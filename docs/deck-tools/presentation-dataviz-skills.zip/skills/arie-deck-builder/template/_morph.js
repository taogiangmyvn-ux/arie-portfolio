/* ---- Morph (like PowerPoint Morph / Keynote Magic Move) ----
   Same data-morph="key" on two neighbouring slides: the element glides from its old position, size, rotation,
   corner radius, colour and opacity to the new ones. The rest of the new slide fades in after it.
   Extras:
   - Charts: put the same data-morph key on a .chart[data-chart] on both slides (same chart type). The chart moves
     to its new place and its numbers tween, so bars grow or shrink, lines bend, rings and donuts turn, radars reshape.
   - data-count on a morph element: the number in it counts from the old value to the new one (keeps prefix,
     suffix, decimals and thousands commas), e.g. <div data-morph="v1" data-count>42%</div>.
   - data-morph-split="words" or "chars" on any element: each word or letter becomes its own morph piece, so
     a sentence can rearrange itself into another. Pieces with no partner fade in.
   - Rotation: set it with the CSS `rotate` property (style="rotate:-8deg"), not transform.
   Works with any engine that marks the current slide with .active. Skipped in scroll view and for reduced motion. */
(() => {
  const stage = document.getElementById("stage"); if (!stage) return;
  const slides = [...stage.querySelectorAll(":scope > .slide")];
  const DUR = 950, EASE = "cubic-bezier(.76,0,.24,1)";  // ease-in-out quart: slow start, slow landing
  // split words / letters into keyed pieces once
  stage.querySelectorAll("[data-morph-split]").forEach(el => {
    const mode = el.dataset.morphSplit, base = el.dataset.morph || el.dataset.morphKey || "t", seen = {};
    delete el.dataset.morph;
    const walk = node => [...node.childNodes].forEach(n => {
      if (n.nodeType === 1) return walk(n);
      if (n.nodeType !== 3) return;
      const parts = mode === "chars" ? [...n.textContent] : n.textContent.split(/(\s+)/);
      const frag = document.createDocumentFragment();
      parts.forEach(p => { if (!p) return; if (/^\s+$/.test(p)) return frag.append(p);
        const t = p.toLowerCase().replace(/[^\p{L}\p{N}]/gu, "") || p; seen[t] = (seen[t] || 0) + 1;
        const s = document.createElement("span"); s.textContent = p; s.style.display = "inline-block"; s.style.whiteSpace = "pre";
        s.dataset.morph = `${base}:${t}:${seen[t]}`; frag.append(s); });
      n.replaceWith(frag);
    });
    walk(el);
  });
  const snap = new Map();
  const scale = () => stage.getBoundingClientRect().width / 1600;
  const record = s => { const k = scale(), sr = s.getBoundingClientRect(), m = {};
    s.querySelectorAll("[data-morph]").forEach(e => { const c = getComputedStyle(e), rotated = c.rotate !== "none" && c.rotate !== "0deg", pr = e.style.rotate; if (rotated) e.style.rotate = "0deg"; const r = e.getBoundingClientRect(); if (rotated) e.style.rotate = pr;
      m[e.dataset.morph] = { x: (r.left - sr.left) / k, y: (r.top - sr.top) / k, w: r.width / k, h: r.height / k, radius: c.borderRadius,
        color: c.color, bg: c.backgroundColor, op: c.opacity, rot: c.rotate === "none" ? "0deg" : c.rotate, text: e.textContent, chart: e.dataset.chart, el: e, z: c.zIndex };
    });
    m.__bg = getComputedStyle(s).backgroundColor; snap.set(s, m); };
  const num = t => { const m = String(t).match(/-?[\d,]*\.?\d+/); return m ? { v: parseFloat(m[0].replace(/,/g, "")), dec: (m[0].split(".")[1] || "").length, comma: m[0].includes(","), pre: t.slice(0, m.index), post: t.slice(m.index + m[0].length) } : null; };
  const count = (e, from) => { const a = num(from), b = num(e.textContent); if (!a || !b || a.v === b.v) return; const t0 = performance.now(), end = e.textContent;
    const fmt = v => b.pre + (b.comma ? v.toLocaleString("en-US", { minimumFractionDigits: b.dec, maximumFractionDigits: b.dec }) : v.toFixed(b.dec)) + b.post;
    const tick = now => { const p = Math.min(1, (now - t0) / DUR), q = p < .5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
      e.textContent = p < 1 ? fmt(a.v + (b.v - a.v) * q) : end; if (p < 1) requestAnimationFrame(tick); };
    requestAnimationFrame(tick); };
  // charts: redraw every frame with in-between numbers (any chart type the chart script draws)
  const st = document.createElement("style");
  st.textContent = ".chart.morphing *{transition:none!important;animation:none!important} .chart.morphing .cb,.chart.morphing .hb{transform:none!important} .chart.morphing .ln{stroke-dashoffset:0!important} .chart.morphing .fade{opacity:1!important}";
  document.head.appendChild(st);
  const mix = (a, b, q) => {
    if (typeof b === "number") { const x = typeof a === "number" ? a : 0, d = Math.max(...[x, b].map(v => (String(v).split(".")[1] || "").length)); return +(x + (b - x) * q).toFixed(d); }
    if (Array.isArray(b)) return b.map((x, i) => mix(Array.isArray(a) ? a[i] : undefined, x, q));
    if (b && typeof b === "object") { const o = {}; for (const k in b) o[k] = mix(a && typeof a === "object" ? a[k] : undefined, b[k], q); return o; }
    return b;
  };
  const tweenChart = (box, fromJSON) => {
    let a, b; try { a = JSON.parse(fromJSON); b = JSON.parse(box.dataset.chart); } catch (e) { return; }
    if (!window.drawChart || a.type !== b.type) return;
    box.classList.add("morphing"); const t0 = performance.now();
    const tick = now => { const p = Math.min(1, (now - t0) / DUR), q = p < .5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
      window.drawChart(box, p < 1 ? mix(a, b, q) : b);
      if (p < 1) requestAnimationFrame(tick); else box.classList.remove("morphing"); };
    requestAnimationFrame(tick);
  };
  let current = slides.find(s => s.classList.contains("active"));
  if (current) setTimeout(() => record(current), 600);
  const FONT = ["fontFamily", "fontSize", "fontWeight", "fontStyle", "lineHeight", "letterSpacing", "textTransform", "textAlign", "color", "whiteSpace"];
  const isTextEl = e => !e.querySelector("img") && e.tagName !== "IMG" && e.textContent.trim() && !e.hasAttribute("data-morph-box") && !(e.classList.contains("chart") && e.dataset.chart);
  let pending = null;   // cleanup of a morph still running; a new slide change finishes it first
  const run = (from, to) => {
    if (pending) { stage.getAnimations({ subtree: true }).forEach(x => { try { x.finish(); } catch (err) {} }); pending(); }
    if (!snap.has(from)) record(from);
    const old = snap.get(from) || {};
    const pairs = [...to.querySelectorAll("[data-morph]")].filter(e => old[e.dataset.morph]);
    // morph only when something real carries over: a shape, photo or chart, or text that stays the same
    const real = pairs.filter(e => !isTextEl(e) || old[e.dataset.morph].text.trim() === e.textContent.trim());
    if (document.body.classList.contains("scroll-mode") || matchMedia("(prefers-reduced-motion: reduce)").matches) { setTimeout(() => record(to), DUR); return; }
    if (!real.length) {
      // plain change: the old slide stays solid underneath and the new one fades in on top (no dark gap between them)
      [from, to].forEach(s => s.style.transition = "none");
      Object.assign(from.style, { opacity: "1", visibility: "visible", transform: "none", zIndex: "2" }); Object.assign(to.style, { zIndex: "3" });
      const outs = [...from.children].map(ch => ch.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 180, easing: "ease-in", fill: "forwards" }));
      const fin = to.animate([{ opacity: 0, transform: "translateY(10px)" }, { opacity: 1, transform: "none" }], { delay: 190, duration: 430, easing: "cubic-bezier(.22,1,.36,1)", fill: "backwards" });
      const done = () => { clearTimeout(timer); pending = null; fin.cancel();
        [from, to].forEach(s => { s.style.opacity = ""; s.style.zIndex = ""; s.style.transform = ""; }); from.style.visibility = "";
        void from.offsetWidth; outs.forEach(x => x.cancel()); [from, to].forEach(s => s.style.transition = ""); record(to); };
      const timer = setTimeout(done, 660); pending = done; return;
    }
    const opt = { duration: DUR, easing: EASE };
    // both slides stay visible: the old one fades out underneath while the new one builds on top
    [from, to].forEach(s => s.style.transition = "none");
    to.style.opacity = "1"; to.style.zIndex = "3"; from.style.opacity = "1"; from.style.zIndex = "2"; from.style.visibility = "visible"; from.style.transform = "none";
    const hidden = pairs.map(e => old[e.dataset.morph].el).filter(Boolean);
    hidden.forEach(x => x.style.visibility = "hidden");
    const bgNew = getComputedStyle(to).backgroundColor, bgOld = old.__bg || bgNew;
    to.animate([{ backgroundColor: bgOld.replace(/rgba?\(([^)]+)\)/, (m, v) => `rgba(${v.split(",").slice(0, 3).join(",")},0)`) }, { backgroundColor: bgNew, offset: .45 }, { backgroundColor: bgNew }], opt);
    const outs = [...from.querySelectorAll(":scope > *")].map(ch => ch.animate([{ opacity: 1 }, { opacity: 0 }], { duration: DUR * .22, easing: "ease-in", fill: "forwards" }));
    const fade = from.animate([{ opacity: 1 }, { opacity: 1, offset: .99 }, { opacity: 0 }], { ...opt, fill: "forwards" });  // stays solid underneath; the new background covers it
    // measure everything first (one layout pass), then start every animation
    const k = scale(), sr = to.getBoundingClientRect();
    const plan = pairs.map(e => { const c = getComputedStyle(e), rotated = c.rotate !== "none" && c.rotate !== "0deg", pr = e.style.rotate;
      if (rotated) e.style.rotate = "0deg"; const r = e.getBoundingClientRect(); if (rotated) e.style.rotate = pr;
      return { e, a: old[e.dataset.morph], c, b: { x: (r.left - sr.left) / k, y: (r.top - sr.top) / k, w: r.width / k, h: r.height / k }, rot: rotated ? c.rotate : "0deg" }; });
    plan.forEach(({ e, a, c, b, rot }) => {
      const isChart = e.classList.contains("chart") && e.dataset.chart && a.chart, isText = isTextEl(e);
      e.style.willChange = "transform, opacity";
      if (isText && a.text.trim() !== e.textContent.trim()) {
        // different words: no travelling, no overlap. Old text fades out where it was, new text rises in after it.
        const g = a.el.cloneNode(true); g.removeAttribute("data-morph"); g.setAttribute("data-morph-ghost", ""); g.querySelectorAll("[data-morph]").forEach(x => x.removeAttribute("data-morph"));
        const oc = getComputedStyle(a.el); FONT.forEach(f => g.style[f] = oc[f]);
        Object.assign(g.style, { position: "absolute", left: a.x + "px", top: a.y + "px", width: a.w + "px", height: a.h + "px", margin: "0", rotate: a.rot, pointerEvents: "none", zIndex: 6, visibility: "visible" });
        to.appendChild(g);
        g.animate([{ opacity: 1, transform: "none" }, { opacity: 0, transform: "translateY(-10px)" }], { duration: DUR * .28, easing: "ease-in", fill: "forwards" }).onfinish = () => g.remove();
        e.animate([{ opacity: 0, transform: "translateY(14px)" }, { opacity: c.opacity, transform: "none" }], { delay: DUR * .34, duration: DUR * .66, easing: "cubic-bezier(.22,1,.36,1)", fill: "backwards" });
      } else if (e.dataset.morphOrbit) {
        // orbit: travel along an ellipse (cx,cy,rx,ry in slide px), growing toward the front and shrinking toward the back
        const [cx, cy, rx, ry] = e.dataset.morphOrbit.split(",").map(Number);
        const ang = (x, y, w, h) => Math.atan2((x + w / 2 - cx) / rx, (y + h / 2 - cy) / ry);
        let a1 = ang(a.x, a.y, a.w, a.h), a2 = ang(b.x, b.y, b.w, b.h); if (a2 - a1 > Math.PI) a1 += 2 * Math.PI; if (a1 - a2 > Math.PI) a2 += 2 * Math.PI;
        const d1 = (Math.cos(a1) + 1) / 2, d2 = (Math.cos(a2) + 1) / 2, sizeAt = d => Math.abs(d2 - d1) < .01 ? 1 : (a.w + (b.w - a.w) * (d - d1) / (d2 - d1)) / b.w;
        const ease = t => t < .5 ? 8 * t ** 4 : 1 - Math.pow(-2 * t + 2, 4) / 2, frames = [];
        for (let i = 0; i <= 16; i++) { const t = i / 16, q = ease(t), an = a1 + (a2 - a1) * q, d = (Math.cos(an) + 1) / 2, k2 = Math.max(.2, sizeAt(d));
          const ccx = cx + rx * Math.sin(an), ccy = cy + ry * Math.cos(an);
          frames.push({ offset: t, transformOrigin: "50% 50%", transform: `translate(${ccx - (b.x + b.w / 2)}px,${ccy - (b.y + b.h / 2)}px) scale(${k2})`, zIndex: Math.round(d * 10),
            opacity: +a.op + (+c.opacity - +a.op) * q, borderRadius: q < .5 ? a.radius : c.borderRadius, rotate: q < .5 ? a.rot : rot }); }
        e.animate(frames, { duration: DUR * 1.15, easing: "linear" });
      } else {
        const sx = isChart ? 1 : (a.w / b.w || 1), sy = isChart ? 1 : (a.h / b.h || 1);
        const s0 = isText ? `scale(${(sx + sy) / 2})` : `scale(${sx},${sy})`;
        const far = Math.hypot(a.x - b.x, a.y - b.y) > 20;
        if (isText && far) {
          // text that travels far fades through the middle of the trip, so words passing each other never collide
          const T0 = `translate(${a.x - b.x}px,${a.y - b.y}px) ${s0}`;
          e.animate([{ transformOrigin: "0 0", transform: T0 }, { transformOrigin: "0 0", transform: "none" }], opt);
          e.animate([{ color: a.color, opacity: a.op }, { opacity: 0, offset: .1 }, { opacity: 0, offset: .82 }, { color: c.color, opacity: c.opacity }], { duration: DUR, easing: "linear" });
        } else
        e.animate([{ transformOrigin: "0 0", transform: `translate(${a.x - b.x}px,${a.y - b.y}px) ${s0}`, rotate: a.rot, borderRadius: a.radius, color: a.color, backgroundColor: a.bg, opacity: a.op, zIndex: a.z === "auto" ? 0 : a.z },
                   { transformOrigin: "0 0", transform: "none", rotate: rot, zIndex: c.zIndex === "auto" ? 0 : c.zIndex, borderRadius: c.borderRadius, color: c.color, backgroundColor: c.backgroundColor, opacity: c.opacity }], opt);
        const img = e.tagName === "IMG" ? null : e.querySelector("img");
        if (img && !isText) img.animate([{ transform: `scale(${1 / sx},${1 / sy}) scale(${Math.max(sx, sy)})`, transformOrigin: "50% 50%" }, { transform: "none" }], opt);
      }
      if (e.hasAttribute("data-count")) count(e, a.text);
      if (isChart) tweenChart(e, a.chart);
    });
    // everything new on the slide comes in quickly, in reading order, while the morph is still moving
    const keep = new Set(pairs), rest = [];
    const walk = n => [...n.children].forEach(ch => { if (keep.has(ch) || ch.hasAttribute("data-morph-ghost")) return; if ([...keep].some(p => ch.contains(p))) walk(ch); else rest.push(ch); });
    walk(to);
    // when a photo shrinks or grows a lot, new items wait until it has mostly landed so they don't sit under it
    const bigMove = plan.some(({ e, a, b }) => (e.tagName === "IMG" || e.querySelector("img")) && Math.max(a.w * a.h / (b.w * b.h), b.w * b.h / (a.w * a.h)) > 1.8);
    const startAt = DUR * (bigMove ? .55 : .28);
    rest.forEach((ch, i) => ch.animate([{ opacity: 0, transform: "translateY(16px) scale(.96)" }, { opacity: 1, transform: "none" }], { duration: 520, delay: startAt + Math.min(i * 40, 240), easing: "cubic-bezier(.22,1,.36,1)", fill: "backwards" }));
    const done = () => { clearTimeout(timer); pending = null; hidden.forEach(x => x.style.visibility = ""); plan.forEach(p => p.e.style.willChange = "");
      to.querySelectorAll(":scope > [data-morph-ghost]").forEach(g => g.remove());
      [from, to].forEach(s => { s.style.opacity = ""; s.style.zIndex = ""; }); from.style.visibility = ""; from.style.transform = ""; fade.cancel(); outs.forEach(x => x.cancel());
      void from.offsetWidth; [from, to].forEach(s => s.style.transition = ""); record(to); };
    const timer = setTimeout(done, DUR + 60); pending = done;
  };
  new MutationObserver(() => { const now = slides.find(s => s.classList.contains("active")); if (now && now !== current) { const prev = current; current = now; if (prev) run(prev, now); else record(now); } })
    .observe(stage, { subtree: true, attributes: true, attributeFilter: ["class"] });
})();
