/* ---- image crop (double-click any content image): drag to choose what shows, wheel or slider to zoom inside
   the frame (scale origin = the object-position point, so the image always covers the frame), pick a frame shape
   (Original, Square, Rounded, Arch, Pill, Oval, Circle), switch to Frame mode to move the whole frame, drag a
   corner handle to resize it (Shift keeps the shape), Replace the photo (button, drop a file on any image, or paste
   while cropping), Fit / Reset / Done. Ctrl/Cmd+Z undoes, Ctrl/Cmd+Shift+Z
   or Ctrl+Y redoes (also the ↶ ↷ buttons), even after Done. Esc or a click outside exits and keeps
   the crop. The frame keeps its size. Elements with a CSS background-image get the same controls through
   background-position + background-size.
   Saved with the text edits: keys "img:s3:2" (slide 3, 3rd image; "img:r:4" in a report) or "bg:…" for background
   images, value {"p":"40% 30%","z":1.25,"s":"arch","dx":12,"dy":-8,"w":420,"h":300,"u":"data:image/jpeg;base64,…"} (s = shape,
   empty = the layout's own; dx/dy = frame move, w/h = frame size, in slide px; u = replacement photo, shrunk to
   1600px on the long side, empty = the original). scripts/bake_edits.py
   writes img: keys into the HTML (position + zoom on the <img>, shape on its frame). Skips img.logo, avatars, toolbar
   icons, chart graphics and anything inside [data-nocrop]. ---- */
(() => {
  const stage = document.getElementById("stage"), rpt = document.getElementById("rpt");
  const roots = stage ? [...stage.querySelectorAll(":scope > .slide")].map((r, i) => [r, "s" + (i + 1)]) : rpt ? [[rpt, "r"]] : [];
  if (!roots.length) return;
  const LKEY = "deck-edits:" + document.title;
  const SKIP = ".chart,svg,nav,button,.bar,.rbar,.editbar,.pick,[data-nocrop]";
  // frame shapes: pure CSS, so they follow the frame at any size (huge radii are clamped by the browser)
  const SHAPES = {
    "": { label: "Original" },
    square: { label: "Square", br: "0px", cp: "none" },
    rounded: { label: "Rounded", br: "24px", cp: "none" },
    arch: { label: "Arch", br: "9999px 9999px 0 0", cp: "none" },
    pill: { label: "Pill", br: "9999px", cp: "none" },
    oval: { label: "Oval", br: "50%", cp: "none" },
    circle: { label: "Circle", br: "0px", cp: "circle(closest-side at 50% 50%)" },
  };
  const ICON = {
    "": '<rect x="3" y="5" width="14" height="10" rx="2" stroke-dasharray="2 2"/>', square: '<rect x="3" y="5" width="14" height="10"/>',
    rounded: '<rect x="3" y="5" width="14" height="10" rx="4"/>', arch: '<path d="M5 17V9a5 5 0 0 1 10 0v8z"/>',
    pill: '<rect x="2" y="6" width="16" height="8" rx="4"/>', oval: '<ellipse cx="10" cy="10" rx="8" ry="5.5"/>', circle: '<circle cx="10" cy="10" r="6"/>' };
  const items = new Map();   // key -> {el, kind, frame, orig:{p,z,s}, fr0:{br,cp}}
  const pct = v => { const m = String(v || "").trim().split(/\s+/); const f = s => s === "left" || s === "top" ? 0 : s === "right" || s === "bottom" ? 100 : s === "center" || !s ? 50 : parseFloat(s);
    let x = f(m[0]), y = f(m[1] ?? "center"); if (m[0] === "top" || m[0] === "bottom") [x, y] = [50, f(m[0])];
    return [isFinite(x) ? x : 50, isFinite(y) ? y : 50]; };
  const bgUrl = el => (getComputedStyle(el).backgroundImage.match(/url\(["']?(.*?)["']?\)/) || [])[1];
  const fr0 = f => ({ br: f.style.borderRadius, cp: f.style.clipPath, tr: f.style.translate, w: f.style.width, h: f.style.height, zi: f.style.zIndex });
  const r1 = v => Math.round((+v || 0) * 10) / 10;
  const fmt = (x, y) => `${+x.toFixed(2)}% ${+y.toFixed(2)}%`;

  roots.forEach(([root, pre]) => {
    let n = 0, b = 0;
    root.querySelectorAll("img").forEach(img => {
      if (img.matches(".logo,.avatar,.av,[class*=avatar],[class*=icon]") || img.closest(SKIP)) return;
      const k = `img:${pre}:${n++}`, frame = img.parentElement;
      const [x, y] = pct(img.style.objectPosition || "50% 50%");
      const z = parseFloat((img.style.transform.match(/scale\(([\d.]+)\)/) || [])[1]) || 1;
      items.set(k, { el: img, kind: "img", frame, orig: { p: fmt(x, y), z, s: "", dx: 0, dy: 0, w: 0, h: 0, u: "" }, fr0: fr0(frame), src0: img.getAttribute("src") || "" });
      img.title = img.title || "Double-click to crop"; img.draggable = false;
    });
    root.querySelectorAll("*").forEach(el => {
      if (el.tagName === "IMG" || el.closest(SKIP) || !bgUrl(el)) return;
      const k = `bg:${pre}:${b++}`, [x, y] = pct(getComputedStyle(el).backgroundPosition.split(",")[0] || "50% 50%");
      items.set(k, { el, kind: "bg", frame: el, orig: { p: fmt(x, y), z: 1, s: "", dx: 0, dy: 0, w: 0, h: 0, u: "" }, fr0: fr0(el), src0: el.style.backgroundImage });
      el.title = el.title || "Double-click to crop";
    });
  });

  // natural size of a background image (cached)
  const nat = new Map();
  function bgSize(it) {
    const url = bgUrl(it.el);
    if (nat.has(url)) return Promise.resolve(nat.get(url));
    return new Promise(res => { const im = new Image(); im.onload = () => { nat.set(url, [im.naturalWidth, im.naturalHeight]); res(nat.get(url)); }; im.onerror = () => res([1, 1]); im.src = url; });
  }
  function shape(it, s) {
    const sh = SHAPES[s] && s ? SHAPES[s] : null, f = it.frame.style;
    if (sh) { f.borderRadius = sh.br; f.clipPath = sh.cp === "none" ? "" : sh.cp; if (getComputedStyle(it.frame).overflow === "visible") f.overflow = "hidden"; }
    else { f.borderRadius = it.fr0.br; f.clipPath = it.fr0.cp; }
  }
  function apply(it, v) {
    v = { ...(it.cur || it.orig), ...v };
    const [x, y] = pct(v.p), z = Math.max(1, Math.min(4, +v.z || 1)), p = fmt(x, y), s = SHAPES[v.s] ? v.s || "" : "";
    const dx = r1(v.dx), dy = r1(v.dy), w = r1(v.w), h = r1(v.h), f = it.frame.style, u = typeof v.u === "string" && /^data:image\/|^https?:|^[\w./-]+$/.test(v.u) ? v.u : "";
    if (u !== (it.cur?.u || "")) {   // swap the photo; the original comes back when u is empty
      if (it.kind === "img") { if (u) it.el.src = u; else it.el.setAttribute("src", it.src0); it.el.removeAttribute("srcset"); }
      else it.el.style.backgroundImage = u ? `url("${u}")` : it.src0;
    }
    f.translate = dx || dy ? `${dx}px ${dy}px` : it.fr0.tr;
    f.zIndex = dx || dy || w || h ? "4" : it.fr0.zi;
    f.width = w ? w + "px" : it.fr0.w; f.height = h ? h + "px" : it.fr0.h;
    if (it.kind === "img") {
      const st = it.el.style; st.objectFit = "cover"; st.objectPosition = p; st.transformOrigin = p; st.transform = z > 1.001 ? `scale(${+z.toFixed(3)})` : "";
      if (getComputedStyle(it.frame).overflow === "visible") it.frame.style.overflow = "hidden";
    } else {
      bgSize(it).then(([nw, nh]) => { const fw = it.el.clientWidth, fh = it.el.clientHeight, c = Math.max(fw / nw, fh / nh) * z;
        it.el.style.backgroundSize = `${Math.ceil(nw * c)}px ${Math.ceil(nh * c)}px`; it.el.style.backgroundPosition = p; });
    }
    shape(it, s);
    it.cur = { p, z, s, dx, dy, w, h, u };
    if (it === act) { paintShapes(); place(); }
  }
  items.forEach(it => { it.cur = { ...it.orig }; });
  const loadSaved = obj => Object.entries(obj || {}).forEach(([k, v]) => { const it = items.get(k); if (it && v && typeof v === "object") apply(it, v); });
  const readLocal = () => { try { return JSON.parse(localStorage.getItem(LKEY) || "{}") || {}; } catch (e) { return {}; } };
  const fresh = () => fetch("edits.json", { cache: "no-store" }).then(r => r.ok ? r.json() : {}).catch(() => ({}));
  fresh().then(j => { loadSaved(j); loadSaved(readLocal()); });

  let art = null; window.claude?.use?.("artifact").then(a => { art = a; }).catch(() => {});

  // ---- toolbar ----
  const css = document.createElement("style");
  css.textContent = `.cropbar{position:fixed;z-index:70;display:flex;flex-wrap:wrap;align-items:center;gap:8px;max-width:min(560px,calc(100vw - 16px));background:#1B2631;color:#E6ECF0;border-radius:12px;padding:8px 10px;font:500 13px/1.2 system-ui,sans-serif;box-shadow:0 14px 36px rgba(0,0,0,.35)}
.cropbar button{all:unset;cursor:pointer;padding:7px 12px;border-radius:8px;background:rgba(255,255,255,.12)}.cropbar button.primary{background:#FFE14D;color:#111;font-weight:600}
.cropbar button:focus-visible{outline:2px solid #FFE14D}.cropbar input{width:120px;accent-color:#FFE14D}.cropbar .hint{opacity:.75;margin-right:4px}
.cropbar .shp{display:flex;gap:4px;width:100%;align-items:center;border-top:1px solid rgba(255,255,255,.12);padding-top:8px}.cropbar .shp > span{opacity:.75;margin-right:4px}
.cropbar .shp button{padding:5px 7px;display:grid;place-items:center}.cropbar .shp button[aria-pressed="true"]{background:#FFE14D;color:#111}
.cropbar .shp svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.6}
.cropbar .mode{display:flex;border-radius:8px;overflow:hidden}.cropbar .mode button{border-radius:0;padding:7px 11px}.cropbar .mode button[aria-pressed="true"]{background:#FFE14D;color:#111}
.crophandle{position:fixed;z-index:69;width:14px;height:14px;margin:-7px 0 0 -7px;border-radius:3px;background:#FFE14D;border:2px solid #1B2631;box-shadow:0 2px 8px rgba(0,0,0,.35);touch-action:none}
.crophandle[data-c=nw],.crophandle[data-c=se]{cursor:nwse-resize}.crophandle[data-c=ne],.crophandle[data-c=sw]{cursor:nesw-resize}
.cropping.framemode,.cropping.framemode img{cursor:move!important}
.cropping{outline:3px solid #FFE14D!important;outline-offset:3px;cursor:grab!important;touch-action:none}.cropping:active{cursor:grabbing!important}
.cropping img{cursor:grab!important;touch-action:none}.cropdrop{outline:3px dashed #FFE14D!important;outline-offset:3px}.croptoast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:71;background:#1B2631;color:#E6ECF0;padding:10px 16px;border-radius:10px;font:500 13px system-ui,sans-serif}`;
  document.head.appendChild(css);
  const bar = document.createElement("div"); bar.className = "cropbar"; bar.hidden = true;
  bar.innerHTML = '<span class="mode"><button type="button" aria-pressed="true">Image</button><button type="button" aria-pressed="false">Frame</button></span><span class="hint"></span><button type="button" title="Undo (Ctrl/Cmd+Z)" aria-label="Undo">↶</button><button type="button" title="Redo (Ctrl/Cmd+Shift+Z)" aria-label="Redo">↷</button><input type="range" min="1" max="4" step="0.01" value="1" aria-label="Zoom"><button type="button" title="Replace the photo (or drop / paste an image)">Replace</button><button type="button">Fit</button><button type="button">Reset</button><button type="button" class="primary">Done</button><div class="shp"><span>Shape</span></div>';
  document.body.appendChild(bar);
  const [modeBox, hint, bUndo, bRedo, slider, bNew, bFit, bReset, bDone, shp] = bar.children;
  const file = document.createElement("input"); file.type = "file"; file.accept = "image/*"; file.hidden = true; document.body.appendChild(file);
  let mode = "image";
  const setMode = m => { mode = m; [...modeBox.children].forEach((b, i) => b.setAttribute("aria-pressed", String((i === 0) === (m === "image"))));
    hint.textContent = m === "image" ? "Drag to move the photo · scroll to zoom" : "Drag to move the frame · corners resize (Shift keeps shape)";
    act?.frame.classList.toggle("framemode", m === "frame"); };
  modeBox.children[0].onclick = () => setMode("image"); modeBox.children[1].onclick = () => setMode("frame");
  const handles = ["nw", "ne", "sw", "se"].map(c => { const h = document.createElement("div"); h.className = "crophandle"; h.dataset.c = c; h.hidden = true; document.body.appendChild(h); return h; });
  Object.entries(SHAPES).forEach(([s, d]) => {
    const b = document.createElement("button"); b.type = "button"; b.dataset.s = s; b.title = d.label; b.setAttribute("aria-label", d.label + " shape");
    b.innerHTML = `<svg viewBox="0 0 20 20">${ICON[s]}</svg>`; b.onclick = () => { if (!act) return; const b0 = snap(act); apply(act, { s }); record(actKey, b0, snap(act)); }; shp.appendChild(b); });
  function paintShapes() { shp.querySelectorAll("button").forEach(b => b.setAttribute("aria-pressed", String(!!act && (act.cur.s || "") === b.dataset.s))); }
  // ---- undo / redo: one step per finished gesture (drag, wheel burst, slider, shape, Fit, Reset) ----
  const hist = [], fut = [], snap = it => JSON.parse(JSON.stringify(it.cur)), same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  function record(k, b, a) { if (same(b, a)) return; hist.push({ k, b, a }); fut.length = 0; if (hist.length > 200) hist.shift(); paintHist(); }
  function step(from, to, key) {
    const e = from.pop(); if (!e) { toast(key === "b" ? "Nothing to undo" : "Nothing to redo"); return; }
    to.push(e); const it = items.get(e.k), v = e[key]; apply(it, v);
    if (it === act) slider.value = it.cur.z; else persist(e.k, it.cur, true);
    paintHist();
  }
  const undo = () => step(hist, fut, "b"), redoIt = () => step(fut, hist, "a");
  function paintHist() { bUndo.disabled = !hist.length; bRedo.disabled = !fut.length; bUndo.style.opacity = hist.length ? 1 : .4; bRedo.style.opacity = fut.length ? 1 : .4; }
  bUndo.onclick = undo; bRedo.onclick = redoIt;
  const toast = t => { const d = document.createElement("div"); d.className = "croptoast"; d.textContent = t; document.body.appendChild(d); setTimeout(() => d.remove(), 2600); };

  let act = null, actKey = null, start = null;
  function place() {
    if (!act) return; const r = act.frame.getBoundingClientRect(), w = bar.offsetWidth, h = bar.offsetHeight;
    let top = r.bottom + 10; if (top + h > innerHeight - 8) top = Math.max(8, r.top - h - 10);
    bar.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.left + r.width / 2 - w / 2)) + "px"; bar.style.top = top + "px";
    handles.forEach(hd => { const c = hd.dataset.c; hd.style.left = (c[1] === "w" ? r.left : r.right) + "px"; hd.style.top = (c[0] === "n" ? r.top : r.bottom) + "px"; });
  }
  function enter(k) {
    if (act) exit(true);
    act = items.get(k); actKey = k; start = { ...act.cur };
    act.frame.classList.add("cropping"); bar.hidden = false; handles.forEach(h => h.hidden = false); slider.value = act.cur.z; setMode("image"); paintShapes(); paintHist(); place();
  }
  async function exit(commit) {
    if (!act) return;
    const it = act, k = actKey, before = start; act = null; actKey = null; bar.hidden = true; handles.forEach(h => h.hidden = true); it.frame.classList.remove("cropping", "framemode");
    if (!commit) { apply(it, before); return; }
    if (JSON.stringify(it.cur) === JSON.stringify(before)) return;
    await persist(k, it.cur);
  }
  async function persist(k, v, quiet) {
    if (art) {
      try { const cur = await fresh(); await art.publish({ "edits.json": JSON.stringify({ ...cur, [k]: v }, null, 1) }); if (!quiet) toast("Image saved. Everyone with the link sees it."); return; }
      catch (e) { if (!["not_writer", "not_granted", "capability_disabled", "not_declared", "consent_required"].includes(e?.code)) { toast("Could not save the image. Try again."); return; } art = null; }
    }
    const local = readLocal(); local[k] = v; try { localStorage.setItem(LKEY, JSON.stringify(local)); } catch (e) {}
    if (!quiet) toast("Image saved in this browser. Use Copy edits to send it to Claude.");
  }

  // geometry: content width/height of the cover image at zoom 1, in the frame's own px
  function dims(it) {
    const fw = it.frame.clientWidth || 1, fh = it.frame.clientHeight || 1;
    let nw, nh; if (it.kind === "img") { nw = it.el.naturalWidth || fw; nh = it.el.naturalHeight || fh; } else [nw, nh] = nat.get(bgUrl(it.el)) || [fw, fh];
    const c = Math.max(fw / nw, fh / nh); return { fw, fh, w: nw * c, h: nh * c };
  }
  // page px -> frame px (decks are scaled with a CSS transform)
  const unit = it => (it.frame.getBoundingClientRect().width || 1) / (it.frame.offsetWidth || 1);

  items.forEach((it, k) => {
    it.frame.addEventListener("dblclick", e => { if (e.target !== it.el && it.kind === "img" && !it.el.contains(e.target)) return; e.preventDefault(); e.stopPropagation(); enter(k); }, true);
  });
  // a click on a croppable image (or anywhere while cropping) must not reach the deck's click-to-advance:
  // a double-click is two clicks, so the slide would move before crop mode opens
  const isItem = t => { for (const it of items.values()) if (it.el === t) return true; return false; };
  let swallow = false;   // the click that closes crop mode (outside the frame) must not reach the deck either
  document.addEventListener("click", e => { if (bar.contains(e.target)) return; if (act || swallow || isItem(e.target)) e.stopPropagation(); swallow = false; }, true);
  document.addEventListener("pointerdown", e => {
    if (!act) return;
    if (bar.contains(e.target)) return;
    const it = act, u = unit(it), sx = e.clientX, sy = e.clientY, c0 = { ...it.cur };
    const k0 = actKey, drag = move => { const up = () => { removeEventListener("pointermove", move); removeEventListener("pointerup", up); record(k0, c0, snap(it)); }; addEventListener("pointermove", move); addEventListener("pointerup", up); };
    if (e.target.classList?.contains("crophandle")) {   // resize the frame from a corner; the opposite corner stays put
      e.preventDefault(); e.stopPropagation();
      const c = e.target.dataset.c, w0 = it.frame.offsetWidth, h0 = it.frame.offsetHeight, ratio = w0 / h0;
      drag(ev => { const ddx = (ev.clientX - sx) / u, ddy = (ev.clientY - sy) / u;
        let w = Math.max(40, c[1] === "e" ? w0 + ddx : w0 - ddx), h = Math.max(40, c[0] === "s" ? h0 + ddy : h0 - ddy);
        if (ev.shiftKey) { if (w / ratio > h) h = w / ratio; else w = h * ratio; }
        apply(it, { w, h, dx: c0.dx + (c[1] === "w" ? w0 - w : 0), dy: c0.dy + (c[0] === "n" ? h0 - h : 0) }); });
      return;
    }
    if (!act.frame.contains(e.target)) { swallow = true; exit(true); return; }
    e.preventDefault(); e.stopPropagation();
    if (mode === "frame") { drag(ev => apply(it, { dx: c0.dx + (ev.clientX - sx) / u, dy: c0.dy + (ev.clientY - sy) / u })); return; }
    const d = dims(it), [x0, y0] = pct(it.cur.p), z = it.cur.z;
    const ox = d.w * z - d.fw, oy = d.h * z - d.fh;
    const move = ev => { const dx = (ev.clientX - sx) / u, dy = (ev.clientY - sy) / u;
      const x = ox > 0.5 ? Math.min(100, Math.max(0, x0 - dx / ox * 100)) : x0, y = oy > 0.5 ? Math.min(100, Math.max(0, y0 - dy / oy * 100)) : y0;
      apply(it, { p: fmt(x, y), z }); };
    drag(move);
  }, true);
  let wheelB = null, wheelK = null, wheelT = 0;
  document.addEventListener("wheel", e => {
    if (!act || !act.frame.contains(e.target)) return;
    e.preventDefault(); e.stopPropagation();
    if (!wheelB) { wheelB = snap(act); wheelK = actKey; } clearTimeout(wheelT);
    const z = Math.max(1, Math.min(4, act.cur.z * Math.exp(-e.deltaY * 0.0015))); apply(act, { z }); slider.value = z;
    const it = act; wheelT = setTimeout(() => { record(wheelK, wheelB, snap(it)); wheelB = null; }, 350);
  }, { passive: false, capture: true });
  let sliderB = null;
  slider.addEventListener("input", () => { if (!act) return; if (!sliderB) sliderB = snap(act); apply(act, { z: +slider.value }); });
  slider.addEventListener("change", () => { if (act && sliderB) record(actKey, sliderB, snap(act)); sliderB = null; });
  bFit.onclick = () => { if (!act) return; const b0 = snap(act); apply(act, { z: 1 }); slider.value = 1; record(actKey, b0, snap(act)); };
  bReset.onclick = () => { if (!act) return; const b0 = snap(act); apply(act, { ...act.orig }); slider.value = act.orig.z; record(actKey, b0, snap(act)); };
  bDone.onclick = () => exit(true);

  // ---- replace the photo: shrink to 1600px on the long side so edits.json and localStorage stay small ----
  function shrink(f) {
    return new Promise((res, rej) => {
      if (!f || !/^image\//.test(f.type)) return rej(new Error("not an image"));
      const r = new FileReader(); r.onerror = rej;
      r.onload = () => { const im = new Image(); im.onerror = rej; im.onload = () => {
        const sc = Math.min(1, 1600 / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement("canvas");
        c.width = Math.round(im.naturalWidth * sc); c.height = Math.round(im.naturalHeight * sc);
        c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
        const png = f.type === "image/png" || f.type === "image/webp" || f.type === "image/gif";
        let out = png ? c.toDataURL("image/png") : ""; if (!out || out.length > 900000) out = c.toDataURL("image/jpeg", 0.85);
        res(out); }; im.src = r.result; };
      r.readAsDataURL(f);
    });
  }
  async function replace(k, f) {
    const it = items.get(k); if (!it) return;
    let u; try { u = await shrink(f); } catch (e) { toast("That file is not an image."); return; }
    const b0 = snap(it); apply(it, { u, p: "50% 50%", z: 1 });
    if (it === act) slider.value = 1;
    record(k, b0, snap(it));
    if (it !== act) persist(k, it.cur);
  }
  bNew.onclick = () => { if (act) file.click(); };
  file.onchange = () => { if (act && file.files[0]) replace(actKey, file.files[0]); file.value = ""; };
  // drop an image file on any croppable image, in or out of crop mode
  items.forEach((it, k) => {
    const t = it.frame;
    t.addEventListener("dragover", e => { if ([...(e.dataTransfer?.types || [])].includes("Files")) { e.preventDefault(); e.stopPropagation(); t.classList.add("cropdrop"); } }, true);
    t.addEventListener("dragleave", () => t.classList.remove("cropdrop"));
    t.addEventListener("drop", e => { const f = e.dataTransfer?.files?.[0]; t.classList.remove("cropdrop"); if (!f) return; e.preventDefault(); e.stopPropagation(); replace(k, f); }, true);
  });
  // paste an image while cropping
  document.addEventListener("paste", e => {
    if (!act) return; const f = [...(e.clipboardData?.files || [])].find(x => /^image\//.test(x.type)); if (!f) return;
    e.preventDefault(); e.stopPropagation(); replace(actKey, f);
  }, true);
  document.addEventListener("keydown", e => {
    if (act && e.key === "Escape") { e.preventDefault(); e.stopPropagation(); exit(true); return; }
    const mod = e.metaKey || e.ctrlKey, k = e.key.toLowerCase();
    if (!mod || (k !== "z" && k !== "y")) return;
    if (e.target.isContentEditable || /INPUT|TEXTAREA/.test(e.target.tagName)) return;   // text keeps the browser's own undo
    if (!act && !hist.length && !fut.length) return;
    e.preventDefault(); e.stopPropagation();
    if (k === "y" || e.shiftKey) redoIt(); else undo();
  }, true);
  addEventListener("resize", place); addEventListener("scroll", place, true);
  // images added later (the "+ Image" tool in reports): register them so double-click crop, shapes, replace and undo work too
  let savedAll = {}; fresh().then(j => { savedAll = { ...j, ...readLocal() }; });
  function adopt(img, k) {
    if (items.has(k)) return items.get(k);
    const frame = img.parentElement;
    const it = { el: img, kind: "img", frame, orig: { p: "50% 50%", z: 1, s: "", dx: 0, dy: 0, w: 0, h: 0, u: "" }, fr0: fr0(frame), src0: img.getAttribute("src") || "" };
    it.cur = { ...it.orig }; items.set(k, it); img.draggable = false; frame.title = "Double-click to crop";
    frame.addEventListener("dblclick", e => { e.preventDefault(); e.stopPropagation(); enter(k); }, true);
    if (savedAll[k] && typeof savedAll[k] === "object") apply(it, savedAll[k]);
    return it;
  }
  const forget = k => { if (act && actKey === k) exit(false); items.delete(k); };
  window.imageCrops = { items, apply, SHAPES, replace, adopt, forget, isCropping: () => !!act };
})();
