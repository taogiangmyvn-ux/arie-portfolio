/* ---- annotate a report (the ✎ Draw button, or D): pen, highlighter, arrow, box, circle, eraser, 6 colours,
   undo (Ctrl/Cmd+Z), clear, done. Keys while drawing: P pen · H highlight · A arrow · R box · O circle · E eraser ·
   1–6 colour · Esc done. Drawings sit on an SVG layer over the whole report, in report units (1200 wide), so they
   stay in place when the page is scaled. Saved like the other edits: on the claude.ai link into edits.json
   (key "ink:r", everyone sees them), elsewhere in this browser. ---- */
(() => {
  const rpt = document.getElementById("rpt"); if (!rpt) return;
  const LKEY = "deck-edits:" + document.title, KEY = "ink:r", NS = "http://www.w3.org/2000/svg", BASE = 1200;
  const COLS = ["#E8552D", "#FFC93C", "#2F6FED", "#1F9D55", "#1B2631", "#FFFFFF"];
  const css = document.createElement("style");
  css.textContent = `#rpt{position:relative}
.inklayer{position:absolute;left:0;top:0;width:100%;z-index:6;pointer-events:none;overflow:visible}
body.drawing .inklayer{pointer-events:auto;cursor:crosshair}
body.drawing.erasing .inklayer{cursor:not-allowed}
body.drawing.erasing .inklayer *{cursor:pointer}
.drawbar{position:fixed;left:50%;bottom:calc(76px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:72;display:flex;flex-wrap:wrap;align-items:center;gap:4px;max-width:calc(100vw - 16px);
  background:#1B2631;color:#E6ECF0;border-radius:12px;padding:6px 8px;font:500 13px/1.2 system-ui,sans-serif;box-shadow:0 14px 36px rgba(0,0,0,.35)}
.drawbar button{all:unset;cursor:pointer;padding:7px 9px;border-radius:8px;min-width:18px;text-align:center}
.drawbar button:hover{background:rgba(255,255,255,.12)}.drawbar button[aria-pressed="true"]{background:#FFE14D;color:#111}
.drawbar .sep{width:1px;height:20px;background:rgba(255,255,255,.18);margin:0 3px}
.drawbar .sw{width:18px;height:18px;padding:0;border-radius:50%;border:2px solid rgba(255,255,255,.4);min-width:0}
.drawbar .sw[aria-pressed="true"]{outline:2px solid #FFE14D;outline-offset:2px;background:none}
.drawbar .done{background:#FFE14D;color:#111;font-weight:600;padding:7px 12px}
@media print{.drawbar{display:none!important}}`;
  document.head.appendChild(css);

  const svg = document.createElementNS(NS, "svg"); svg.setAttribute("class", "inklayer"); rpt.appendChild(svg);
  const defs = document.createElementNS(NS, "defs"); svg.appendChild(defs);
  let shapes = [], tool = "pen", col = COLS[0], on = false, art = null, cur = null;
  const k = () => BASE / (rpt.offsetWidth || BASE);   // page px -> report units
  function size() { const h = rpt.scrollHeight * k(); svg.setAttribute("viewBox", `0 0 ${BASE} ${h}`); svg.style.height = rpt.scrollHeight + "px"; }
  new ResizeObserver(size).observe(rpt); size();

  function arrowHead(c) { const id = "ah" + c.replace("#", ""); if (!defs.querySelector("#" + id)) {
    const m = document.createElementNS(NS, "marker"); m.id = id; ["viewBox", "0 0 10 10", "refX", "6", "refY", "5", "markerWidth", "5", "markerHeight", "5", "orient", "auto-start-reverse"]
      .reduce((a, v, i, arr) => (i % 2 ? 0 : m.setAttribute(v, arr[i + 1]), a), 0);
    const p = document.createElementNS(NS, "path"); p.setAttribute("d", "M0,0 L10,5 L0,10 z"); p.setAttribute("fill", c); m.appendChild(p); defs.appendChild(m); } return `url(#${id})`; }
  function draw(s) {
    let e;
    if (s.t === "pen" || s.t === "hl") { e = document.createElementNS(NS, "polyline"); e.setAttribute("points", s.p.map(q => q.join(",")).join(" "));
      e.setAttribute("fill", "none"); e.setAttribute("stroke", s.c); e.setAttribute("stroke-linecap", "round"); e.setAttribute("stroke-linejoin", "round");
      e.setAttribute("stroke-width", s.t === "hl" ? 22 : 4); if (s.t === "hl") e.setAttribute("stroke-opacity", ".35"); }
    else if (s.t === "arrow") { e = document.createElementNS(NS, "line"); [["x1", s.a[0]], ["y1", s.a[1]], ["x2", s.b[0]], ["y2", s.b[1]]].forEach(([n, v]) => e.setAttribute(n, v));
      e.setAttribute("stroke", s.c); e.setAttribute("stroke-width", 5); e.setAttribute("stroke-linecap", "round"); e.setAttribute("marker-end", arrowHead(s.c)); }
    else { const x = Math.min(s.a[0], s.b[0]), y = Math.min(s.a[1], s.b[1]), w = Math.abs(s.a[0] - s.b[0]), h = Math.abs(s.a[1] - s.b[1]);
      if (s.t === "rect") { e = document.createElementNS(NS, "rect"); [["x", x], ["y", y], ["width", w], ["height", h], ["rx", 6]].forEach(([n, v]) => e.setAttribute(n, v)); }
      else { e = document.createElementNS(NS, "ellipse"); [["cx", x + w / 2], ["cy", y + h / 2], ["rx", w / 2], ["ry", h / 2]].forEach(([n, v]) => e.setAttribute(n, v)); }
      e.setAttribute("fill", "none"); e.setAttribute("stroke", s.c); e.setAttribute("stroke-width", 4); }
    e.dataset.i = shapes.indexOf(s); svg.appendChild(e); return e;
  }
  const redraw = () => { [...svg.children].forEach(c => c !== defs && c.remove()); shapes.forEach(draw); };

  // ---- toolbar ----
  const bar = document.createElement("div"); bar.className = "drawbar"; bar.hidden = true;
  const TOOLS = [["pen", "✎ Pen", "P"], ["hl", "▮ Highlight", "H"], ["arrow", "↗ Arrow", "A"], ["rect", "▢ Box", "R"], ["ellipse", "◯ Circle", "O"], ["erase", "⌫ Eraser", "E"]];
  bar.innerHTML = TOOLS.map(([t, l, key]) => `<button type="button" data-t="${t}" title="${l.slice(2)} (${key})">${l}</button>`).join("") + '<span class="sep"></span>' +
    COLS.map((c, i) => `<button type="button" class="sw" data-c="${c}" title="Colour (${i + 1})" style="background:${c}"></button>`).join("") +
    '<span class="sep"></span><button type="button" data-a="undo" title="Undo (Ctrl/Cmd+Z)">↶ Undo</button><button type="button" data-a="clear" title="Clear all drawings">Clear</button><button type="button" class="done" data-a="done">Done</button>';
  document.body.appendChild(bar);
  const paint = () => { bar.querySelectorAll("[data-t]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.t === tool)));
    bar.querySelectorAll("[data-c]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.c === col))); document.body.classList.toggle("erasing", tool === "erase"); };
  const setOn = v => { on = v; bar.hidden = !v; document.body.classList.toggle("drawing", v); btn.setAttribute("aria-pressed", String(v)); paint(); };
  bar.addEventListener("click", e => { e.stopPropagation(); const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.t) tool = b.dataset.t; else if (b.dataset.c) { col = b.dataset.c; if (tool === "erase") tool = "pen"; }
    else if (b.dataset.a === "undo") { shapes.pop(); redraw(); save(); } else if (b.dataset.a === "clear") { if (shapes.length && confirm("Clear all drawings on this page?")) { shapes = []; redraw(); save(); } }
    else if (b.dataset.a === "done") setOn(false);
    paint(); });
  const btn = document.createElement("button"); btn.type = "button"; btn.title = "Draw on the page (D)"; btn.textContent = "✎ Draw"; btn.setAttribute("aria-pressed", "false");
  const rbar = document.querySelector(".rbar"), edit = document.getElementById("bEdit"); edit ? edit.before(btn) : rbar?.append(btn);
  btn.onclick = e => { e.stopPropagation(); setOn(!on); };

  // ---- drawing ----
  const pt = e => { const r = svg.getBoundingClientRect(), s = BASE / r.width; return [+((e.clientX - r.left) * s).toFixed(1), +((e.clientY - r.top) * s).toFixed(1)]; };
  svg.addEventListener("pointerdown", e => {
    if (!on) return; e.preventDefault(); e.stopPropagation();
    if (tool === "erase") { const i = e.target.dataset?.i; if (i != null && e.target !== svg) { shapes.splice(+i, 1); redraw(); save(); } return; }
    const p = pt(e); svg.setPointerCapture(e.pointerId);
    cur = tool === "pen" || tool === "hl" ? { t: tool, c: col, p: [p] } : { t: tool, c: col, a: p, b: p };
    shapes.push(cur); let el = draw(cur);
    const move = ev => { const q = pt(ev); if (cur.p) cur.p.push(q); else cur.b = q; el.remove(); el = draw(cur); };
    const up = () => { svg.removeEventListener("pointermove", move); svg.removeEventListener("pointerup", up); svg.removeEventListener("pointercancel", up);
      const tiny = cur.p ? cur.p.length < 2 : Math.hypot(cur.a[0] - cur.b[0], cur.a[1] - cur.b[1]) < 6;
      if (tiny) { shapes.pop(); redraw(); } else save(); cur = null; };
    svg.addEventListener("pointermove", move); svg.addEventListener("pointerup", up); svg.addEventListener("pointercancel", up);
  });
  document.addEventListener("click", e => { if (on && svg.contains(e.target)) e.stopPropagation(); }, true);
  document.addEventListener("keydown", e => {
    if (e.target.isContentEditable || /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
    const key = e.key.toLowerCase();
    if (!on) { if (key === "d" && !e.metaKey && !e.ctrlKey && !e.altKey) { e.preventDefault(); setOn(true); } return; }
    if ((e.metaKey || e.ctrlKey) && key === "z") { e.preventDefault(); e.stopPropagation(); shapes.pop(); redraw(); save(); return; }
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    const map = { p: "pen", h: "hl", a: "arrow", r: "rect", o: "ellipse", e: "erase" };
    if (map[key]) { tool = map[key]; paint(); e.preventDefault(); e.stopPropagation(); }
    else if (/^[1-6]$/.test(key)) { col = COLS[+key - 1]; paint(); e.preventDefault(); e.stopPropagation(); }
    else if (key === "escape") { setOn(false); e.preventDefault(); }
  }, true);

  // ---- save / load ----
  window.claude?.use?.("artifact").then(a => { art = a; }).catch(() => {});
  const fresh = () => fetch("edits.json", { cache: "no-store" }).then(r => r.ok ? r.json() : {}).catch(() => ({}));
  const readLocal = () => { try { return JSON.parse(localStorage.getItem(LKEY) || "{}") || {}; } catch (e) { return {}; } };
  let saveT = 0;
  function save() { clearTimeout(saveT); saveT = setTimeout(async () => {
    if (art) { try { const c = await fresh(); await art.publish({ "edits.json": JSON.stringify({ ...c, [KEY]: shapes }, null, 1) }); return; }
      catch (e) { if (!["not_writer", "not_granted", "capability_disabled", "not_declared", "consent_required"].includes(e?.code)) return; art = null; } }
    const l = readLocal(); l[KEY] = shapes; try { localStorage.setItem(LKEY, JSON.stringify(l)); } catch (e) {}
  }, 500); }
  fresh().then(j => { const l = readLocal(); const s = Array.isArray(l[KEY]) ? l[KEY] : Array.isArray(j[KEY]) ? j[KEY] : []; shapes = s; redraw(); });
})();
