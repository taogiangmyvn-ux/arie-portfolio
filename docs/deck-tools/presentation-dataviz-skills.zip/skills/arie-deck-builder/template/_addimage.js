/* ---- add images to a report (the "+ Image" button, or drop / paste an image file on a card) ----
   The image lands in the card you dropped it on, or the card nearest the middle of the screen. Drag it to move
   (drop it on another card to move it there), drag the round corner to resize, × or Delete removes it.
   Double-click it for the crop tools (crop, zoom, shape, frame, replace, undo) from _imgcrop.js.
   Saved like the other edits: on the claude.ai link into edits.json (everyone sees it), elsewhere in this browser.
   Key "added:r" = [{id, c: card index, src, l, t, w}] with l/t/w in % of the card size. Photos are shrunk to
   1400px so the saved file stays small. Not baked by bake_edits.py: add the photo to the source if it should stay. ---- */
(() => {
  const rpt = document.getElementById("rpt"); if (!rpt) return;
  const LKEY = "deck-edits:" + document.title, KEY = "added:r";
  const cards = () => [...rpt.querySelectorAll(".card")];
  const css = document.createElement("style");
  css.textContent = `.addimg{position:absolute;z-index:5;margin:0;cursor:move;touch-action:none;user-select:none;overflow:hidden;border-radius:10px;box-shadow:0 10px 26px rgba(0,0,0,.18)}
.addimg img{display:block;width:100%;height:auto;pointer-events:none}
.addimg .rs,.addimg .rm{display:none;position:absolute;z-index:2}
.addimg .rs{right:6px;bottom:6px;width:18px;height:18px;border-radius:50%;background:#FFE14D;border:3px solid #1B2631;cursor:nwse-resize}
.addimg .rm{all:unset;display:none;position:absolute;right:6px;top:6px;width:28px;height:28px;border-radius:50%;background:#1B2631;color:#fff;font:600 18px/28px system-ui,sans-serif;text-align:center;cursor:pointer}
.addimg.sel{outline:3px solid #FFE14D;outline-offset:2px;overflow:visible}.addimg.sel .rs,.addimg.sel .rm{display:block}
body.addimg-drop .card{outline:2px dashed #C9A57E;outline-offset:4px}
@media print{.addimg .rs,.addimg .rm{display:none!important}.addimg{outline:none!important}}`;
  document.head.appendChild(css);

  const btn = document.createElement("button"); btn.type = "button"; btn.title = "Add an image (or drop / paste one on a card)"; btn.textContent = "+ Image";
  const bar = document.querySelector(".rbar"); (document.getElementById("bEdit") || null) ? document.getElementById("bEdit").before(btn) : bar?.append(btn);
  const file = document.createElement("input"); file.type = "file"; file.accept = "image/*"; file.multiple = true; file.hidden = true; document.body.appendChild(file);

  let list = [], sel = null, art = null, target = null;
  window.claude?.use?.("artifact").then(a => { art = a; }).catch(() => {});
  const fresh = () => fetch("edits.json", { cache: "no-store" }).then(r => r.ok ? r.json() : {}).catch(() => ({}));
  const readLocal = () => { try { return JSON.parse(localStorage.getItem(LKEY) || "{}") || {}; } catch (e) { return {}; } };
  const toast = t => { const d = document.createElement("div"); d.className = "croptoast"; d.textContent = t;
    Object.assign(d.style, { position: "fixed", left: "50%", bottom: "24px", transform: "translateX(-50%)", zIndex: 71, background: "#1B2631", color: "#E6ECF0", padding: "10px 16px", borderRadius: "10px", font: "500 13px system-ui,sans-serif" });
    document.body.appendChild(d); setTimeout(() => d.remove(), 2600); };

  let saveT = 0;
  function save() { clearTimeout(saveT); saveT = setTimeout(async () => {
    list = [...rpt.querySelectorAll(".addimg")].map(f => { const c = f.parentElement, cw = c.offsetWidth || 1, ch = c.offsetHeight || 1;
      return { id: f.dataset.id, c: cards().indexOf(c), src: f.querySelector("img").getAttribute("src"),
        l: +(f.offsetLeft / cw * 100).toFixed(2), t: +(f.offsetTop / ch * 100).toFixed(2), w: +(f.offsetWidth / cw * 100).toFixed(2) }; });
    if (art) {
      try { const cur = await fresh(); await art.publish({ "edits.json": JSON.stringify({ ...cur, [KEY]: list }, null, 1) }); toast("Image saved. Everyone with the link sees it."); return; }
      catch (e) { if (!["not_writer", "not_granted", "capability_disabled", "not_declared", "consent_required"].includes(e?.code)) { toast("Could not save the image. Try again."); return; } art = null; }
    }
    const local = readLocal(); local[KEY] = list;
    try { localStorage.setItem(LKEY, JSON.stringify(local)); toast("Image saved in this browser."); } catch (e) { toast("Too big to save in this browser. Use a smaller photo."); }
  }, 400); }

  function place(card, m) {
    const f = document.createElement("figure"); f.className = "addimg"; f.tabIndex = 0; f.dataset.id = m.id;
    const img = new Image(); img.alt = "Added image"; img.draggable = false; img.src = m.src;
    const rs = document.createElement("span"); rs.className = "rs"; rs.title = "Drag to resize";
    const rm = document.createElement("button"); rm.className = "rm"; rm.type = "button"; rm.textContent = "×"; rm.title = "Remove (Delete)";
    rm.onclick = e => { e.stopPropagation(); remove(f); };
    f.append(img, rs, rm); Object.assign(f.style, { left: m.l + "%", top: m.t + "%", width: m.w + "%" });
    if (getComputedStyle(card).position === "static") card.style.position = "relative";
    card.appendChild(f);
    window.imageCrops?.adopt?.(img, "img:add:" + m.id);
    return f;
  }
  function remove(f) { window.imageCrops?.forget?.("img:add:" + f.dataset.id); if (sel === f) sel = null; f.remove(); save(); }
  const select = f => { sel?.classList.remove("sel"); sel = f || null; sel?.classList.add("sel"); };

  function shrink(fl) { return new Promise(res => { const r = new FileReader(); r.onload = () => { const im = new Image(); im.onload = () => {
    const s = Math.min(1, 1400 / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement("canvas");
    c.width = Math.round(im.naturalWidth * s); c.height = Math.round(im.naturalHeight * s); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
    res({ src: fl.type === "image/png" ? c.toDataURL("image/png") : c.toDataURL("image/jpeg", .85), ratio: c.height / c.width }); }; im.src = r.result; }; r.readAsDataURL(fl); }); }
  const middleCard = () => { let best = null, bd = 1e9; cards().forEach(c => { const r = c.getBoundingClientRect(); if (r.bottom < 0 || r.top > innerHeight) return;
    const d = Math.abs(r.top + r.height / 2 - innerHeight / 2); if (d < bd) { bd = d; best = c; } }); return best || cards()[0]; };
  async function add(files, card, at) {
    card = card || middleCard(); if (!card) return;
    for (const fl of [...files].filter(x => /^image\//.test(x.type))) {
      const { src, ratio } = await shrink(fl), r = card.getBoundingClientRect();
      let w = Math.min(30, 300 / r.width * 100); if (w * r.width / 100 * ratio > r.height * .8) w = r.height * .8 / ratio / r.width * 100;   // fit inside the card
      const hPct = w * r.width / 100 * ratio / r.height * 100;
      const l = at ? (at.x - r.left) / r.width * 100 - w / 2 : 50 - w / 2, t = at ? (at.y - r.top) / r.height * 100 - hPct / 2 : 50 - hPct / 2;
      select(place(card, { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5), src, l: Math.max(0, l), t: Math.max(0, t), w }));
    }
    save();
  }

  btn.onclick = e => { e.stopPropagation(); target = middleCard(); file.click(); };
  file.onchange = () => { if (file.files.length) add(file.files, target); file.value = ""; };
  // drop a file on a card (an existing photo in the card is replaced by the crop tool instead)
  rpt.addEventListener("dragover", e => { if ([...(e.dataTransfer?.types || [])].includes("Files")) { e.preventDefault(); document.body.classList.add("addimg-drop"); } });
  rpt.addEventListener("dragleave", e => { if (!rpt.contains(e.relatedTarget)) document.body.classList.remove("addimg-drop"); });
  rpt.addEventListener("drop", e => { document.body.classList.remove("addimg-drop"); const c = e.target.closest(".card"); if (!c || !e.dataTransfer?.files?.length) return; e.preventDefault(); add(e.dataTransfer.files, c, { x: e.clientX, y: e.clientY }); });
  document.addEventListener("paste", e => {
    if (window.imageCrops?.isCropping?.() || e.target.isContentEditable || /INPUT|TEXTAREA/.test(e.target.tagName)) return;
    const fs = [...(e.clipboardData?.files || [])]; if (!fs.some(x => /^image\//.test(x.type))) return; e.preventDefault(); add(fs);
  });

  // move / resize; dropping on another card moves the image there
  rpt.addEventListener("pointerdown", e => {
    const f = e.target.closest(".addimg"); if (!f) return select(null);
    if (e.target.closest(".rm") || window.imageCrops?.isCropping?.()) return;
    e.preventDefault(); select(f); f.setPointerCapture(e.pointerId);
    const resize = e.target.classList.contains("rs"), sx = e.clientX, sy = e.clientY, l = f.offsetLeft, t = f.offsetTop, w = f.offsetWidth;
    const move = ev => { const dx = ev.clientX - sx, dy = ev.clientY - sy;
      if (resize) f.style.width = Math.max(60, w + dx) + "px"; else { f.style.left = l + dx + "px"; f.style.top = t + dy + "px"; } };
    const up = ev => { f.removeEventListener("pointermove", move); f.removeEventListener("pointerup", up); f.removeEventListener("pointercancel", up);
      if (!resize) { f.style.visibility = "hidden"; const under = document.elementFromPoint(ev.clientX, ev.clientY)?.closest(".card"); f.style.visibility = "";
        if (under && under !== f.parentElement) { const r = under.getBoundingClientRect(), fr = f.getBoundingClientRect(); under.appendChild(f);
          f.style.left = fr.left - r.left + "px"; f.style.top = fr.top - r.top + "px"; } }
      save(); };
    f.addEventListener("pointermove", move); f.addEventListener("pointerup", up); f.addEventListener("pointercancel", up);
  });
  document.addEventListener("keydown", e => { if (!sel || e.target.isContentEditable || /INPUT|TEXTAREA/.test(e.target.tagName)) return;
    if (e.key === "Delete" || e.key === "Backspace") { e.preventDefault(); remove(sel); } else if (e.key === "Escape") select(null); });

  // restore: edits.json first, this browser's copy wins
  fresh().then(j => { const loc = readLocal(); const saved = Array.isArray(loc[KEY]) ? loc[KEY] : Array.isArray(j[KEY]) ? j[KEY] : [];
    const cs = cards(); saved.forEach(m => cs[m.c] && place(cs[m.c], m)); });
})();
