/* ---- text style bar (shows while Edit text / W is on and a text block has focus): font, size, colour,
   highlight, bold / italic / underline, align, clear. With text selected it styles the selection; with only a caret
   it styles the whole block. Every change goes through the browser's insertHTML / execCommand, so Ctrl/Cmd+Z and
   Ctrl/Cmd+Shift+Z undo and redo it like typing, and the edit-text saver picks it up as an ordinary text edit
   (inline <span style> with allow-listed properties, plus <b> <i> <u>). Fonts outside the theme load from Google Fonts
   on demand, also when a saved edit uses them. Keep FONTS in step with FONTS in scripts/bake_edits.py. ---- */
(() => {
  const stage = document.getElementById("stage"), rpt = document.getElementById("rpt");
  const roots = stage ? [...stage.querySelectorAll(":scope > .slide")] : rpt ? [rpt] : [];
  if (!roots.length) return;
  const inRoots = n => roots.some(r => r.contains(n));
  const FONTS = [   // [label, css family, google family or ""]
    ["Heading (theme)", "var(--display)", ""], ["Body (theme)", "var(--body)", ""],
    ["Sen (CoBa brand)", "'Sen', sans-serif", "Sen:wght@400;500;600;700;800"], ["Playfair Display (CoBa brand)", "'Playfair Display', serif", "Playfair+Display:ital,wght@0,400;0,700;1,400"],
    ["Inter", "'Inter', sans-serif", "Inter:wght@400;600;700"], ["Montserrat", "'Montserrat', sans-serif", "Montserrat:wght@400;600;800"],
    ["Poppins", "'Poppins', sans-serif", "Poppins:wght@400;600;700"], ["Be Vietnam Pro", "'Be Vietnam Pro', sans-serif", "Be+Vietnam+Pro:wght@400;600;700"],
    ["Space Grotesk", "'Space Grotesk', sans-serif", "Space+Grotesk:wght@400;600;700"], ["Bebas Neue", "'Bebas Neue', sans-serif", "Bebas+Neue"],
    ["DM Serif Display", "'DM Serif Display', serif", "DM+Serif+Display:ital@0;1"],
    ["Cormorant Garamond", "'Cormorant Garamond', serif", "Cormorant+Garamond:ital,wght@0,400;0,600;1,400"], ["Lora", "'Lora', serif", "Lora:ital,wght@0,400;0,600;1,400"],
    ["Caveat", "'Caveat', cursive", "Caveat:wght@400;700"], ["Courier", "'Courier Prime', monospace", "Courier+Prime"],
  ];
  const loaded = new Set();
  function loadFont(css) {
    const norm = v => String(v || "").replace(/["'\s]/g, "").toLowerCase();
    const f = FONTS.find(x => css && norm(css).startsWith(norm(x[1].split(",")[0]))); if (!f || !f[2] || loaded.has(f[2])) return;
    loaded.add(f[2]); const l = document.createElement("link"); l.rel = "stylesheet"; l.href = `https://fonts.googleapis.com/css2?family=${f[2]}&display=swap`; document.head.appendChild(l);
  }
  // saved edits may use a font this page has not loaded yet
  const scan = () => roots.forEach(r => r.querySelectorAll("[style*='font-family']").forEach(n => loadFont(n.style.fontFamily)));
  let scanT = 0; new MutationObserver(() => { clearTimeout(scanT); scanT = setTimeout(scan, 120); }).observe(stage || rpt, { subtree: true, childList: true }); scan();

  const vars = getComputedStyle(document.body);
  const SW = ["--ink", "--muted", "--accent", "--accent-2", "--accent2", "--p", "--s", "--hl", "--paper", "--bg"]
    .filter(v => vars.getPropertyValue(v).trim() && /^#|^rgb|^hsl|^oklch/.test(vars.getPropertyValue(v).trim())).map(v => [`var(${v})`, vars.getPropertyValue(v).trim()]);
  const FIXED = ["#111111", "#FFFFFF", "#E8552D", "#2F6FED", "#1F9D55", "#F2B705", "#8E44AD"];

  const css = document.createElement("style");
  css.textContent = `.stylebar{position:fixed;z-index:72;display:flex;flex-wrap:wrap;align-items:center;gap:4px;max-width:min(720px,calc(100vw - 16px));background:#1B2631;color:#E6ECF0;border-radius:12px;padding:6px 8px;font:500 13px/1.2 system-ui,sans-serif;box-shadow:0 14px 36px rgba(0,0,0,.35)}
.stylebar button{all:unset;cursor:pointer;min-width:18px;text-align:center;padding:6px 8px;border-radius:7px}.stylebar button:hover{background:rgba(255,255,255,.12)}.stylebar button[aria-pressed="true"]{background:#FFE14D;color:#111}
.stylebar button:focus-visible{outline:2px solid #FFE14D}.stylebar .sep{width:1px;height:20px;background:rgba(255,255,255,.18);margin:0 3px}
.stylebar select{all:unset;cursor:pointer;padding:6px 8px;border-radius:7px;background:rgba(255,255,255,.1);max-width:150px}.stylebar select option{color:#111;background:#fff}
.stylebar input[type=number]{width:44px;background:rgba(255,255,255,.1);color:inherit;border:0;border-radius:7px;padding:6px 4px;text-align:center;font:inherit}
.stylebar .chip{display:inline-block;width:14px;height:4px;border-radius:2px;margin-top:2px}
.stylepop{position:fixed;z-index:73;display:grid;grid-template-columns:repeat(7,24px);gap:6px;background:#1B2631;padding:10px;border-radius:10px;box-shadow:0 14px 36px rgba(0,0,0,.35);font:500 12px system-ui,sans-serif;color:#E6ECF0}
.stylepop button{all:unset;cursor:pointer;width:24px;height:24px;border-radius:50%;border:2px solid rgba(255,255,255,.35);box-sizing:border-box}.stylepop button:hover{border-color:#FFE14D}
.stylepop .wide{grid-column:1/-1;display:flex;gap:8px;align-items:center;justify-content:space-between}.stylepop .wide button{width:auto;height:auto;border-radius:6px;padding:4px 8px;background:rgba(255,255,255,.12);border:0}
.stylepop input[type=color]{width:34px;height:24px;border:0;padding:0;background:none;cursor:pointer}`;
  document.head.appendChild(css);

  const bar = document.createElement("div"); bar.className = "stylebar"; bar.hidden = true; bar.setAttribute("role", "toolbar"); bar.setAttribute("aria-label", "Text style");
  bar.innerHTML = `<select aria-label="Font" title="Font"><option value="">Font</option>${FONTS.map((f, i) => `<option value="${i}">${f[0]}</option>`).join("")}</select>
<button type="button" data-a="dn" title="Smaller" aria-label="Smaller">A−</button><input type="number" min="6" max="400" aria-label="Font size (px)" title="Font size (px)"><button type="button" data-a="up" title="Bigger" aria-label="Bigger">A+</button>
<span class="sep"></span><button type="button" data-a="bold" title="Bold (Ctrl/Cmd+B)"><b>B</b></button><button type="button" data-a="italic" title="Italic (Ctrl/Cmd+I)"><i>I</i></button><button type="button" data-a="underline" title="Underline (Ctrl/Cmd+U)"><u>U</u></button>
<span class="sep"></span><button type="button" data-a="color" title="Text colour">A<br><span class="chip"></span></button><button type="button" data-a="hl" title="Highlight">▮<br><span class="chip" style="background:#FFE14D"></span></button>
<span class="sep"></span><button type="button" data-a="left" title="Align left">⇤</button><button type="button" data-a="center" title="Align centre">≡</button><button type="button" data-a="right" title="Align right">⇥</button>
<span class="sep"></span><button type="button" data-a="clear" title="Clear formatting">⌫ Clear</button>`;
  document.body.appendChild(bar);
  const fontSel = bar.querySelector("select"), sizeIn = bar.querySelector("input"), colorChip = bar.querySelector('[data-a="color"] .chip');
  let host = null, saved = null, pop = null;   // host = the text block being edited, saved = its last selection

  const editable = n => { const e = n && (n.nodeType === 1 ? n : n.parentElement); const h = e && e.closest('[contenteditable="true"]'); return h && inRoots(h) ? h : null; };
  document.addEventListener("selectionchange", () => {
    const s = getSelection(); if (!s.rangeCount) return; const h = editable(s.anchorNode); if (!h) return;
    host = h; saved = s.getRangeAt(0).cloneRange(); show();
  });
  document.addEventListener("focusin", e => { const h = editable(e.target); if (h) { host = h; show(); } });
  document.addEventListener("focusout", () => setTimeout(() => { const a = document.activeElement; if (!editable(a) && !bar.contains(a) && !pop?.contains(a)) hide(); }, 0));
  new MutationObserver(() => { if (!document.body.classList.contains("editing")) hide(); }).observe(document.body, { attributes: true, attributeFilter: ["class"] });

  function show() {
    if (!host || !document.body.classList.contains("editing")) return;
    bar.hidden = false; place(); paint();
  }
  function hide() { bar.hidden = true; closePop(); }
  function place() {
    if (bar.hidden || !host) return; const r = host.getBoundingClientRect(), w = bar.offsetWidth, h = bar.offsetHeight;
    let top = r.top - h - 12; if (top < 8) top = Math.min(innerHeight - h - 8, r.bottom + 12);
    bar.style.left = Math.max(8, Math.min(innerWidth - w - 8, r.left + r.width / 2 - w / 2)) + "px"; bar.style.top = top + "px";
  }
  function paint() {
    const n = saved ? (saved.startContainer.nodeType === 1 ? saved.startContainer : saved.startContainer.parentElement) : host; if (!n) return;
    const cs = getComputedStyle(n); sizeIn.value = Math.round(parseFloat(cs.fontSize));
    colorChip.style.background = cs.color;
    const fam = cs.fontFamily.replace(/["']/g, "").split(",")[0].trim().toLowerCase();
    const i = FONTS.findIndex(f => f[1].replace(/["']/g, "").split(",")[0].trim().toLowerCase() === fam); fontSel.value = i > 1 ? String(i) : "";
    ["bold", "italic", "underline"].forEach(c => { let on = false; try { on = document.queryCommandState(c); } catch (e) {} bar.querySelector(`[data-a="${c}"]`).setAttribute("aria-pressed", String(on)); });
    const al = getComputedStyle(host.querySelector(":scope > span[data-align]") || host).textAlign;
    ["left", "center", "right"].forEach(a => bar.querySelector(`[data-a="${a}"]`).setAttribute("aria-pressed", String(al === a || (a === "left" && al === "start"))));
  }

  // put the caret / selection back in the block (a <select> or colour input took focus)
  function restore() {
    if (!host) return null; host.focus({ preventScroll: true });
    const s = getSelection(); s.removeAllRanges();
    if (saved && host.contains(saved.commonAncestorContainer)) s.addRange(saved); else { const r = document.createRange(); r.selectNodeContents(host); r.collapse(false); s.addRange(r); }
    return s;
  }
  // with only a caret, act on the whole block
  function target() {
    const s = restore(); if (!s) return null;
    if (s.isCollapsed) { const r = document.createRange(); r.selectNodeContents(host); s.removeAllRanges(); s.addRange(r); return { s, whole: true }; }
    return { s, whole: false };
  }
  const esc = t => t.replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  // wrap the selection in <span style="prop:val">, dropping the same property inside it so the new value wins
  function wrap(prop, val) {
    const t = target(); if (!t) return;
    const r = t.s.getRangeAt(0);
    // a selection that covers a whole styled element (the word styled a moment ago) must take the element along,
    // or insertHTML drops it and its earlier styles with it
    for (let i = 0; i < 8; i++) {
      const c = r.commonAncestorContainer, el = c.nodeType === 1 ? c : c.parentElement;
      if (!el || el === host || !host.contains(el)) break;
      const full = document.createRange(); full.selectNodeContents(el);
      if (r.compareBoundaryPoints(Range.START_TO_START, full) > 0 || r.compareBoundaryPoints(Range.END_TO_END, full) < 0) break;
      r.setStartBefore(el); r.setEndAfter(el);
    }
    t.s.removeAllRanges(); t.s.addRange(r);
    const box = document.createElement("div"); box.appendChild(r.cloneContents());
    box.querySelectorAll("[style]").forEach(n => { n.style.removeProperty(prop); if (!n.getAttribute("style").trim()) n.removeAttribute("style"); });
    box.querySelectorAll("span:not([style]):not([class])").forEach(n => n.replaceWith(...n.childNodes));
    if (!box.textContent.trim() && !box.querySelector("br")) return;
    document.execCommand("insertHTML", false, val ? `<span style="${prop}:${esc(val)}">${box.innerHTML}</span>` : box.innerHTML);
    if (!t.whole && val) {   // keep the styled words selected, so the next change applies to them too
      const s = getSelection(), a = s.anchorNode, o = s.anchorOffset;
      // the caret ends up inside the new span's last text, or just after the span
      let n = a && (a.nodeType === 3 ? (o === 0 ? a.previousSibling : a.parentElement) : a.childNodes[o - 1]);
      if (n && n.nodeType === 1 && !(n.tagName === "SPAN" && n.style.getPropertyValue(prop))) n = n.closest?.("span[style]");
      if (n && !host.contains(n)) n = null;
      if (n && n.nodeType === 1 && n.tagName === "SPAN") { unNbsp(); const r = document.createRange(); r.selectNodeContents(n); s.removeAllRanges(); s.addRange(r); saved = r.cloneRange(); }
    }
    after(t.whole);
  }
  // insertHTML turns the spaces around the new span into &nbsp;, which stops the line from wrapping there:
  // put plain spaces back at span edges (same length, so the undo stack stays valid)
  function unNbsp() {
    const fix = (t, end) => { if (!t || t.nodeType !== 3) return; const d = t.data, i = end ? d.length - 1 : 0; if (d[i] === " ") t.data = d.slice(0, i) + " " + d.slice(i + 1); };
    host.querySelectorAll("span[style],b,i,u").forEach(s => { fix(s.previousSibling, true); fix(s.nextSibling, false); fix(s.firstChild, false); fix(s.lastChild, true); });
  }
  function after(whole) {
    unNbsp();
    if (whole) { const s = getSelection(), r = document.createRange(); r.selectNodeContents(host); r.collapse(false); s.removeAllRanges(); s.addRange(r); }
    host.dispatchEvent(new Event("input", { bubbles: true }));   // let the edit-text saver count it (insertHTML already fires one; harmless twice)
    setTimeout(() => { place(); paint(); }, 0);
  }
  function cmd(c) { const t = target(); if (!t) return; document.execCommand("styleWithCSS", false, false); document.execCommand(c); after(t.whole); }
  // align is a block property: wrap the whole block in one <span data-align style="display:block;text-align:…">
  function align(a) {
    const s = restore(); if (!s) return; const r = document.createRange(); r.selectNodeContents(host); s.removeAllRanges(); s.addRange(r);
    const cur = host.querySelector(":scope > span[data-align]"), inner = cur && host.childNodes.length === 1 ? cur.innerHTML : host.innerHTML;
    document.execCommand("insertHTML", false, a ? `<span data-align style="display:block;text-align:${a}">${inner}</span>` : inner);
    after(true);
  }
  function size(px) { px = Math.max(6, Math.min(400, Math.round(px))); sizeIn.value = px; wrap("font-size", px + "px"); }

  bar.addEventListener("pointerdown", e => { if (e.target.closest("button")) e.preventDefault(); });   // keep the text selection
  bar.addEventListener("click", e => {
    e.stopPropagation(); const b = e.target.closest("button"); if (!b) return; const a = b.dataset.a;
    if (a === "up" || a === "dn") return size((+sizeIn.value || 16) * (a === "up" ? 1.12 : 1 / 1.12));
    if (a === "bold" || a === "italic" || a === "underline") return cmd(a);
    if (a === "left" || a === "center" || a === "right") return align(a);
    if (a === "clear") { const t = target(); if (!t) return; const plain = esc(t.s.toString()).replace(/\n/g, "<br>"); document.execCommand("insertHTML", false, plain); return after(t.whole); }
    if (a === "color" || a === "hl") return palette(b, a === "color" ? "color" : "background-color");
  });
  fontSel.addEventListener("change", () => { const f = FONTS[+fontSel.value]; if (!f) return; loadFont(f[1]); wrap("font-family", f[1]); });
  sizeIn.addEventListener("change", () => size(+sizeIn.value || 16));
  sizeIn.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Enter") { e.preventDefault(); size(+sizeIn.value || 16); } });

  function closePop() { pop?.remove(); pop = null; }
  function palette(anchor, prop) {
    closePop(); pop = document.createElement("div"); pop.className = "stylepop";
    const all = [...SW, ...FIXED.map(c => [c, c])];
    pop.innerHTML = all.map(([v, c]) => `<button type="button" title="${esc(v)}" data-v="${esc(v)}" style="background:${esc(c)}"></button>`).join("") +
      `<div class="wide"><label>Custom <input type="color" value="#E8552D"></label><button type="button" data-v="">${prop === "color" ? "Default" : "None"}</button></div>`;
    document.body.appendChild(pop);
    const r = anchor.getBoundingClientRect(); pop.style.left = Math.max(8, Math.min(innerWidth - pop.offsetWidth - 8, r.left)) + "px";
    pop.style.top = (r.bottom + 8 + pop.offsetHeight > innerHeight ? r.top - pop.offsetHeight - 8 : r.bottom + 8) + "px";
    pop.addEventListener("pointerdown", e => { if (e.target.closest("button")) e.preventDefault(); });
    pop.addEventListener("click", e => { e.stopPropagation(); const b = e.target.closest("button"); if (!b) return; wrap(prop, b.dataset.v); closePop(); });
    pop.querySelector("input").addEventListener("change", e => { wrap(prop, e.target.value); closePop(); });
    pop.addEventListener("keydown", e => { e.stopPropagation(); if (e.key === "Escape") { closePop(); restore(); } });
  }
  // Ctrl+Z / Cmd+Z (and Ctrl+Shift+Z, Cmd+Shift+Z, Ctrl+Y) in a text block: the browser's own undo stack, which holds
  // typing and every style change above. Handled here so Ctrl+Z works on a Mac too.
  document.addEventListener("keydown", e => {
    const k = e.key.toLowerCase(); if (!(e.metaKey || e.ctrlKey) || e.altKey || (k !== "z" && k !== "y")) return;
    if (!editable(e.target)) return;
    e.preventDefault(); e.stopPropagation();
    host = editable(e.target); document.execCommand(k === "y" || e.shiftKey ? "redo" : "undo"); unNbsp();
    setTimeout(() => { place(); paint(); }, 0);
  }, true);
  document.addEventListener("pointerdown", e => { if (pop && !pop.contains(e.target) && !bar.contains(e.target)) closePop(); }, true);
  addEventListener("resize", place); addEventListener("scroll", place, true);
  window.textStyle = { FONTS, loadFont, wrap };
})();
