"""Prepare the user's photo set for a deck.

Resizes every image to max 1920 px on the long side, converts to JPEG (PNG kept when it has transparency),
writes them to <deck_dir>/img/, and prints a manifest Claude uses to pick layout slots.

    python3 prep_images.py path/to/photos_folder path/to/deck_dir

Manifest columns: file, orientation (landscape / portrait / square), width x height, KB.
Landscape -> L3 photo block, L10 side, half-bleed. Portrait -> L9 people, tall strips. Square -> cards.
"""
import sys, pathlib
from PIL import Image, ImageOps

EXT = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".tif", ".tiff"}

def main(src, deck):
    out = pathlib.Path(deck) / "img"; out.mkdir(parents=True, exist_ok=True)
    rows = []
    for p in sorted(pathlib.Path(src).iterdir()):
        if p.suffix.lower() not in EXT:
            continue
        try:
            im = ImageOps.exif_transpose(Image.open(p))
        except Exception as e:
            print(f"skip {p.name}: {e}"); continue
        im.thumbnail((1920, 1920))
        alpha = im.mode in ("RGBA", "LA") and im.getextrema()[-1][0] < 255
        name = p.stem.lower().replace(" ", "-") + (".png" if alpha else ".jpg")
        dst = out / name
        (im if alpha else im.convert("RGB")).save(dst, quality=82, optimize=True)
        w, h = im.size; r = w / h
        orient = "landscape" if r > 1.15 else "portrait" if r < 0.87 else "square"
        rows.append((name, orient, f"{w}x{h}", dst.stat().st_size // 1024))
    print(f"{'file':40} {'orientation':11} {'size':>10} {'KB':>5}")
    for n, o, s, kb in rows:
        print(f"img/{n:36} {o:11} {s:>10} {kb:>5}")
    print(f"\n{len(rows)} images -> {out}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    main(*sys.argv[1:])
