// Capture a deck as layers for the editable PPTX export.
// For every slide: the text blocks (position, runs, style, real line breaks), a screenshot with text (reference)
// and a screenshot with the text hidden (the design layer that becomes the locked slide background).
// usage: node _capture_layers.mjs <page_url> <out_dir> [scale=2]
import { spawn } from "node:child_process";
import { mkdirSync, writeFileSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";

const [url, out, scaleArg = "2"] = process.argv.slice(2);
const SCALE = +scaleArg;
mkdirSync(out, { recursive: true });
const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const port = 9600 + Math.floor(Math.random() * 300);
const prof = join(tmpdir(), "deck-layers-" + port);
const chrome = spawn(CHROME, ["--headless=new", `--remote-debugging-port=${port}`, `--user-data-dir=${prof}`, "--hide-scrollbars", "--no-first-run", "about:blank"], { stdio: "ignore" });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let target;
for (let i = 0; i < 80 && !target; i++) { try { target = (await (await fetch(`http://127.0.0.1:${port}/json`)).json()).find(x => x.type === "page"); } catch {} if (!target) await sleep(250); }
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise(r => ws.addEventListener("open", r));
let id = 0; const pend = new Map();
ws.addEventListener("message", e => { const m = JSON.parse(e.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m); pend.delete(m.id); } });
const send = (method, params = {}) => new Promise(r => { const i = ++id; pend.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
const ev = async expr => { const m = await send("Runtime.evaluate", { expression: expr, awaitPromise: true, returnByValue: true }); if (m.result?.exceptionDetails) throw new Error(JSON.stringify(m.result.exceptionDetails).slice(0, 800)); return m.result?.result?.value; };

await send("Emulation.setDeviceMetricsOverride", { width: 1600, height: 900, deviceScaleFactor: SCALE, mobile: false });
await send("Page.enable");
await send("Page.navigate", { url });
for (let i = 0; i < 120; i++) { if (await ev("document.readyState === 'complete'").catch(() => false)) break; await sleep(250); }
console.log("loaded");
// Show every build step and hide the deck UI. (Copying the deck's @media print rules made headless screenshots stall.)
if (!process.env.NOSTEP) await ev(`(() => { const st = document.createElement("style"); st.textContent = "[data-step]{opacity:1!important;transform:none!important;transition:none!important} .bar-c i{height:var(--h)!important;transition:none!important} .bar,.progress,.overview,.help,#ink,.editbar,.tagpin,.cmtpin,.toast{display:none!important} *{transition:none!important;animation:none!important}"; document.head.appendChild(st); return 1; })()`);
await ev(`(async () => { document.querySelectorAll("img[loading=lazy]").forEach(i => i.loading = "eager");
  const wait = Promise.all([document.fonts.ready, ...[...document.images].filter(i => !i.complete).map(i => new Promise(r => { i.onload = i.onerror = r; }))]);
  await Promise.race([wait, new Promise(r => setTimeout(r, 8000))]); await new Promise(r => setTimeout(r, 1200)); return 1; })()`);
console.log("ready");

// Same list the in-page text editor uses (EDIT_SEL), so editable PPTX text = editable deck text.
const extract = idx => `(() => {
  const SEL = "h1,h2,h3,p,li,td,th,dt,dd,.num,.lbl,.kicker,.year,.role,.pill,.badge,.tag,.delta,.card-h,.no,.tab,div.quote";
  const px = v => parseFloat(v) || 0;
  const rgb = c => { const m = c.match(/[\\d.]+/g) || [0, 0, 0, 1]; return { r: +m[0], g: +m[1], b: +m[2], a: m[3] === undefined ? 1 : +m[3] }; };
  const fam = f => f.split(",")[0].replace(/["']/g, "").trim();
  const slides = [...document.querySelectorAll(".slide")];
  return [slides[${idx}]].map((s) => { const si = ${idx};
    const sr = s.getBoundingClientRect(), K = sr.width / 1600, texts = [];
    const els = [...s.querySelectorAll(SEL)].filter(e => !e.parentElement.closest(SEL));
    els.forEach(e => {
      const r = e.getBoundingClientRect(), cs = getComputedStyle(e);
      if (r.width < 2 || r.height < 2 || cs.visibility === "hidden" || !e.textContent.trim()) return;
      if (e.offsetWidth && Math.abs(r.width / K - e.offsetWidth) > 2) return;          // rotated or scaled: stays in the image
      for (let a = e; a && a !== s; a = a.parentElement) if (+getComputedStyle(a).opacity === 0) return;
      const runs = []; let lastTop = null, atStart = true;
      const push = (txt, st) => { if (!txt) return; const L = runs[runs.length - 1]; if (L && JSON.stringify(L.st) === JSON.stringify(st)) L.t += txt; else runs.push({ t: txt, st }); };
      const styleOf = el => { const c = getComputedStyle(el); return { font: fam(c.fontFamily), size: px(c.fontSize), weight: +c.fontWeight || 400, italic: c.fontStyle === "italic", color: rgb(c.color), ls: c.letterSpacing === "normal" ? 0 : px(c.letterSpacing), upper: c.textTransform === "uppercase", underline: c.textDecorationLine.includes("underline") }; };
      const walk = node => {
        for (const n of node.childNodes) {
          if (n.nodeType === 3) {
            const el = n.parentElement, st = styleOf(el), raw = n.textContent;
            const re = /\\S+/g; let m, prevEnd = 0;
            while ((m = re.exec(raw))) {
              const rg = document.createRange(); rg.setStart(n, m.index); rg.setEnd(n, m.index + m[0].length);
              const rc = rg.getClientRects(); if (!rc.length) { prevEnd = m.index + m[0].length; continue; }
              const top = rc[0].top, gap = raw.slice(prevEnd, m.index);
              if (lastTop !== null && top - lastTop > st.size * K * 0.5) push("\\v", st);
              else if (!atStart && gap.length) push(" ", st);
              else if (!atStart && !gap.length && m.index === 0 && /\\s$/.test(runs[runs.length - 1]?.t || "") === false && n.previousSibling && /\\s$/.test(n.previousSibling.textContent || "")) push(" ", st);
              push(st.upper ? m[0].toUpperCase() : m[0], st);
              lastTop = rc[rc.length - 1].top; atStart = false; prevEnd = m.index + m[0].length;
            }
            if (/\\s$/.test(raw) && !atStart) push(" ", st);
          } else if (n.nodeType === 1) {
            const c = getComputedStyle(n); if (c.display === "none") continue;
            if (n.tagName === "BR") { push("\\v", styleOf(node.nodeType === 1 ? node : e)); lastTop = null; continue; }
            const block = /^(block|list-item|flex|grid|table)/.test(c.display);
            if (block && !atStart) { push("\\n", styleOf(n)); lastTop = null; }
            walk(n);
          }
        }
      };
      walk(e);
      runs.forEach(u => u.t = u.t.replace(/ +(\\v|\\n)/g, "$1").replace(/(\\v|\\n) +/g, "$1"));
      if (runs.length) { runs[runs.length - 1].t = runs[runs.length - 1].t.replace(/\\s+$/, ""); runs[0].t = runs[0].t.replace(/^\\s+/, ""); }
      const lh = cs.lineHeight === "normal" ? px(cs.fontSize) * 1.2 : px(cs.lineHeight);
      const bullet = e.tagName === "LI" && cs.listStyleType !== "none";
      
      texts.push({ x: (r.left - sr.left) / K + px(cs.paddingLeft) + px(cs.borderLeftWidth), y: (r.top - sr.top) / K + px(cs.paddingTop) + px(cs.borderTopWidth),
        w: r.width / K - px(cs.paddingLeft) - px(cs.paddingRight) - px(cs.borderLeftWidth) - px(cs.borderRightWidth),
        h: r.height / K - px(cs.paddingTop) - px(cs.paddingBottom) - px(cs.borderTopWidth) - px(cs.borderBottomWidth),
        align: ({ start: "left", end: "right", justify: "left" })[cs.textAlign] || cs.textAlign, lh, valign: "top", bullet, tag: e.tagName.toLowerCase(), runs });
    });
    return { index: si + 1, top: 0, clip: { x: sr.left, y: sr.top, width: sr.width, height: sr.height, scale: 1 / K }, title: s.dataset.title || "", texts, notes: s.innerText.replace(/\\n{2,}/g, "\\n").trim().slice(0, 4000) };
  })[0];
})()`;
const N = await ev(`document.querySelectorAll(".slide").length`);
if (process.env.DBG) console.log("N", N);
await ev(`(() => { const st = document.createElement("style"); st.id = "solo"; document.head.appendChild(st);
  const hide = document.createElement("style"); hide.id = "hidetext"; document.head.appendChild(hide); return 1; })()`);
const SELS = "h1,h2,h3,p,li,td,th,dt,dd,.num,.lbl,.kicker,.year,.role,.pill,.badge,.tag,.delta,.card-h,.no,.tab,div.quote".split(",");
const HIDE = SELS.map(x => `.slide ${x},.slide ${x} *,.slide ${x}::marker`).join(",") + "{color:transparent!important;-webkit-text-fill-color:transparent!important;text-shadow:none!important;text-decoration-color:transparent!important}";
const slides = [];
const shot = async (name, clip) => { const m = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: true, clip }); writeFileSync(join(out, name), Buffer.from(m.result.data, "base64")); };
for (let i = 0; i < N; i++) {
  // show one slide at the top-left corner, nothing else
  await ev(`(() => { window.scrollTo(0, 0); document.getElementById("hidetext").textContent = "";
    const sl = document.querySelectorAll(".slide")[${i}], nth = [...sl.parentElement.children].indexOf(sl) + 1, me = ".slide:nth-child(" + nth + ")";
    if (!${!!process.env.NOSOLO}) document.getElementById("solo").textContent = ".slide{display:none!important} " + me + "{display:block!important;opacity:1!important;visibility:visible!important;transform:none!important}";
    return new Promise(r => setTimeout(r, 120)); })()`);
  if (process.env.DBG) console.log("solo", i);
  const sl = await ev(extract(i));
  if (process.env.DBG) console.log("ext", i, sl && sl.texts.length);
  const nm = String(i + 1).padStart(2, "0");
  await shot(`full_${nm}.png`, sl.clip);
  await ev(`(() => { document.getElementById("hidetext").textContent = ${JSON.stringify(HIDE)}; return new Promise(r => setTimeout(r, 120)); })()`);
  await shot(`bg_${nm}.png`, sl.clip);
  slides.push(sl); process.stdout.write(`${i + 1} `);
}
writeFileSync(join(out, "layers.json"), JSON.stringify({ width: 1600, height: 900, slides }, null, 1));
console.log("slides", slides.length, "text blocks", slides.reduce((a, s) => a + s.texts.length, 0));
ws.close(); chrome.kill();
try { rmSync(prof, { recursive: true, force: true }); } catch {}
