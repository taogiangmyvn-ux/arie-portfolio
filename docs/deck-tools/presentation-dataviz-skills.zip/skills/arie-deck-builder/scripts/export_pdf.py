"""Export a Deck Builder by Arie deck to PDF with headless Chrome.

Decks: one page per slide at 1600x900 px, every build step shown. Reports (report.html): one long page, 1200 px wide. Text stays selectable.

    python3 export_pdf.py path/to/deck.html [--lang en|vi] [--theme name] [--out file.pdf]

The artifact viewer blocks window.print(), so PDF export always runs locally with this script.
"""
import argparse, pathlib, shutil, subprocess, tempfile

CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck")
    ap.add_argument("--lang", default="en")
    ap.add_argument("--theme", help="theme preset name, for decks built from layouts.html")
    ap.add_argument("--cards", help="report.html only: outline | tint | band")
    ap.add_argument("--out")
    a = ap.parse_args()
    src = pathlib.Path(a.deck).resolve()
    out = pathlib.Path(a.out).resolve() if a.out else src.with_name(f"{src.stem}_{a.lang}{'_' + a.theme if a.theme else ''}.pdf")
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="deckpdf_"))
    # The deck file has no doctype (the Artifact skeleton adds one), so add it here to avoid quirks mode.
    page = tmp / "deck.html"
    page.write_text("<!doctype html><html><head><meta charset='utf-8'></head><body>" + src.read_text() + "</body></html>")
    # Relative assets (images next to the deck) must still resolve.
    for p in src.parent.iterdir():
        if p.is_dir() and p.name in ("img", "images", "assets"):
            shutil.copytree(p, tmp / p.name)
    cmd = [CHROME, "--headless=new", "--disable-gpu", "--no-first-run", "--no-pdf-header-footer",
           f"--user-data-dir={tmp / 'profile'}", f"--print-to-pdf={out}", "--virtual-time-budget=6000",
           page.as_uri() + f"?lang={a.lang}&print=1" + (f"&theme={a.theme}" if a.theme else "") + (f"&cards={a.cards}" if a.cards else "")]
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        proc.wait(timeout=60)  # Chrome sometimes lingers after writing the file
    except subprocess.TimeoutExpired:
        proc.kill(); proc.wait()
    shutil.rmtree(tmp, ignore_errors=True)
    if not out.exists():
        raise SystemExit(f"Chrome did not write {out}")
    print(f"{out}  {out.stat().st_size / 1024:.0f} KB")

if __name__ == "__main__":
    main()
