"""Export a deck to an editable PPTX (hybrid mode).

Each slide = the design as the slide background picture (cannot be dragged by accident; Format Background
to change it) + every text line block as a real text box on top, at the position the browser printed it.

    python3 export_pptx_editable.py path/to/deck.html [--lang en] [--out file.pptx]
                                    [--body Sen] [--serif "Playfair Display"]

Pipeline: export_pdf.py (Chrome) -> PyMuPDF reads text spans (position, size, colour, italic) and
renders each page with the text removed -> python-pptx. Chrome prints web fonts without names, so the
font names come from --body (upright text) and --serif (italic text). Use Google Fonts so Google Slides
shows them; PowerPoint needs them installed.
"""
import argparse, pathlib, subprocess, sys, tempfile
import fitz
from pptx import Presentation
from pptx.util import Emu, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import MSO_AUTO_SIZE, MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from lxml import etree

HERE = pathlib.Path(__file__).parent
W_EMU, H_EMU = 12192000, 6858000


def set_background(slide, img):
    _, rId = slide.part.get_or_add_image_part(str(img))
    cSld = slide._element.find(qn("p:cSld"))
    bg = etree.Element(qn("p:bg")); cSld.insert(0, bg)
    bgPr = etree.SubElement(bg, qn("p:bgPr"))
    fill = etree.SubElement(bgPr, qn("a:blipFill"), {"dpi": "0", "rotWithShape": "1"})
    etree.SubElement(fill, qn("a:blip"), {qn("r:embed"): rId})
    etree.SubElement(etree.SubElement(fill, qn("a:stretch")), qn("a:fillRect"))
    etree.SubElement(bgPr, qn("a:effectLst"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck")
    ap.add_argument("--lang", default="en")
    ap.add_argument("--out")
    ap.add_argument("--body", default="Sen")
    ap.add_argument("--serif", default="Playfair Display")
    ap.add_argument("--slack", type=float, default=0.06)
    a = ap.parse_args()
    src = pathlib.Path(a.deck).resolve()
    out = pathlib.Path(a.out).resolve() if a.out else src.with_name(src.stem + "_editable.pptx")
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="deckpptx_"))
    pdf = tmp / "deck.pdf"
    subprocess.run([sys.executable, str(HERE / "export_pdf.py"), str(src), "--lang", a.lang, "--out", str(pdf)], check=True, timeout=180)
    doc = fitz.open(pdf)
    prs = Presentation(); prs.slide_width, prs.slide_height = Emu(W_EMU), Emu(H_EMU)
    boxes = 0
    for pno, page in enumerate(doc):
        k = W_EMU / page.rect.width                      # EMU per PDF point
        ptk = 960 / page.rect.width                      # slide pt per PDF point
        blocks = [b for b in page.get_text("dict")["blocks"] if b["type"] == 0]
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        # design layer: same page with the text removed
        for b in blocks:
            page.add_redact_annot(fitz.Rect(b["bbox"]))
        page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE, graphics=fitz.PDF_REDACT_LINE_ART_NONE)
        bg = tmp / f"bg_{pno:02d}.jpg"
        page.get_pixmap(dpi=200).save(bg, jpg_quality=90)
        set_background(slide, bg)
        # group lines into paragraphs: next line directly below, same left edge or same centre
        lines = sorted((l for b in blocks for l in b["lines"] if "".join(sp["text"] for sp in l["spans"]).strip()), key=lambda l: (round(l["bbox"][1]), l["bbox"][0]))
        groups = []
        for l in lines:
            sz = max(sp["size"] for sp in l["spans"])
            for g in groups:
                q = g[-1]["bbox"]; gap = l["bbox"][1] - q[1]
                cx, qcx = (l["bbox"][0] + l["bbox"][2]) / 2, (q[0] + q[2]) / 2
                qs = max(sp["size"] for sp in g[-1]["spans"])
                if 0.6 * sz < gap < 2.0 * sz and 0.8 < sz / qs < 1.25 and (abs(l["bbox"][0] - q[0]) < 4 or abs(cx - qcx) < 4) and l["bbox"][0] < q[2] and q[0] < l["bbox"][2]:
                    g.append(l); break
            else:
                groups.append([l])
        for g in groups:
            x0 = min(l["bbox"][0] for l in g); y0 = g[0]["bbox"][1]; x1 = max(l["bbox"][2] for l in g); y1 = g[-1]["bbox"][3]
            centred = len(g) > 1 and all(abs((l["bbox"][0] + l["bbox"][2]) / 2 - (x0 + x1) / 2) < 4 for l in g) and any(abs(l["bbox"][0] - x0) > 4 for l in g)
            w = (x1 - x0) * (1 + a.slack) + 2
            if centred:
                x0 -= (w - (x1 - x0)) / 2
            tb = slide.shapes.add_textbox(Emu(int(x0 * k)), Emu(int(y0 * k)), Emu(int(w * k)), Emu(int((y1 - y0) * k)))
            tf = tb.text_frame; tf.word_wrap = True; tf.auto_size = MSO_AUTO_SIZE.NONE
            tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0; tf.vertical_anchor = MSO_ANCHOR.TOP
            p = tf.paragraphs[0]
            if centred:
                p.alignment = PP_ALIGN.CENTER
            if len(g) > 1:
                p.line_spacing = Pt((g[1]["bbox"][1] - g[0]["bbox"][1]) * ptk)
            for li, l in enumerate(g):
                if li:
                    p.add_line_break()
                for sp in l["spans"]:
                    if not sp["text"]:
                        continue
                    r = p.add_run(); r.text = sp["text"]
                    f = r.font; italic = bool(sp["flags"] & 2)
                    f.name = a.serif if italic else a.body
                    f.italic = italic; f.bold = bool(sp["flags"] & 16)
                    f.size = Pt(round(sp["size"] * ptk * 2) / 2)
                    c = sp["color"]; f.color.rgb = RGBColor((c >> 16) & 255, (c >> 8) & 255, c & 255)
            boxes += 1
        slide.notes_slide.notes_text_frame.text = "\n".join(
            "".join(s["text"] for s in l["spans"]) for b in blocks for l in b["lines"])
    prs.save(out)
    print(f"wrote {out} · {len(doc)} slides · {boxes} text boxes")


if __name__ == "__main__":
    main()
