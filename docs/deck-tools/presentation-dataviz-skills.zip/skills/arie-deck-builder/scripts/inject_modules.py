"""Copy the shared in-page modules into every template and example page.

    python3 scripts/inject_modules.py            # all templates + examples/coba
    python3 scripts/inject_modules.py page.html  # also a built page

template/_imgcrop.js goes between /* imgcrop:begin */ and /* imgcrop:end */.
template/_textstyle.js goes between /* textstyle:begin */ and /* textstyle:end */; in reports,
template/_addimage.js goes between /* addimage:begin */ and /* addimage:end */, and
template/_annotate.js (draw tools) between /* annotate:begin */ and /* annotate:end */ (added right after the
imgcrop block the first time).
template/_morph.js goes between /* morph:begin */ and /* morph:end */ (decks only, after the textstyle block). The edit-text sanitiser in each page is also upgraded once so styled spans survive.
"""
import pathlib, re, sys

SKILL = pathlib.Path(__file__).resolve().parent.parent
PAGES = [SKILL / "template" / n for n in ("layouts.html", "deck.html", "report.html")] + sorted((SKILL / "examples").glob("*/*.html"))

SAFE = '''  // inline styles from the text style bar: only these properties, no urls
  const STY = /^(color|background-color|font-family|font-size|font-weight|font-style|text-decoration|text-decoration-line|text-align|display)$/;
  const safeStyle = v => String(v || "").split(";").map(d => d.trim()).filter(d => { const i = d.indexOf(":"); if (i < 1) return false;
    const p = d.slice(0, i).trim().toLowerCase(), x = d.slice(i + 1).trim(); return STY.test(p) && x.length < 160 && !/url\\(|expression|javascript:|[<>\\\\]/i.test(x) && (p !== "display" || x === "block"); }).join(";");
'''
OLD_OK = 'const OK = new Set(["em", "b", "strong", "i", "br", "mark", "sup", "sub", "span", "svg", "use"]);'
NEW_OK = 'const OK = new Set(["em", "b", "strong", "i", "u", "s", "br", "mark", "sup", "sub", "span", "svg", "use"]);'
OLD_KEEP = '[...c.attributes].forEach(a => { const keep = (a.name === "class"'
NEW_KEEP = ('if (tag === "span" && c.hasAttribute("style")) c.setAttribute("style", safeStyle(c.getAttribute("style")));\n'
            '      [...c.attributes].forEach(a => { const keep = (tag === "span" && (a.name === "data-align" || (a.name === "style" && a.value))) || (a.name === "class"')


def block(text, name, code, after=None):
    b, e = f"/* {name}:begin */", f"/* {name}:end */"
    if b in text:
        i, j = text.index(b), text.index(e) + len(e)
        return text[:i] + f"{b}\n{code.rstrip()}\n{e}" + text[j:]
    if after and after in text:
        j = text.index(after) + len(after)
        return text[:j] + f"\n{b}\n{code.rstrip()}\n{e}" + text[j:]
    raise SystemExit(f"no place for {name}")


def main():
    crop = (SKILL / "template" / "_imgcrop.js").read_text()
    style = (SKILL / "template" / "_textstyle.js").read_text()
    add = (SKILL / "template" / "_addimage.js").read_text()
    ink = (SKILL / "template" / "_annotate.js").read_text()
    morph = (SKILL / "template" / "_morph.js").read_text()
    for p in PAGES + [pathlib.Path(a) for a in sys.argv[1:]]:
        t = p.read_text()
        t = block(t, "imgcrop", crop)
        t = block(t, "textstyle", style, after="/* imgcrop:end */")
        if 'id="rpt"' in t:   # reports only: decks already have their own add-image tool
            t = block(t, "addimage", add, after="/* textstyle:end */")
            t = block(t, "annotate", ink, after="/* addimage:end */")
        if 'id="stage"' in t:
            t = block(t, "morph", morph, after="/* textstyle:end */")
        if OLD_OK in t:
            t = t.replace(OLD_OK, NEW_OK)
        if OLD_KEEP in t and "safeStyle(c.getAttribute" not in t:
            t = t.replace(OLD_KEEP, NEW_KEEP)
            t = t.replace("  function clean(html) {", SAFE + "  function clean(html) {", 1)
        p.write_text(t)
        print("updated", p.relative_to(SKILL) if SKILL in p.parents else p)


if __name__ == "__main__":
    main()
