"""Write text edits made in the deck (Edit text / W) back into the HTML source.

Image crops (double-click an image) are baked too: keys "img:s3:2" rewrite that <img>'s
object-position / transform, and its frame's shape, move (translate) and size. A replaced photo ("u", a data URL)
is written to img/edit-<key>.<ext> beside the page and the <img> src points at it.
Text styles from the style bar (<span style>, <u>, <s>, align spans) are kept through the same allow-list as the
page, and a Google Fonts <link> is added to <head> for every FONTS entry the page now uses. "bg:" keys (CSS background images) are reported, not baked.

Edits come from edits.json on the claude.ai link (Artifact tool: read with path "edits.json")
or from the "Copy edits" button (paste into a file). Keys look like "s3:5" (slide 3, 6th editable
element) or "r:12" (report). The element list must match EDIT_SEL in the page's editor script.

    python3 bake_edits.py path/to/deck.html edits.json [--out path/to/deck.html]

Only the inner HTML of the edited elements changes; the rest of the file is kept byte for byte.
After baking, republish the page and reset edits.json to {} so edits are not applied twice.
"""
import argparse, base64, html, json, pathlib, re
from html.parser import HTMLParser

TAGS = {"h1", "h2", "h3", "p", "li", "td", "th", "dt", "dd"}
CLASSES = {"num", "lbl", "kicker", "year", "role", "pill", "badge", "tag", "delta", "card-h", "no", "tab"}
COMBOS = {("div", "quote")}
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "source", "track", "wbr"}
OK_TAGS = {"em", "b", "strong", "i", "u", "s", "br", "mark", "sup", "sub", "span", "svg", "use"}
STY = re.compile(r"^(color|background-color|font-family|font-size|font-weight|font-style|text-decoration|text-decoration-line|text-align|display)$")
FONTS = {  # keep in step with FONTS in template/_textstyle.js: css family -> Google Fonts family
    "Sen": "Sen:wght@400;500;600;700;800", "Inter": "Inter:wght@400;600;700", "Montserrat": "Montserrat:wght@400;600;800", "Poppins": "Poppins:wght@400;600;700",
    "Be Vietnam Pro": "Be+Vietnam+Pro:wght@400;600;700", "Space Grotesk": "Space+Grotesk:wght@400;600;700", "Bebas Neue": "Bebas+Neue",
    "Playfair Display": "Playfair+Display:ital,wght@0,400;0,700;1,400", "DM Serif Display": "DM+Serif+Display:ital@0;1",
    "Cormorant Garamond": "Cormorant+Garamond:ital,wght@0,400;0,600;1,400", "Lora": "Lora:ital,wght@0,400;0,600;1,400",
    "Caveat": "Caveat:wght@400;700", "Courier Prime": "Courier+Prime",
}


def safe_style(v):
    out = []
    for d in (v or "").split(";"):
        if ":" not in d:
            continue
        p, x = d.split(":", 1)
        p, x = p.strip().lower(), x.strip()
        if STY.match(p) and len(x) < 160 and not re.search(r"url\(|expression|javascript:|[<>\\]", x, re.I) and (p != "display" or x == "block"):
            out.append(f"{p}:{x}")
    return ";".join(out)


class Node:
    def __init__(self, tag, attrs, parent, inner_start, tag_start=None, tag_text=""):
        self.tag, self.parent, self.inner_start, self.inner_end = tag, parent, inner_start, None
        self.tag_start, self.tag_text = tag_start, tag_text
        self.attrs = dict(attrs)
        self.cls = set((self.attrs.get("class") or "").split())
        self.children = []

    def editable(self):
        return self.tag in TAGS or bool(self.cls & CLASSES) or "data-edit" in self.attrs or any(self.tag == t and c in self.cls for t, c in COMBOS)

    def ancestors(self):
        n = self.parent
        while n:
            yield n
            n = n.parent


class Tree(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=False)
        self.text, self.lines = text, [0]
        for m in re.finditer("\n", text):
            self.lines.append(m.end())
        self.root = Node("#root", [], None, 0)
        self.stack, self.order = [self.root], []

    def off(self):
        line, col = self.getpos()
        return self.lines[line - 1] + col

    def handle_starttag(self, tag, attrs):
        start = self.off()
        txt = self.get_starttag_text()
        node = Node(tag, attrs, self.stack[-1], start + len(txt), start, txt)
        self.stack[-1].children.append(node)
        self.order.append(node)
        if tag not in VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        node = Node(tag, attrs, self.stack[-1], None, self.off(), self.get_starttag_text())
        self.stack[-1].children.append(node)
        self.order.append(node)

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                self.stack[i].inner_end = self.off()
                del self.stack[i:]
                return


def roots(tree):
    out = []
    for n in tree.order:
        if n.tag == "section" and "slide" in n.cls and n.parent and n.parent.attrs.get("id") == "stage":
            out.append((n, f"s{len(out) + 1}"))
    if not out:
        out = [(n, "r") for n in tree.order if n.attrs.get("id") == "rpt"][:1]
    return out


def keyed(tree):
    result = {}
    for root, pre in roots(tree):
        n = 0
        for node in tree.order:
            anc = list(node.ancestors())
            if root not in anc or not node.editable():
                continue
            below = anc[:anc.index(root)]  # ancestors inside this root
            if any("chart" in a.cls or "data-noedit" in a.attrs or a.tag == "svg" for a in [node] + below):
                continue
            if any(a.editable() for a in below):
                continue
            result[f"{pre}:{n}"] = node
            n += 1
    return result


SKIP_CLS = {"chart", "bar", "rbar", "editbar", "pick"}


def images(tree):
    """img nodes in the same order as the page's image-crop script (keys img:<root>:<n>)."""
    result = {}
    for root, pre in roots(tree):
        n = 0
        for node in tree.order:
            if node.tag != "img":
                continue
            anc = list(node.ancestors())
            if root not in anc:
                continue
            if node.cls & {"logo", "avatar", "av"} or any("avatar" in c or "icon" in c for c in node.cls):
                continue
            below = anc[:anc.index(root)]
            if any(a.tag in ("svg", "nav", "button") or a.cls & SKIP_CLS or "data-nocrop" in a.attrs for a in below):
                continue
            result[f"img:{pre}:{n}"] = node
            n += 1
    return result


SHAPES = {  # keep in step with SHAPES in template/_imgcrop.js
    "square": {"border-radius": "0px"},
    "rounded": {"border-radius": "24px"},
    "arch": {"border-radius": "9999px 9999px 0 0"},
    "pill": {"border-radius": "9999px"},
    "oval": {"border-radius": "50%"},
    "circle": {"border-radius": "0px", "clip-path": "circle(closest-side at 50% 50%)"},
}


def set_style(tag_text, props, drop=()):
    """Set CSS properties in a start tag's style attribute (adds the attribute if missing)."""
    m = re.search(r"""\sstyle\s*=\s*("([^"]*)"|'([^']*)')""", tag_text)
    old = (m.group(2) if m.group(2) is not None else m.group(3)) if m else ""
    gone = {k.lower() for k in props} | {d.lower() for d in drop}
    decl = [d.strip() for d in old.split(";") if d.strip() and d.split(":")[0].strip().lower() not in gone]
    decl += [f"{k}:{v}" for k, v in props.items()]
    style = f' style="{";".join(decl)}"'
    if m:
        return tag_text[:m.start()] + style + tag_text[m.end():]
    return re.sub(r"\s*/?>$", lambda e: style + e.group(0), tag_text, count=1)


def set_attr(tag_text, name, value, drop=()):
    """Set one attribute in a start tag (and remove the ones in drop)."""
    for d in drop:
        tag_text = re.sub(rf"""\s{d}\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)""", "", tag_text)
    pat = rf"""(\s{name}\s*=\s*)("[^"]*"|'[^']*'|[^\s>]+)"""
    if re.search(pat, tag_text):
        return re.sub(pat, lambda m: f'{m.group(1)}"{html.escape(value, quote=True)}"', tag_text, count=1)
    return re.sub(r"\s*/?>$", lambda e: f' {name}="{html.escape(value, quote=True)}"' + e.group(0), tag_text, count=1)


def add_fonts(text):
    """Add a Google Fonts <link> for each style-bar font the page uses and does not load yet."""
    used = [g for f, g in FONTS.items() if re.search(rf"font-family:\s*(&#x27;|&#39;|'|\")?{re.escape(f)}", text)]
    have = " ".join(re.findall(r"<link[^>]+fonts\.googleapis\.com[^>]*>", text))
    need = [g for g in used if "family=" + g.split(":")[0] not in have]
    if not need:
        return text, []
    links = "".join(f'<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family={g}&display=swap">\n' for g in need)
    for anchor in ("</head>", "<style"):   # artifact pages are fragments without <head>
        if anchor in text:
            return text.replace(anchor, links + anchor, 1), need
    return links + text, need


def crop_tag(tag_text, p, z):
    """Rewrite an <img> start tag so object-position / zoom match the crop."""
    m = re.search(r"""\sstyle\s*=\s*("([^"]*)"|'([^']*)')""", tag_text)
    old = (m.group(2) if m and m.group(2) is not None else m.group(3)) if m else ""
    decl = [d.strip() for d in old.split(";") if d.strip() and d.split(":")[0].strip().lower() not in
            ("object-fit", "object-position", "transform-origin", "transform")]
    decl += ["object-fit:cover", f"object-position:{p}", f"transform-origin:{p}"]
    if z and float(z) > 1.001:
        decl.append(f"transform:scale({round(float(z), 3)})")
    style = f' style="{";".join(decl)}"'
    if m:
        return tag_text[:m.start()] + style + tag_text[m.end():]
    return re.sub(r"\s*/?>$", lambda e: style + e.group(0), tag_text, count=1)


class Clean(HTMLParser):
    """Allow-list sanitiser matching the page's clean(): text plus simple inline tags."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out = []

    def handle_starttag(self, tag, attrs):
        if tag not in OK_TAGS:
            return
        keep = []
        for k, v in attrs:
            if k == "class" and v and re.fullmatch(r"[\w -]{0,80}", v):
                keep.append(f' class="{v}"')
            if tag == "use" and k == "href" and v and re.fullmatch(r"#[\w-]+", v):
                keep.append(f' href="{v}"')
            if tag == "span" and k == "data-align":
                keep.append(" data-align")
            if tag == "span" and k == "style" and safe_style(v):
                keep.append(f' style="{html.escape(safe_style(v), quote=True)}"')
        self.out.append(f"<{tag}{''.join(keep)}>")

    def handle_endtag(self, tag):
        if tag in OK_TAGS and tag not in VOID and tag != "br":
            self.out.append(f"</{tag}>")

    def handle_data(self, data):
        self.out.append(html.escape(data, quote=False))


def clean(s):
    c = Clean()
    c.feed(s)
    c.close()
    return "".join(c.out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("page")
    ap.add_argument("edits")
    ap.add_argument("--out")
    a = ap.parse_args()
    src = pathlib.Path(a.page)
    text = src.read_text()
    edits = json.loads(pathlib.Path(a.edits).read_text())
    tree = Tree(text)
    tree.feed(text)
    tree.close()
    nodes = keyed(tree)
    imgs = images(tree)
    todo, missing, skipped = [], [], []
    for k, v in edits.items():
        if k.startswith("img:"):
            n = imgs.get(k)
            if n is None or n.tag_start is None or not isinstance(v, dict):
                missing.append(k)
                continue
            tag = crop_tag(n.tag_text, v.get("p", "50% 50%"), v.get("z", 1))
            u = v.get("u") or ""
            m = re.match(r"data:image/(png|jpeg|webp|gif);base64,(.+)$", u, re.S)
            if m:
                ext = "jpg" if m.group(1) == "jpeg" else m.group(1)
                rel = f"img/edit-{k.replace(':', '-')}.{ext}"
                dest = src.parent / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(base64.b64decode(m.group(2)))
                tag = set_attr(tag, "src", rel, drop=("srcset",))
            todo.append((n.tag_start, n.tag_start + len(n.tag_text), tag, k))
            fr = n.parent
            props, drop = {}, ()
            if v.get("s") in SHAPES:
                props.update(SHAPES[v["s"]]); props["overflow"] = "hidden"; drop = ("clip-path",)
            dx, dy, w, h = (round(float(v.get(a) or 0), 1) for a in ("dx", "dy", "w", "h"))
            if dx or dy:
                props["translate"] = f"{dx:g}px {dy:g}px"
            if w:
                props["width"] = f"{w:g}px"
            if h:
                props["height"] = f"{h:g}px"
            if dx or dy or w or h:
                props["z-index"] = "4"
            if props and fr is not None and fr.tag_start is not None:
                todo.append((fr.tag_start, fr.tag_start + len(fr.tag_text), set_style(fr.tag_text, props, drop=drop), k + ":frame"))
            continue
        if k.startswith("bg:"):
            skipped.append(k)  # background-image crops live in CSS; re-apply by hand if needed
            continue
        n = nodes.get(k)
        if n is None or n.inner_start is None or n.inner_end is None:
            missing.append(k)
            continue
        todo.append((n.inner_start, n.inner_end, clean(v), k))
    for start, end, new, k in sorted(todo, reverse=True):
        text = text[:start] + new + text[end:]
    text, fonts = add_fonts(text)
    out = pathlib.Path(a.out) if a.out else src
    out.write_text(text)
    if fonts:
        print("added fonts:", ", ".join(f.split(":")[0].replace("+", " ") for f in fonts))
    print(f"baked {len(todo)} edit(s) into {out}" + (f"; not found: {', '.join(missing)}" if missing else "")
          + (f"; background crops not baked: {', '.join(skipped)}" if skipped else ""))


if __name__ == "__main__":
    main()
