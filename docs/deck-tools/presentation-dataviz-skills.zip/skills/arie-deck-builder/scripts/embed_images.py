"""Make a single-file deck: every local image (img src and CSS url()) is resized and embedded as a data URL,
so the deck shows its photos wherever it is opened (chat attachment, Drive preview, email, AirDrop).

    python3 embed_images.py deck.html [--out deck_standalone.html] [--max 1600] [--quality 82]
"""
import argparse, base64, io, pathlib, re
from PIL import Image


def data_url(path, mx, q):
    im = Image.open(path)
    keep_png = path.suffix.lower() == ".png" and im.mode in ("RGBA", "LA", "P")
    im.thumbnail((mx, mx))
    buf = io.BytesIO()
    if keep_png:
        im.save(buf, "PNG", optimize=True); mime = "image/png"
    else:
        im.convert("RGB").save(buf, "JPEG", quality=q, optimize=True, progressive=True); mime = "image/jpeg"
    return f"data:{mime};base64," + base64.b64encode(buf.getvalue()).decode()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck"); ap.add_argument("--out")
    ap.add_argument("--max", type=int, default=1600); ap.add_argument("--quality", type=int, default=82)
    a = ap.parse_args()
    src = pathlib.Path(a.deck).resolve(); base = src.parent
    t = src.read_text(); cache = {}; missing = []

    def sub(m):
        ref = m.group(2)
        if ref.startswith(("data:", "http:", "https:", "//")):
            return m.group(0)
        p = (base / ref).resolve()
        if not p.exists():
            missing.append(ref); return m.group(0)
        if ref not in cache:
            cache[ref] = data_url(p, a.max, a.quality)
        return m.group(1) + cache[ref] + m.group(3)

    t = re.sub(r'(src=")([^"]+\.(?:jpe?g|png|webp|gif))(")', sub, t, flags=re.I)
    t = re.sub(r"(url\(['\"]?)([^'\")]+\.(?:jpe?g|png|webp|gif))(['\"]?\))", sub, t, flags=re.I)
    out = pathlib.Path(a.out) if a.out else src.with_name(src.stem + "_standalone.html")
    out.write_text(t)
    print(f"wrote {out} · {len(cache)} images embedded · {out.stat().st_size / 1e6:.1f} MB" + (f" · missing: {missing}" if missing else ""))


if __name__ == "__main__":
    main()
