"""Make one self-contained HTML file from a built deck or report: full document wrapper plus every
local image inlined as a data URI, so it opens with colours and photos from anywhere (email, Drive,
double-click). The claude.ai artifact keeps using the normal file + img/ folder.

    python3 scripts/make_standalone.py path/to/page.html [--out page_standalone.html]
"""
import argparse, base64, mimetypes, pathlib, re


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("page")
    ap.add_argument("--out")
    a = ap.parse_args()
    src = pathlib.Path(a.page)
    s = src.read_text()
    missing = []

    def data(rel):
        p = src.parent / rel
        if not p.exists():
            missing.append(rel)
            return rel
        mt = mimetypes.guess_type(p.name)[0] or "image/jpeg"
        return f"data:{mt};base64,{base64.b64encode(p.read_bytes()).decode()}"

    s = re.sub(r'(src=)"((?!data:|https?:|//)[^"]+\.(?:jpe?g|png|webp|gif|svg))"', lambda m: f'{m.group(1)}"{data(m.group(2))}"', s)
    s = re.sub(r'url\((["\']?)((?!data:|https?:|//)[^"\')]+\.(?:jpe?g|png|webp|gif|svg))\1\)', lambda m: f'url("{data(m.group(2))}")', s)
    # fragments run their theme script before <body> exists unless the page opens one first
    if "<body" not in s:
        s = re.sub(r"(<script>\s*/\* pick the theme)", r"<body>\n\1", s, count=1)
    if not s.lstrip().lower().startswith("<!doctype"):
        s = '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n' + s + "\n</html>\n"
    out = pathlib.Path(a.out) if a.out else src.with_name(src.stem + "_standalone.html")
    out.write_text(s)
    print(f"wrote {out} ({out.stat().st_size / 1e6:.2f} MB)" + (f"; not found: {', '.join(missing)}" if missing else ""))


if __name__ == "__main__":
    main()
