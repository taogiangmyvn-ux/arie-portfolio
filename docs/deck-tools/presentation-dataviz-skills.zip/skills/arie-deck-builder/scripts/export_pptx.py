"""Export a deck to .pptx for Google Slides / PowerPoint / Keynote.

Each slide becomes one full-bleed 16:9 picture (pixel-identical to the HTML deck), and the slide's
text goes into the speaker notes so it stays searchable and copyable. Upload the .pptx to Google Drive
and open it with Google Slides (or drop it in the synced Drive folder).

    python3 export_pptx.py path/to/deck.html [--lang en|vi] [--theme name] [--out file.pptx] [--dpi 144]

Trade-off: pictures look exactly like the deck but the text on them is not editable in Slides.
Needs: Google Chrome, PyMuPDF (fitz), python-pptx.
"""
import argparse, io, pathlib, subprocess, sys, tempfile
import fitz
from pptx import Presentation
from pptx.util import Emu

HERE = pathlib.Path(__file__).parent

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck")
    ap.add_argument("--lang", default="en")
    ap.add_argument("--theme")
    ap.add_argument("--out")
    ap.add_argument("--dpi", type=int, default=144, help="144 gives 3200x1800 px per slide")
    a = ap.parse_args()
    src = pathlib.Path(a.deck).resolve()
    out = pathlib.Path(a.out).resolve() if a.out else src.with_name(f"{src.stem}_{a.lang}{'_' + a.theme if a.theme else ''}.pptx")
    pdf = pathlib.Path(tempfile.mkdtemp(prefix="deckpptx_")) / "deck.pdf"
    cmd = [sys.executable, str(HERE / "export_pdf.py"), str(src), "--lang", a.lang, "--out", str(pdf)]
    if a.theme:
        cmd += ["--theme", a.theme]
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL)

    doc = fitz.open(pdf)
    prs = Presentation()
    prs.slide_width, prs.slide_height = Emu(12192000), Emu(6858000)  # 13.333 x 7.5 in, 16:9
    blank = prs.slide_layouts[6]
    for page in doc:
        png = page.get_pixmap(dpi=a.dpi).tobytes("png")
        slide = prs.slides.add_slide(blank)
        slide.shapes.add_picture(io.BytesIO(png), 0, 0, prs.slide_width, prs.slide_height)
        text = " ".join(page.get_text().split())
        slide.notes_slide.notes_text_frame.text = text[:5000]
    prs.save(out)
    print(f"{out}  {len(doc)} slides  {out.stat().st_size / 1e6:.1f} MB")

if __name__ == "__main__":
    main()
