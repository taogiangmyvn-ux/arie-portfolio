# Style playbook: commercial template look

Learned from paid PowerPoint / Keynote templates: Marketing Campaign (crimson + sand), Non-Profit (violet + lime), Economy Pitch (blue + green), Global Economy Report (dark + lime), Planview (sage gradient), Selling Report (editorial blue lines), Business Marketing (blue + coral duo). Read this before designing any deck. The layouts in `template/layouts.html` implement every rule below.

## 1. Why these templates look expensive

1. **Two colours do all the work.** One strong primary (fills big panels) + one secondary (small accents, motifs, one stat). Everything else is white, one off-white and one ink colour.
2. **Big blocks, not many small ones.** Each slide has one solid colour block that takes 25–50 % of the area. Text sits either on white or on that block, never on a busy middle ground.
3. **One highlighted phrase per headline.** The headline is 2 short lines. The key word or the second line takes the colour (or a pill). Nothing else in the headline is styled.
4. **Numbers are the heroes.** Stats are 2–3× the headline size, bold, and each has a tiny bold label and a 2-line grey note. Nothing else on the slide competes with them.
5. **A small repeated motif** (diamond cluster, leaf, pixel squares, blur blob) appears in 1–2 places per slide: corners, beside a number, at the edges of a timeline. It is the brand's signature and it ties 20 slides together.
6. **Constant chrome.** Tiny logo + deck name top-left, page number bottom-left, same margins on every slide. The eye stops noticing it, so the slide feels calm.
7. **Photos are cropped hard and anchored.** Photos touch a slide edge or sit on an offset colour block. They are never floating with a thin border.
8. **Rhythm.** Every 3–4 white slides, one full-colour slide (section break, big statement, quote). Keeps a 20-slide deck from feeling flat.

## 2. Colour recipe

| Role | Share of slide area | Crimson set | Violet set | Pitch set | Report set |
|---|---|---|---|---|---|
| Background | 50–65 % | #FFFFFF | #FFFFFF | #FFFFFF | #F4F6F9 |

More presets in the file: **sage** (gradient #9CCBA8 → #0B2B29, mint #A9D8B8, Inter Tight 400), **editorial** (#2156E0 on white, thin 2 px frames, Inter 500), **duo** (#3346E0 + #EE5A3C, Montserrat 800), **forest** (#1E5631 on cream #E9E6D4, Barlow Condensed 700 caps, 2 px ruled cells, side rails with rotated labels, petal motif, black-and-white photos; the highlight is a filled pill, e.g. the year), **azure** (blue gradient panels #7FA8FF → #0F2FB0 on a white-to-ice page, Barlow Condensed caps with a gradient fill on headlines, glossy number bubbles, soft blue shadows under white cards, pill-shaped task rows and a white note bar at the bottom).

| Primary (panels, headline highlight) | 25–40 % | #A32A2A | #3A1D9A | #1D6CF0 | #1C43E0 |
| Primary mid tone (2nd card, gradients) | 5–10 % | #B8552F | #8B6CF3 | #5B93F5 | #111317 (dark slides) |
| Secondary (motif, one stat, last timeline step) | ≤ 10 % | #D6A56B | #C4F135 | #22C46E | #B8F23C |
| Ink (headlines) | text | #1E1A1A | #16113A | #13233F | #101317 |
| Muted (body) | text | #6D6461 | #5F5A79 | #5D6B82 | #5E6673 |

Rules:
- **Tonal ramp for sequences.** 3–4 items in a row (timeline years, SWOT, cards) go primary → mid tone → secondary, left to right. It reads as progress and shows off the palette without extra colours.
- **Text on primary is white.** Text on secondary is ink. Never put secondary text on white if contrast is below 4.5:1 (lime and sand fail; use them as fills only).
- **Semantic colours stay out.** No green/red "good/bad" unless the data needs it.
- **Taking colours from a reference:** sample the primary from the biggest solid panel, the secondary from the motif, and the ink from the headline. Then check the pair: primary and secondary must differ in lightness by at least 25 L* so the ramp is visible.

## 3. Type

- One geometric or grotesk sans for everything. Weights: 700/800 for headlines and numbers, 400 for body, 600 for tiny labels.
- Vietnamese text needs a font with the `vietnamese` subset: Be Vietnam Pro, Lexend, Plus Jakarta Sans, Archivo, Montserrat, Inter Tight. Poppins does NOT cover Vietnamese.
- Scale on a 1600×900 slide:

| Element | Size | Weight | Notes |
|---|---|---|---|
| Cover title | 120–150 px | 800 | 2 lines, tight leading 0.95 |
| Slide headline | 60–72 px | 700 | max 2 lines, max ~7 words |
| Hero number | 96–150 px | 800 | tabular figures |
| Card number | 56–72 px | 800 | |
| Label above body | 22–24 px | 700 | ink or primary |
| Body | 20–24 px | 400 | muted colour, max 30 words per block |
| Chrome (deck name, page) | 15–16 px | 500 | |

- Headlines: sentence case for crimson/violet/report; UPPERCASE with 500 weight works for the "pitch" look only.
- Left-align body text. Centre only cover lines, section breaks and single headlines over symmetric layouts (timeline, SWOT).

## 4. What to highlight (the decision rule)

For each slide ask: *what is the one thing the audience should repeat after the meeting?* Highlight only that, in this order of strength:

1. **The number** → hero-number style (largest element on the slide).
2. **The claim word in the headline** → `<em>` inside the `h2`. The theme turns it into colour, a pill or an underline. Pick the word that carries the meaning ("Smarter Data", "Every Purchase", "Impact"), usually the last 1–3 words.
3. **The row or card that wins** → give only that card the primary fill; the others stay light or tonal.
4. **A phrase in body text** → `<mark>` (marker stroke). At most one per slide.

Never highlight two things at the same level. If the number is the hero, the headline highlight stays small.

## 5. Layout grid

- Slide 1600×900. Outer margin 96 px left/right, 72 px top, 64 px bottom. Chrome sits inside the top 56 px.
- 12-column grid, 32 px gutters. Common splits: 5/7 (text/photo), 6/6, 4/4/4, 3/3/3/3.
- Everything aligns to the left margin or the centre line. No element floats between.
- Vertical rhythm: headline → 32 px → body → 48 px → stats/cards.
- Blocks bleed: colour panels and photos may run to the slide edge (0 margin) on one or two sides. That is what gives the "designed" look.

## 5b. Gradient looks (sage preset)

- A gradient is a **material**, not decoration: use it only on the big primary blocks (`--pbg`), never on text or small chips.
- Direction diagonal (120–160°), 3–4 stops from the light tint of the primary to a near-black of the same hue. Example: `#9CCBA8 → #4E8C78 → #15433E → #0B2B29`.
- The page itself gets a very faint gradient (`--paper-bg`, 2–4 % lightness change). Anything stronger fights the panels.
- Pair gradients with light headline weight (300–400), large radius (20–24 px), soft shadows on photos, a glass card (white 70 % + blur) over a photo, and pill tags ("RESULTS").
- Charts on gradient panels are white lines with a soft area fill; bars get a vertical fade (`--chart-grad:1`).

## 5c. Arrangement patterns

| Pattern | When | How |
|---|---|---|
| Split 5/7 | claim + proof | text left 5 cols, photo or chart right 7; one side may bleed |
| Panel + bleed photo | hero numbers | colour panel ~70 % width with chart + KPIs, photo fills the rest edge to edge (L13) |
| Hero number | one metric that matters | 180–220 px light number, unit in accent, 2 small notes below (L18) |
| Card row | 3–4 parallel items | equal cards, tonal ramp, one dark card in the middle for rhythm (L15) |
| Bento | summary, "at a glance" | 3×2 grid, one tile spans 2 rows (photo), mix fills: white, primary, secondary (L20) |
| Chart + takeaway | any data slide | chart ~60 %, a primary card with the one number and what to do (L19) |
| Map / matrix | positioning, prioritising | 2×2 with axis pills on the edges, "us" in the secondary colour, detail panel right (L16) |
| Table + notes | budgets, plans | table left, 3 numbered notes right, total row filled, winning column coloured (L17) |

Mix patterns across a deck: never use the same one on two slides in a row.

## 5d. Charts that look designed and say something

The chart script in `layouts.html` does the drawing. Your job is choosing and framing:

1. **Pick the chart from the question.** Change over time → `line`. Compare few categories or periods → `bar`. Rank many items → `hbar` (sorted). One share of a whole → `ring`. 2–4 parts of a whole → `donut`. Positioning → the L16 map. Several scores for one thing vs a benchmark → `radar` (5–8 axes, same 0–max scale on all). Exact numbers people will read → table (L17).
2. **The headline is the takeaway**, written as a sentence ("TikTok Shop brings the most orders"), never "Orders by channel".
3. **Highlight one thing**: `"highlight": index` (or `"last"` / `"max"` for lines). Everything else goes muted. Grouped bars keep series colours faded outside the highlighted group.
4. **Label directly.** Values sit on the bars; the highlighted value is bold. A legend only when there are 2+ series.
5. **Honest scales.** Bars start at zero (the script forces it). Lines may use `"zero": false` only when the change is the point and the axis is shown.
6. **Few marks.** ≤ 7 bars, ≤ 3 series, ≤ 12 line points, ≤ 4 donut parts. Round to 2–3 significant digits (`prefix`, `suffix`; the script shortens 4200000 → 4.2M).
7. **Support the chart** with 1–2 big deltas (L14) or a takeaway card (L19). The chart shows the shape, the number tells the size.
8. **On colour blocks** add `data-on="dark"` (white chart) or `data-on="s"` (on the secondary colour).

Chart spec examples:
```html
<div class="chart" style="left:96px;top:380px;width:1400px;height:430px"
  data-chart='{"type":"bar","labels":["Q1","Q2","Q3","Q4"],"series":[{"name":"Spend","values":[12,14,13,18]},{"name":"Revenue","values":[30,38,41,64]}],"prefix":"$","suffix":"K","highlight":3}'></div>
<div class="chart" data-chart='{"type":"line","labels":["Jan","Feb","Mar"],"series":[{"name":"Sales","values":[18,22,31]}],"axis":false,"highlight":"last","prefix":"$","suffix":"K"}'></div>
<div class="chart" data-chart='{"type":"hbar","labels":["TikTok Shop","Instagram"],"values":[612,344],"sort":true}'></div>
<div class="chart" data-chart='{"type":"ring","value":84}'></div>
<div class="chart" data-chart='{"type":"donut","parts":[{"label":"Creators","value":62},{"label":"Paid","value":38}],"center":"62%"}'></div>
```

## 6. Layout library (in `template/layouts.html`)

| # | Name | Use for | Key parts |
|---|---|---|---|
| L1 | Cover | first slide | full primary, 2-line title, subtitle, year, edge motif art |
| L2 | Statement box | quote, promise, section intro | inset primary box centred on white, motifs left/right |
| L3 | Photo + claim + stat duo | a claim backed by 2 numbers | photo on offset panel left, headline right, 2 stats on primary block |
| L4 | Data panel | one chart + explanation | framed box with donut + legend, side primary panel with bars |
| L5 | Four pillars | SWOT, 4 steps, 4 benefits | 4 tall cards in tonal ramp, letter/icon badge |
| L6 | Timeline | phases, roadmap | 3–4 tonal tabs with pointer, dots on a line, captions |
| L7 | Metric cards | 3 KPIs with context | 3 tonal cards, icon + arrow, number bottom |
| L8 | Split budget | total + breakdown | left primary panel with hero number, right table on secondary |
| L9 | People grid | team, creators, partners | 2×2 photo + primary name cards |
| L10 | Pill headline + metrics | violet look, campaign impact | headline with pill, photo, 2 big metrics with % superscript |
| L11 | Section break | chapter change | full dark or primary, huge title, number |
| L12 | Close | thank you + contact | primary, motif art, contact rows |
| L13 | Trend hero | growth story | gradient panel with line chart + callout, 3 KPIs, bleed photo with glass card |
| L14 | Columns + deltas | before/after, quarters | grouped bar chart, highlighted period, 2 big deltas top-right |
| L15 | Ring cards | budget split, goal progress | 3 cards (gradient / dark / secondary), value + ring % |
| L16 | Positioning map | competitors, prioritising | 2×2 with axis pills, "us" pill, detail panel |
| L17 | Table + notes | budget by quarter, plans | table with dot headers, winning column, filled total row, 3 notes |
| L18 | Editorial number | one headline metric | framed vertical label, huge light number with accent unit, outlined photo |
| L19 | Ranked bars | channels, products, creators | sorted hbar with leader highlighted, takeaway card with one number |
| L20 | Bento | summary at a glance | 3×2 tile grid: photo, stat, quote, secondary stat, ring |
| L21 | Ruled summary | 3 points with numbers | top colour band, title + pill, 3 cells split by 2 px rules |
| L22 | Contents | agenda | colour band title, section list built automatically from `data-sec`, click to jump |
| L24 | Radar + movers | profile vs benchmark, what changed | radar of 5–8 scores (focus vs average), list of metrics with direction arrows coloured good/bad |
| L25 | Agenda split | agenda | gradient panel with title + one line, numbered sections in 2 columns built from `data-sec` |
| L26 | KPI bubbles | 3–4 headline numbers | glossy spheres with the number inside, label + one line under each |
| L27 | Goal cards | 4 goals with measures | white cards with gradient header, one mini chart each (bar, donut, ring, line), delta with arrow, note bar |
| L28 | Channel split | share by channel | 3 gradient cards with a ring % bubble overlapping the top |
| L29 | Action plan | who does what by when | task pills (gradient), owner pills (white), big deadline column, note bar |
| L30 | Strategy mix | content angles | headline + donut mix left, 2×3 numbered cards with photo + short line right |
| L23 | Welcome + rail | opening after the cover | huge condensed title with motif, rules above and below, bleed photo, side rail |

Pick layouts by content shape, not by habit: 2 numbers → L3; 3 numbers → L7 or L15; 1 number + list → L8; one killer metric → L18; trend → L13; periods compared → L14; ranking → L19; share → L4; sequence → L6; 4 parallel ideas → L5; competitors → L16; budget table → L17; recap → L20.

## 7. Photos

- Ask the user for their photo set. Run `scripts/prep_images.py` to resize and list orientation.
- Landscape photos → L3 left block, L10 side, full-bleed halves. Portrait → L9 people cards, tall side strips. Square → cards.
- Crop with `object-fit: cover` and set `object-position` so faces and products stay in frame.
- If a slot has no photo, use the `.ph` placeholder (tinted block with a caption of what should go there). Never use a random stock image.

## 8. Checklist before delivering

- [ ] Only 2 brand colours + white + ink + muted used.
- [ ] Every headline ≤ 2 lines with exactly one `<em>` highlight (or none on L1/L11).
- [ ] Every slide has one dominant element (block, photo, or number).
- [ ] Chrome and margins identical across slides.
- [ ] A full-colour slide at least every 4 slides.
- [ ] Numbers are real or visibly tagged "Sample".
- [ ] Body copy ≤ 30 words per block, no lorem ipsum.
- [ ] Vietnamese renders with the chosen font (check one slide with VI on).
