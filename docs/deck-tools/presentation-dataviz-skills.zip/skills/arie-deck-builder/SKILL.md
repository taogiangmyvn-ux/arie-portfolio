---
name: arie-deck-builder
description: "Build decks and vertical reports that look like paid commercial templates, as one interactive HTML page instead of PowerPoint or Canva. The user sends reference images, content and photos; the skill turns the references into a theme (10 presets incl. gradients), picks from 30 layouts, draws charts that highlight the takeaway (line, bar, ranked bar, ring, donut, radar), places the photos, and ships a link, PDF and PPTX. Built-in presenter tools (pen, highlighter, arrows, shapes, laser), in-place text editing with a style bar (font incl. brand fonts, size, colour, highlight, align, Ctrl+Z), Canva-style image editing (crop, zoom, shapes, move/resize frame, replace photo, undo), comments, EN/VI switch, scroll view. Use for any deck, slides, presentation, pitch, report or infographic request, 'slide app', 'slide đẹp như template', or when the user sends slide reference images."
---

# Deck Builder by Arie

Files:
- `template/layouts.html` — **start here for every real deck.** Engine + 30 designed layouts + 10 theme presets (theme dropdown on the toolbar; T cycles) + chart script + comment pins.
- `template/report.html` — vertical scrolling report / infographic (bento cards, KPI, charts, rings, pictogram, insights). Same themes and chart script; responsive to phone width; exports as one long PDF page.
- `template/deck.html` — engine demo only (feature showcase).
- `references/style-playbook.md` — the design rules: colour recipe, type scale, what to highlight, grid, layout picker, checklist. **Read it before designing.**
- `scripts/prep_images.py` — resize the user's photos into `img/` and list their orientation.
- `scripts/export_pdf.py` — PDF, one page per slide.
- `scripts/bake_edits.py` — writes text edits made in the page (Edit text, W) into the HTML source.
- `scripts/embed_images.py` — one-file deck with every image embedded (send this when the deck will be opened outside its folder: chat attachment, Drive preview, email).
- `scripts/export_pptx.py` — .pptx for Google Slides / PowerPoint (each slide a full-bleed picture, slide text in speaker notes).

## Data slides

For consulting-style data slides (BCG-like action titles, survey question boxes, delta callouts, waterfall, marimekko, 2x2, slope, dumbbell, CAGR columns…) use the companion skill `arie-dataviz`. It builds on this engine; run its `add_dataviz.py` on a deck to add its chart types and text blocks.

## What the user gives, what you do

The user should only need to send: **reference images + content + photo folder.** Everything else is your job.

### 1. Read the inputs
- **References** (screenshots of templates they like). For each, write down: primary colour (largest solid panel), secondary colour (motif / small accents), background, ink, corner radius (0 / 4 / 18 / 24+ px), headline case and weight, how the headline highlight is done (colour word / pill / underline), the motif shape (diamond, circle, leaf, ring, blur blob, pixel squares), and which layouts appear. Sample hex values by eye from the image; if the user can send the original file, sample exactly with PIL.
- **Content** (notes, doc, sheet, PDF). Extract the one takeaway, the numbers, the sequence items, the people.
- **Photos.** Run:
  ```bash
  python3 ~/.claude/skills/arie-deck-builder/scripts/prep_images.py <photos_folder> <deck_dir>
  ```
  Use the manifest to match photo orientation to layout slots.
- Ask only for what is missing: audience, the decision the deck asks for, languages (default EN; add VI spans when asked), deadline.

### 2. Outline in chat before building
Table: # · layout (L1–L12) · headline with the `<em>` word marked · hero element (number / photo / chart) · steps. Choose layouts with the picker in the playbook (§6). Put a full-colour slide (L1, L2, L8, L11, L12) at least every 4 slides. Proceed without waiting unless the deck is high-stakes.

### 3. Build the theme from the references
- Copy `template/layouts.html` to `03_outputs/<deck_name>/deck.html` (or the project's output folder), next to the `img/` folder.
- Add a `body.th-custom{…}` block in the theme presets with the tokens you read: `--paper --ink --muted --line --p --p2 --s --bg2 --dark --display --r --fw --case --on-s --mrx --shape-r --shape-rot`, plus `--pbg` (gradient for panels), `--paper-bg`, `--hl` (headline highlight colour), `--chart-grad:1` for faded bars. Start from the closest preset and change only what differs.
- In the deck script set `const THEMES = ["custom"];` (one theme, the theme dropdown disappears) and add `custom: ["Name", primary, secondary, background]` to `THEME_META` if you keep more than one.
- Font: pick a Google Font close to the reference that has the `vietnamese` subset (playbook §3) and put it in the fonts `<link>`. Poppins-like → Be Vietnam Pro. Rounded friendly → Lexend. Neutral grotesk → Archivo / Plus Jakarta Sans.
- Motif: the `#motif` symbol and `.shape` blocks take their shape from the tokens. If the reference motif is something else (a leaf, a star), replace the symbol's contents with a simple SVG of that shape.
- Set `data-deck="<deck name>"` on `#stage` (it fills the chrome on every slide).
- Brand decks: take colours and logo from the brand's files first (memory has the CoBa / Halio palettes), references second.
- CôBa's Daughter: use the `coba` preset (official brand book hexes, Sen + Playfair Display italic for emphasis, solid colours only, one text colour, no decorative shapes).

### 4. Fill the slides
- Keep the layouts you need, delete the rest, duplicate as needed. Change copy, numbers, `data-sec`, `data-title`.
- Photos: replace `<div class="ph" data-label="…"></div>` contents with `<img src="img/name.jpg" alt="…" style="object-position:50% 30%">`. Leave `.ph` placeholders only where no photo exists.
- Highlight rule: exactly one `<em>` per headline (the claim words), one hero element per slide, `<mark>` at most once. See playbook §4.
- Charts: `<div class="chart" data-chart='{…}'>` — see playbook §5d. Pick the type from the question, write the takeaway as the headline, highlight one bar/point.
- Real numbers only; add `data-sample` to a slide if any figure is illustrative (it prints "Sample figures" in the footer).

### 5. Check, then deliver
- Export the PDF and look at every page at once (that is the reliable check; browser transitions blur screenshots):
  ```bash
  python3 ~/.claude/skills/arie-deck-builder/scripts/export_pdf.py <deck_dir>/deck.html --lang en
  ```
  Render a contact sheet with PyMuPDF (`fitz`, installed) and fix overlaps, clipped text, 3-line headlines, low contrast. One fix pass.
- Run the playbook checklist (§8).
- Publish with the Artifact tool: `file_path` = the deck, `files` = every `img/…` used (keys `img/name.jpg`), and `capabilities: {"comments": {"customAnchors": true}}` so reviewers can comment. Give the link and the PDF.
- If the publish is refused over `customAnchors`, republish with `capabilities: {"comments": {}}`; the shell's own comment mode then anchors to elements (works on the visible slide).

## Vertical formats

Two ways, pick by purpose:
- **Scroll view of the deck** (key S, toolbar ☰): the same slides stacked top to bottom, all steps and charts shown, comments still pinned. Nothing extra to build. Good for sending a deck to someone who reads rather than watches.
- **Report / infographic** (`template/report.html`): a designed long page like Canva report templates. Build it from the same outline and numbers as the deck, not by copying slides:
  - Header: hero photo strip, title with one `<em>`, 2 outline badges (brand, period), one-line lede.
  - Row of 3 KPI cards (`.card.kpi.c-4`); make the most important one `.solid`.
  - Main chart `.c-8` + a narrow ranked chart `.c-4`; rings row `.c-12` (`"label":false` rings + big % below); `.c-6` pairs (stacked bar, pictogram); `.c-5` quote card + `.c-7` recommendations.
  - Card style per reference: `outline` (rounded 1.5 px borders), `tint` (flat tinted blocks), `band` (header band + uppercase centred title). Set `data-cards` default in the first script, K cycles it.
  - Each card: header = what it is, `h3` = the takeaway sentence, then the chart.
  - PDF: `export_pdf.py report.html --theme sage --cards outline` gives one long page 1200 px wide. PNG: render that PDF with fitz.
  - Comments: publish with `capabilities: {"comments": {"composer_only": true}}`; the Comment button arms, then a click on a card opens the claude.ai composer on that card.

Extra chart types (both files): `radar` (`{"type":"radar","axes":[…],"series":[{"name":"Maya","values":[…]},{"name":"Average","values":[…]}],"max":10}`, ≤ 8 axes, ≤ 3 series, first series is the focus), `line` with `"multi":true` (all series coloured + dots + legend), `bar` with `"stack":true`, `ring` with `"label":false`, `picto` (`{"type":"picto","rows":[{"label":"Women","value":72},{"label":"Men","value":28}],"icons":10}`). `hbar` switches to labels-above-bars in narrow cards.

## Editing text in the page (W)

Every deck and report has **Edit text** (key W; report: Edit button). Click a headline, number, label, paragraph, list item or table cell and type (any other leaf element, e.g. a `<span>` or `<b>` inside a custom chip or timeline bar, becomes editable when it carries a `data-edit` attribute); Enter or Esc finishes a line, Shift+Enter adds a line in paragraphs. Save:
- **On the claude.ai link** the edits are written to `edits.json` beside the page (files publish), so everyone with the link sees them. Publish with `capabilities` including `"artifact": {}` and `files: {"edits.json": <file containing {}>}`.
- **Anywhere else** (local file, GitHub Pages) they stay in that browser; **Copy edits** copies them as JSON for Claude.
- Charts are not edited in the page (their numbers live in `data-chart`); ask Claude.
- **Style bar.** While Edit text is on, a dark bar floats above the text block that has focus (code in `template/_textstyle.js`). It has Font (theme heading, theme body, the CoBa brand fonts Sen and Playfair Display, plus 11 more Google Fonts, all loaded on demand), size A− / px box / A+, B I U, text colour and highlight (theme colours as `var(--x)` so they follow the theme, fixed colours, a custom picker), align left / centre / right, and Clear.
  - With words selected it styles only those words. With just a caret it styles the whole block. After a change the styled words stay selected, so you can stack font + size + colour.
  - Every change goes through the browser's own `insertHTML` / `execCommand`. Ctrl/Cmd+Z and Ctrl/Cmd+Shift+Z (or Ctrl+Y) undo and redo it like typing, Ctrl+Z works on a Mac too, and the change is saved by the normal Save button.
  - It is stored as inline `<span style>` (allow-listed: color, background-color, font-family, font-size, font-weight, font-style, text-decoration, text-align, display:block) plus `<b> <i> <u> <s>`, and alignment as `<span data-align style="display:block;text-align:…">`. The page's `clean()` and `bake_edits.py` use the same allow-list; no `url(` is ever kept. Fonts used by saved edits load on page open; `bake_edits.py` adds the Google Fonts `<link>`.
  - Keep `FONTS` in `_textstyle.js` and `FONTS` in `bake_edits.py` in step.

Before changing a published deck yourself, pull the edits in so nothing is lost:
1. Artifact tool `read` with `path: "edits.json"` (or the JSON the user pasted).
2. `python3 scripts/bake_edits.py deck.html edits.json`
3. Republish the page with `files: {"edits.json": <{}>}` to reset it.
Keys are position-based ("s3:5" = slide 3, 6th editable element), so bake BEFORE adding, removing or reordering slides or text blocks.

## Cropping images in the page (double-click)

Every content image on a slide or report card can be re-cropped in place (all three templates; code in `template/_imgcrop.js`, injected between `imgcrop:begin/end` markers after the edit-text script).
- Double-click an image: crop mode. The frame (parent box) keeps its size.
- Drag to choose what shows (changes `object-position`, starting from the value in the HTML). Mouse wheel or the slider zooms inside the frame (`transform: scale`, origin at the object-position point, minimum 1 so the image always covers the frame).
- Toolbar: Fit (zoom back to 1), Reset (the HTML's original position, zoom and shape), Done. Esc or a click outside also exits and keeps the crop.
- Image / Frame toggle: Image mode drags the photo inside the frame; Frame mode drags the whole frame across the slide (CSS `translate`). Four corner handles resize the frame in either mode (Shift keeps the shape); the opposite corner stays put. A moved or resized frame gets `z-index:4` so it sits on top.
- Undo / redo: Ctrl/Cmd+Z undoes the last image change, Ctrl/Cmd+Shift+Z or Ctrl+Y redoes (also the ↶ ↷ toolbar buttons). One step per finished gesture (drag, wheel burst, slider, shape, Fit, Reset), up to 200 steps, and it still works after Done (the undone state is saved). Inside editable text the browser's own undo runs instead.
- Shape row: Original (the layout's own corners), Square, Rounded, Arch, Pill, Oval, Circle. Applied to the frame with border-radius / clip-path, so it follows the frame at any size. Saved as `"s"` in the crop value; bake_edits.py writes shape, move and size onto the frame's style.
- Clicks on images, and the click that closes crop mode, never advance the deck (a double-click would otherwise move the slide first); clicks on the crop toolbar always go through.
- **Replace the photo.** The Replace button in the crop bar opens a file picker. You can also drop an image file on any croppable image (no need to open crop mode), or paste an image while cropping. The new photo is shrunk to 1600px on the long side (PNG kept if under ~900KB, else JPEG 0.85), starts centred at zoom 1, and is saved as `"u"` (a data URL) in the crop value. Reset and Ctrl+Z bring the original back. `bake_edits.py` writes it to `img/edit-img-s3-2.jpg` beside the page and points the `<img>` at it. Large photos make `edits.json` heavy; for more than a handful, bake and republish.
- Elements with a CSS `background-image: url(…)` get the same controls via `background-position` + `background-size`.
- Skipped: `img.logo`, avatars, icons, toolbar/nav/button images, chart graphics, anything inside `[data-nocrop]`.
- Saved with the text edits in `edits.json` (claude.ai link) or this browser: keys `img:s3:2` (slide 3, 3rd image) / `img:r:4` (report) and `bg:…`, value `{"p":"40% 30%","z":1.25,"s":"arch","dx":12,"dy":-8,"w":420,"h":300}` (dx/dy/w/h in slide px). `scripts/bake_edits.py` writes `img:` keys into the `<img>` style; `bg:` keys are reported, not baked. Image keys are position-based too: bake before adding or reordering images.
- After changing `_imgcrop.js` or `_textstyle.js`, run `python3 scripts/inject_modules.py` (templates + examples; add built page paths as arguments to update those too). It also upgrades an older page's text sanitiser so styled spans survive.

## Icons

`<i class="i i-up"></i>` and `i-down`, `i-up-right`, `i-down-right`, `i-right` draw as inline SVG in the text colour. Arrow = which way the number moved; colour = good or bad for us: wrap in `.good` (green) or `.bad` (red). Cost going up is `<b class="bad"><i class="i i-up"></i> +$40</b>`.

## Tag people (@)

Toolbar **@ Tag** (key @): click a spot on a slide (or a card in a report), search the company directory, pick people, add a note, **Tag**. Only people whose email ends with `@yourcompany.com` are offered (`TAG_DOMAIN` at the top of the tag script; change it for another company). A pin with the first person's avatar and a count sits on that spot; click it for the note, **Mark done** or **Delete** (author or owner). Anyone tagged sees **Tagged for you (n)** in the toolbar and jumps to each spot from there.
- Tags are stored in the artifact's `db` (collection `tags`), so everyone with the link sees them. Publish with `capabilities` that include `"db": {}` and `"user": {"scopes": ["profile"]}` next to comments/artifact. The `"email"` scope is refused on this account ("unknown scope"), so do not declare it.
- The platform sends **no email or notification**; people see tags when they open the page. Tell them in chat to check the link, or send the link yourself.
- Search only reaches people in the owner's claude.ai organization (YourCompany), and guests are dropped. Without the email scope the page sees no emails, so the @yourcompany.com check only applies if emails ever come back; in practice the organization boundary does the filtering.
- Viewers without Contributor access see the pins but cannot add tags.

## Comments (Google Slides style)

On the claude.ai link, the toolbar shows **Comment** (key M). Click it, click a spot on the slide, and the claude.ai composer opens there. Threads, replies, @mentions, resolve and the full comment list are the claude.ai comment system; the deck only pins each thread to its slide and position (anchor `s05@42.1,31.0`). Opening a thread from the list jumps to its slide. Pins move with the slide and can be dragged by their author. Local files and GitHub Pages copies have no comments (the button stays hidden). Read comments later with the `ArtifactComments` tool.

## Google Slides / PowerPoint

```bash
python3 ~/.claude/skills/arie-deck-builder/scripts/export_pptx.py <deck_dir>/deck.html --lang en
```
Upload the .pptx to Google Drive (or save it inside the synced Drive folder) and open with Google Slides. The slides look identical but are pictures; the text is in the speaker notes. An editable Slides version would have to be rebuilt with native shapes and loses most of the design, so offer it only when the user needs to edit text in Slides.

## Authoring reference

| Need | Markup |
|---|---|
| Slide | `<section class="slide L3" data-title="…" data-sec="Section">` inside `#stage`, before `<canvas id="ink">` |
| No chrome (cover, close) | add `data-bare` |
| Full-colour slide | add class `on-p` (primary) or `dark` |
| Headline highlight | `<h2>Drive sales with <em>smarter data</em></h2>` — theme decides colour / pill |
| Reveal on → | `data-step="1"`, `"2"`… same number appears together |
| Motif | `<svg class="motif"><use href="#motif"/></svg>` |
| Decorative shape | `<div class="shape" style="width:…;height:…;left/right/top…"></div>` |
| Photo slot | `<div class="ph" data-label="what goes here"><img src="img/x.jpg" alt=""></div>` |
| Two languages | `<span class="en">…</span><span class="vi">…</span>` |
| Box-sizing | all slide children are `border-box`; widths include padding |

- Slide size 1600×900. Margins 96 px sides. Body ≥ 19 px, headlines 60–88 px, covers 110–136 px.
- Headlines are claims, ≤ 2 lines. Short plain copy (user's tone rules). All deliverable text in English unless the user asks for VI.

## Presenter keys (built in)

→ / Space next step · ← back · P pen · H highlighter · A arrow · R box · O circle (Shift = square / perfect circle) · L laser · E erase · C clear slide · 1–6 colour (recolours the selected drawing; edit `COLORS`) · I add image (or ⌘V, or drop a file) · Esc tool off · W edit text · M comment · V language · T theme (library only) · S scroll view · G overview · F full screen · ? help. With no tool on, drawings are objects: drag to move, corner dots to resize, arrow end dots to re-aim, Del to remove. `#s4` opens slide 4.

Drawings and added images are saved in that browser only (localStorage `deck-state:<title>`).

- **One-file copy:** `python3 scripts/make_standalone.py page.html` writes `page_standalone.html` with every local image inlined and a full document wrapper. Give this file when the user wants "the HTML file": the plain built page is a fragment (claude.ai adds `<html><body>`), so opened directly it loses its theme and its img/ photos.

- **Reports also get the deck's presenter tools** (injected by `scripts/inject_modules.py`, reports only):
  - `+ Image` (`template/_addimage.js`): add a photo with the button, or drop or paste it on a card. Drag to move it (drop it on another card to move it there), drag the corner to resize, × or Delete removes it. Double-click it to open the crop tools: crop, shape, frame, replace, undo. Saved as `added:r` in edits.json, or in the browser.
  - `✎ Draw` (D) (`template/_annotate.js`): pen, highlighter, arrow, box, circle, eraser, 6 colours, Ctrl/Cmd+Z, Clear. Saved as `ink:r`.
  - Gotcha: a build script that regex-replaces `const T = [...]` to lock themes must not touch module code. The draw module uses `TOOLS` for that reason.

## Limits to tell the user

- The artifact viewer blocks printing, so PDF and PPTX export run locally with the scripts (not possible from claude.ai chat).
- Drawings and live-added images stay in one browser. Images meant for everyone go into the HTML.
- Reference colours sampled from screenshots are approximate; exact brand hexes beat them.
- Engine changes: `deck.html` and `layouts.html` share the same engine code. Edit both.

## Logo lock (CoBa and any brand)
Never redraw, retype, trace or recolour a logo (no SVG, no text in a font, no CSS filter). Use only official logo PNG files supplied by the brand, scaled uniformly, black on light and white on dark.

Product photos and labels: never generate, redraw or AI-edit packaging. For ads and product scenes use the `static-ad-builder` skill (real product restore, label OCR + pixel QA).

## Morph transitions

Built into every deck template (`template/_morph.js`, injected by `scripts/inject_modules.py`). Give an element the same `data-morph="key"` on two neighbouring slides and it glides from its old position, size, rotation, corner radius, colour and opacity to the new one; the rest of the new slide fades in after it. Morph elements should be absolutely positioned boxes.
- Built-in charts (`.chart[data-chart]`, every type: line, bar, stacked, hbar, ring, donut, radar, picto): give the chart the same `data-morph` key on both slides, keep the same `type`, change the numbers (and position or size if you like). The chart moves and redraws every frame with in-between numbers, so bars grow, lines bend, donut slices and rings turn, radars reshape, labels count. Keep the same number of labels/series for a clean morph.
- Hand-built bar charts: draw each bar as its own box with `data-morph="bar3" data-morph-box` (box scaling, not text scaling). Re-order or resize the bars on the next slide and they re-rank. Put `data-count` on value labels so numbers count up or down. Zoom into one bar by making it a full-height panel on the next slide.
- Cards: same photo cards stacked (CSS `rotate`), then fanned, then one opened to half the slide.
- Tabs: a `data-morph-box` pill behind the active tab moves to the next tab; the tab's photo frame morphs to its new place.
- Words: `data-morph-split="words"` (or `"chars"`) turns a sentence into pieces that rearrange into the next slide's sentence; punctuation is ignored when matching.
- Write morph slides as a pair that shows ONE change, and say the change in the title: the first slide states the before ("July: 24% of the Q3 budget committed"), the second states before → after with the delta highlighted in <em> ("September: 24% → 84% committed, $16K left"). Name the time or condition on both slides so the jump is never unexplained. Never morph two unrelated numbers into each other.
- Make the change visible beyond size: shift the slide background (cream → brand dark), recolour the accent shape behind the hero number, change its shape (circle → rounded square, rotate), and add a big delta label ("+209%", "2×", "5 → 8") on the after slide.
- Text pairs cross-fade while they travel (old wording fades out as the new fades in), so titles can change words. The slide background blends between the two slides' colours.
- Photos: same `data-morph` key on a photo frame on both slides. Patterns that work (demo slides 25–34):
  - One → many: a full-bleed hero on slide A becomes one tile of a 6-photo grid on slide B; the other tiles fade in after it lands.
  - Photo → page: the same photo becomes the hero inside a mock product page or app screen (browser frame, headline, button around it).
  - Small ↔ big: a strip of three becomes one big photo plus two circle thumbnails; step through each, changing the frame shape (arch → circle → rectangle via border-radius).
  - Carousel: photos on an ellipse; add `data-morph-orbit="cx,cy,rx,ry"` (slide px) so they travel around the ring instead of in straight lines, growing at the front and shrinking at the back. Set z-index and opacity by depth; they animate too.
  - Each step's title and caption say what the photo is ("01 / 03 Unwind — evening oil"), so the motion follows the information.
- Photos keep their aspect while the frame changes. Rotation must use the CSS `rotate` property. Skipped in scroll view and for reduced motion. Not carried into PPTX.
- Demo of every pattern: 03_outputs/morph_demo/deck.html (slides 2–12).

## Brand kit layouts (B31–B47, inside template/layouts.html)
17 editorial layouts in the same engine as L1–L30, so they get every tool (edit, crop, comments, morph, PDF/PPTX). They read the normal theme tokens, so any theme works. Themes added for them: `halio` (Halio guideline: Manrope, #58151F / #23080C / #F7F8F3, sand neutrals, 15px corners, pill buttons), `studio` (black / red / cream, Archivo Black caps, B&W photos), `green` (green field, yellow tag labels, pink accent, black cards). `coba` also styles them (Sen + Playfair italic em).
B48–B55 are photo-led (see below).
B31 Cover giant word · B32 Contents · B33 Statement/Ethos · B34 Approach (dark, numbered) · B35 Stats bars · B36 Card grid (tag labels) · B37 Roadmap · B38 Team · B39 Infographic (boxed, big numbers) · B40 SWOT quadrants · B41 Word stack · B42 Thank you · B43 Product hero · B44 Before/after · B45 Compare 3 products · B46 Quote · B47 CTA.
Kit classes are prefixed (bD display, bHi accent, bTag label, bBox card, bList numbered list, bPill button, bChip, bP body). Keep `data-bare` on them: they carry their own furniture.

## Pick the layout from the content, not the other way round
Classify each piece of content first, then choose. If it does not fit, split it into two slides; never shrink type to make it fit. If no layout fits, build one and add it here.
| Content | Layouts |
|---|---|
| Opening, chapter break | L1, B31, L11, B33 |
| List of 3–7 points | B34, L25, B32, B41, L29 |
| 1–4 headline numbers | B35, L3, L18, L7, L26 |
| Trend or comparison over time | L4, L13, L19, L14, dataviz charts |
| Many parts on one slide (report, analysis) | B39, L20, L5, B40, B36 |
| Plan, schedule | B37, L6, L30 |
| People, creators | B38, L9 |
| Product | B43, B45, L27 |
| Proof: before/after, A vs B | B44, L28, L16 |
| Quote, customer voice | B46, L2 |
| Money | L8, L17, L15 |
| Close, ask | B47, B42, L12 |
Brand rules still apply on top: Halio headlines ≤6 words, title case; CoBa max 3 colours, no gradients; never redraw a logo.

## Type scale (BCG standard, measured from the BCG x Altagamma 2021 deck at 1600 px)
Action title 40 · sub-head / chart title 30 · callout 24 · body 20 · label / legend 15–18 · note + source 13. Headline numbers 48–80, light weight with the figure bold. Giant display words (100–400) only on covers, chapter breaks and one-word statements. Never set body below 18 to make text fit: split the slide.

## Photos are part of the layout, not decoration
Marketing decks: at least every other slide carries a photo. Photo-led layouts: B43 product hero, B44 before/after, B48 photo + chart + callouts, B50 photo + 2 cards, B51 three photo columns, B52 personas, B53 feed grids, B54 colour bento, B55 photo + KPI strip, plus L3, L9, L23, B33, B38, B42.
When the user sends a photo set: look at every image, tag it (product only · in use · lifestyle · skin/texture close-up · group · flat lay · environment; portrait/landscape/square; clean or busy background; where the subject sits), then give each slot the image whose role and aspect fit, set object-position so the subject is not cut, and never reuse one photo twice in a deck unless asked. Cut-out (no background) PNGs go to B48 / B43; wide shots to B55 / full-bleed; portraits to B52 / B38. Only real, approved photos; never AI mockups of a real product.

## Report chart style "q2" (template/report_q2.html)
Learned from the boss's CoBa Q2'26 brand report. Use for quarterly/monthly business reports.
Look: page #F1F1F1, white chart cards (1px #E6E0D5, 8px radius), Plus Jakarta Sans. Section tag = orange number chip + orange caps label (19px). Action title 38px bold, the key number or phrase in bold italic orange #BF5B2E (green #3F6B4F for a positive headline delta). Body 17–19, chart title 16 bold + one grey "how to read" line 13 (axis, unit, what dashed lines mean). Series palette in order: caramel #B9875A, sage #6E9478, mauve #A8737A, black #1F1F1F, gold #C7A25A; track #EFEADF.
Rules: KPI row of 4–5 tiles first (number 34–38, bold label, delta line ▲ green / ▼ red "vs Q1"). Every chart names its marketing moments with dashed orange vertical lines and labels. Values sit on the bars; ranked bars are sorted largest first with dot + label left, value right. Reference lines dashed (100% target, 1.0× break-even). Sub-labels under groups turn red when they break a rule. Every slide closes with an IMPLICATION box (green tint #EFF3EC, last sentence bold) and, when there is a risk, a WHAT SHOULD BE NOTICED / LOWLIGHTS box (pink #F7E9E5). Exec summary = KPI grid + A What moved / B What's at risk / C What's next / D What's new.
Chart functions in the file: rankBars, stackedDaily (with events), combo (bars + indexed lines), grouped (with sub-labels), mini (small multiples + break-even), donut, target (% of target, traffic light), stackH (owned/earned/seeding), dual (two axes), table (dark header, coloured delta column).
