---
name: arie-report-charts
description: "Quarterly and monthly business report slides in the boss's Q2'26 CoBa report style: grey page, white chart cards, Plus Jakarta Sans, orange bold-italic key number in the action title, KPI tile rows with deltas vs last period, event-marked charts, 'how to read' line under every chart, IMPLICATION and WHAT SHOULD BE NOTICED boxes, A/B/C/D executive summary. 14 chart functions (heatmap, radar, waterfall, funnel, ranked bars, stacked daily with events, bars + indexed lines, grouped with sub-labels, small multiples with break-even, donut, % of target, owned/earned/seeding stack, dual axis, delta table). Use for brand reports, sales reviews, marketing spend reviews, QBR, 'báo cáo quý', 'báo cáo tháng', 'vẽ chart như sếp'."
---

# Arie Report Charts

One HTML file, 1600x900 slides, arrow keys to move, prints to PDF one slide per page.

## How to use
1. Copy `template/report.html` next to the user's data. Never edit the user's own files in place.
2. Keep the CSS and chart functions. Rewrite the slides and the data block at the bottom (`rankBars(...)`, `grouped(...)` etc.).
3. Each slide: section chip → action title (≤2 lines, key figure in `<em>`) → KPI row → 1–2 chart cards → IMPLICATION box. Add a WHAT SHOULD BE NOTICED box only when there is a real risk.
4. Export: `python3 scripts/export_pdf.py report.html --out report.pdf`, then look at every page before sending.
5. One-file share with photos: `python3 scripts/embed_images.py report.html`.

## Interactive deck (edit text, shapes, photos)
`python3 scripts/build_report_deck.py report.html deck.html --name "Q3 Brand Report"` puts the slides on the Deck Builder engine (template/engine.html). The deck then has: Edit text (W) with the style bar (font, size, colour, highlight, bold/italic, align, Ctrl+Z) on titles, KPI numbers and labels, chart titles, how-to-read lines, box text and table cells; photo slots (`<div class="ph">`) with crop, zoom, shape, move/resize and replace; pen, highlighter, arrows and shapes; comments; scroll view; theme menu does not touch the report look (CSS scoped to .slide.R). Charts are SVG: change their numbers in the data block, then rebuild.
Publish the built deck as an Artifact with capabilities {"comments":{"customAnchors":true},"db":{},"user":{"scopes":["profile"]}} so edits and comments save. PDF: `python3 scripts/export_pdf.py deck.html`. PPTX: `scripts/export_pptx.py` (image) or `scripts/export_pptx_editable.py` (text editable).

## Writing rules
Title says the finding, not the topic. Numbers in titles match the tiles. Every delta says what it compares to (vs Q1, vs target, YoY). Define any metric a reader might not know (MER, NMV) once. Last sentence of each IMPLICATION is the action, in bold.

## Sample data
All numbers in `template/report.html` are fictional. Replace them with the user's real data.

## Style reference
Learned from the boss's CoBa Q2'26 brand report. Use for quarterly/monthly business reports.
Look: page #F1F1F1, white chart cards (1px #E6E0D5, 8px radius), Plus Jakarta Sans. Section tag = orange number chip + orange caps label (19px). Action title 38px bold, the key number or phrase in bold italic orange #BF5B2E (green #3F6B4F for a positive headline delta). Body 17–19, chart title 16 bold + one grey "how to read" line 13 (axis, unit, what dashed lines mean). Series palette in order: caramel #B9875A, sage #6E9478, mauve #A8737A, black #1F1F1F, gold #C7A25A; track #EFEADF.
Rules: KPI row of 4–5 tiles first (number 34–38, bold label, delta line ▲ green / ▼ red "vs Q1"). Every chart names its marketing moments with dashed orange vertical lines and labels. Values sit on the bars; ranked bars are sorted largest first with dot + label left, value right. Reference lines dashed (100% target, 1.0× break-even). Sub-labels under groups turn red when they break a rule. Every slide closes with an IMPLICATION box (green tint #EFF3EC, last sentence bold) and, when there is a risk, a WHAT SHOULD BE NOTICED / LOWLIGHTS box (pink #F7E9E5). Exec summary = KPI grid + A What moved / B What's at risk / C What's next / D What's new.
Chart functions in the file: heat (one-hue caramel ramp, value in cell, best cell outlined orange), radar (filled series + dashed target), waterfall (green add / red loss / dark totals, dashed connectors), funnel (step conversion, worst step orange), rankBars, stackedDaily (with events), combo (bars + indexed lines), grouped (with sub-labels), mini (small multiples + break-even), donut, target (% of target, traffic light), stackH (owned/earned/seeding), dual (two axes), table (dark header, coloured delta column).
