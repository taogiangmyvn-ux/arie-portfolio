"""Turn a report page (template/report.html style) into an interactive deck on the Deck Builder engine:
edit text with the style bar, crop/replace photos, comments, pen/shapes, scroll view, PDF/PPTX export.

    python3 build_report_deck.py report.html out.html [--name "Q3 Brand Report"]

The report keeps its own look: its CSS is scoped to .slide.R so the engine theme does not touch it.
"""
import argparse, pathlib, re

HERE = pathlib.Path(__file__).resolve().parent.parent
ENGINE = HERE / "template" / "engine.html"
EXTRA_EDIT = ",.R h4,.R h5,.R .how,.R .kpi b,.R .kpi span,.R .kpi small,.R .sec span,.R .leg span"


def scope(css):
    out = []
    css = re.sub(r"@media print\{.*?\}\}", "", css, flags=re.S)
    for sel, body in re.findall(r"([^{}]+)\{([^{}]*)\}", css):
        sel = sel.strip()
        if sel.startswith("/*"): sel = re.sub(r"/\*.*?\*/", "", sel, flags=re.S).strip()
        if not sel or sel.startswith("@"): continue
        parts = []
        for s in sel.split(","):
            s = s.strip()
            if s in (":root",): parts.append(".slide.R")
            elif s in ("html", "body", "html,body", "#stage", "#nav") or s.startswith("#stage") or s.startswith("#nav"): continue
            elif s == "*": parts.append(".slide.R *")
            elif s in (".slide", ".slide.on"): continue   # the engine owns slide position, visibility and print
            elif s.startswith(".slide"): parts.append(s.replace(".slide", ".slide.R", 1))
            else: parts.append(".slide.R " + s)
        if parts: out.append(",".join(parts) + "{" + body + "}")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("report"); ap.add_argument("out"); ap.add_argument("--name", default="Report")
    a = ap.parse_args()
    r = pathlib.Path(a.report).read_text(); t = ENGINE.read_text()
    css = scope(re.search(r"<style>(.*?)</style>", r, re.S).group(1))
    css += "\n.slide.R{box-sizing:border-box;padding:46px 56px;background:var(--page)!important;color:var(--ink);font-family:var(--f)}\n.slide.R .sec i{font-style:normal}\n.slide.R p{color:inherit}\n"
    fonts = re.findall(r'<link rel="stylesheet" href="(https://fonts.googleapis.com[^"]+)">', r)
    secs = re.findall(r'<section class="slide">.*?</section>', r, re.S)
    titles = [re.sub(r"<[^>]+>", "", (re.search(r'<div class="sec">(.*?)</div>', s, re.S) or re.search(r"<h2>(.*?)</h2>", s, re.S)).group(1)).strip() for s in secs]
    secs = [s.replace('<section class="slide">', f'<section class="slide R" data-title="{ti}" data-bare>', 1) for s, ti in zip(secs, titles)]
    js = re.search(r"(/\* ---------- tiny chart kit.*?)/\* ---------- nav", r, re.S).group(1)
    js = js.replace("getComputedStyle(document.documentElement)", 'getComputedStyle(document.querySelector(".slide.R"))')
    start = t.index('<section class="slide'); end = t.index('<canvas id="ink"')
    t = t[:start] + "\n".join(secs) + "\n<script>/* report charts: drawn before the engine indexes editable text */\n" + js + "</script>\n    " + t[end:]
    i = t.index("</style>"); t = t[:i] + "\n/* ---- report:begin ---- */\n" + css + "\n/* ---- report:end ---- */\n" + t[i:]
    for f in fonts: t = t.replace("</title>", f'</title>\n<link rel="stylesheet" href="{f}">', 1)
    t = t.replace('const EDIT_SEL = "h1,h2,h3,p,li,td,th', 'const EDIT_SEL = "h1,h2,h3,p,li,td,th' + EXTRA_EDIT, 1) if EXTRA_EDIT else t
    t = t.replace('data-deck="Holiday Creator Campaign"', f'data-deck="{a.name}"', 1)
    t = re.sub(r"<title>.*?</title>", f"<title>{a.name}</title>", t, count=1)
    pathlib.Path(a.out).write_text(t); print("wrote", a.out, "·", len(secs), "slides")


if __name__ == "__main__":
    main()
