---
name: arie-dataviz
description: "Data visualization slides in the style of BCG / consulting insight decks (True-Luxury Global Consumer Insight, BCG city and industry reports), but cleaner and more aesthetic. Turns numbers, survey results and market data into action-titled slides with 12 consulting chart types (100% stacked columns, answer bubbles with group totals, yes/no split bars, waterfall, slope, dumbbell, ranked bars with average, growth columns with CAGR, marimekko, 2x2 matrix, harvey-ball table, funnel), survey question boxes, delta callouts, takeaway bands and source lines. Works with arie-deck-builder (same engine, themes, editing, morph, PDF/PPTX). Use for data slides, charts, survey results, market sizing, consulting-style or BCG/McKinsey-style decks, insight reports, 'slide số liệu', 'biểu đồ đẹp'."
---

# Dataviz slides by Arie

Data slides that read like a top consulting deck: every slide states one finding, the chart proves it, and the text around the chart tells the reader exactly what to look at. Built on the Deck Builder by Arie engine, so decks keep presenter tools, editing, comments, morph and export.

Files:
- `template/_dataviz.js`: the 12 chart types (SVG, theme colours, plugs into the deck's chart pipeline and morph).
- `template/_dataviz.css`: slide anatomy blocks (`vz-title`, `vz-lead`, `vz-h`, `vz-q`, `vz-delta`, `vz-band`, `vz-note-box`, `vz-kpi`, `vz-bullets`, `vz-foot`).
- `scripts/build_viz_deck.py`: slides file → full deck on the deck-builder engine.
- `scripts/add_dataviz.py`: add or update the dataviz layer in an existing deck (e.g. one built with arie-deck-builder).
- `examples/demo_slides.html` + `examples/demo_deck.html`: one slide per pattern, sample data. Copy from these.

## Workflow

1. **Get the data and the question.** For each slide, write the one finding first, in a sentence with a number. If you cannot, the slide has no point; merge or cut it.
2. **Outline in chat**: # · action title · chart type · lead/question/callout · source. Group slides into sections (`data-sec`, shown top right).
3. **Write the slides** in a slides file (only `<section class="slide">` blocks), using the anatomy below and the chart picker.
4. **Build**: `python3 ~/.claude/skills/arie-dataviz/scripts/build_viz_deck.py slides.html out/deck.html --theme sage --name "Deck name"`. Any deck-builder theme works (`coba` for CôBa's Daughter). Mixing with designed slides: build the deck with arie-deck-builder first, then paste the data slides in and run `add_dataviz.py deck.html`.
5. **Check**: export the PDF with `~/.claude/skills/arie-deck-builder/scripts/export_pdf.py`, render pages with PyMuPDF, look at every page: overlaps, clipped labels, titles over 2 lines, footer clashes. Fix once.
6. Publish or export exactly as in arie-deck-builder (link, PDF, PPTX).

## How consulting slides are written (the part that matters most)

Studied from BCG x Altagamma True-Luxury Consumer Insight 2021 and BCG reports (NYC media, NYCHA, Port of LA, Sweden ventures).

1. **Action title = the finding, as a full sentence with the number.** "1 out of 2 true luxury consumers, among the 39% aware, has bought luxury in-game items". Never a topic ("In-game purchases"). Max 2 lines (~110 characters). Highlight the key number or phrase with `<b>` (theme colour).
2. **Colon for the implication.** "…Chinese instead, expected to increase their spend, but only domestically: China repatriation trend to stay". Before the colon: what the data says. After: what it means.
3. **Chain slides with "…"**. End one title or lead with "…" and start the next with "…" when one idea spans two slides or two panels ("Before COVID-19 hit, 56% … were done abroad…" → "…Chinese instead, expected to…").
4. **Panel lead above each chart**: one sentence, the key phrase in bold (`vz-lead`). Or a chart header with units (`vz-h`: "Online beauty sales, Vietnam ($M)" + small line "2027 is a forecast").
5. **Survey question in a quote box, word for word** (`vz-q`), with the filter in brackets: "[Of those aware] Have you ever…". The reader must know exactly what was asked.
6. **Group bracket with the total**: when the story is a sum of answers, bracket them and print the sum ("From half to all of it 69%"). The `bubbles` chart does this with `"group"`.
7. **Delta callout**: big change + comparison + one sentence why (`vz-delta`): "−4 p.p. vs last year 73%" | "Even if the pandemic is more relaxed, some **consumption habits could have changed** for the medium term".
8. **Takeaway band** at the bottom (`vz-band`): the "so what" in one line, 2 bold phrases max.
9. **Note box** pointing at a group (`vz-note-box`): "Relevant for Chinese and US consumers".
10. **Footer, always**: `Note:` definitions (what "Europe" includes), then `Source:` with sample size and date ("Survey Mar/Apr 21, 12K respondents in 12 countries"). Sample or illustrative numbers must say so, and add `data-sample` on the slide.
11. **Bullets** (`vz-bullets`): bold lead-in, then the detail. 3–4 bullets, each one line or two.
12. Plain words, short sentences, no adjectives that do not change a decision. Numbers: `~18%`, `2×`, `+6 p.p.`, `$1.4M`, "1 in 2".

## Chart picker

| Question | Chart | `type` |
|---|---|---|
| How is a whole split, and how did the split change over years? | 100% stacked columns, series named on the left | `stack100` |
| How did people answer one survey question? | answer bubbles, optional group bracket + sum, one highlight | `bubbles` |
| Yes vs no by segment | split bars, dashed remainder, band on key rows | `split` |
| What added up to the change from A to B? | waterfall (totals dark, ups accent, downs red) | `waterfall` |
| Who moved between two dates? | slope, one line highlighted | `slope` |
| Before → after per item | dumbbell (open dot before, filled after) | `dumbbell` |
| Who is top, and vs the average? | ranked bars, one highlight, dashed average | `rank` |
| How fast is it growing? | growth columns + CAGR pill, dashed forecast bars | `growth` |
| Size and mix at once | marimekko (width = size, stack = mix) | `mekko` |
| Where to play / what to do first | 2x2 matrix, sized points, highlighted quadrant | `matrix` |
| Compare options on criteria | harvey-ball table (0–4) | `harvey` |
| Where do people drop off? | funnel with step conversion % | `funnel` |
| Simple trends, parts, rings, radar | use the deck builder's own charts | `line`, `bar`, `hbar`, `ring`, `donut`, `radar`, `picto` |

Markup: `<div class="chart" data-chart='{"type":"rank", ...}' style="left:96px;top:290px;width:900px;height:470px"></div>`. Full option sets are in `examples/demo_slides.html`; every chart takes `prefix`, `suffix`, `dec`.

## Look (why these charts do not look raw)

- One hue family from the theme: `--p` for the thing that matters, soft and faint tints for the rest, `--s` accent for growth, red only for losses. Never rainbow.
- Highlight exactly one thing per chart (a bar, a bubble, a line, a quadrant). Everything else is muted.
- Direct labels on or next to the data; no legends unless unavoidable, no gridlines, one baseline, no chart borders.
- Rounded ends on ranked bars, 3px corners on columns, dashed lines only for remainders, forecasts, connectors and averages.
- Labels get a paper-coloured halo where lines cross them.

Type scale on the 1600×900 slide: action title 44px (500 weight) · panel lead 23px · question box 19px · chart header 19px semibold · data labels 20px · category labels 18px · notes 15–16px · footer 13.5px. Margins 96px. Content zone from y≈220 to y≈800; footer at the bottom.

## Morph

Data charts plug into the deck's morph: same `data-morph` key + same `type` on two neighbouring slides and the numbers tween (bars grow, bubbles change, waterfall steps move). Follow the deck-builder morph rules: one change per pair, title says before → after.

## Limits

- Charts are SVG drawn in the page; the PPTX export keeps them as part of the slide picture (hybrid mode keeps titles and text editable).
- Long category names: keep under ~18 characters or break with `\n` (stack100 series names, bubble labels, waterfall labels support `\n`).
- The `matrix` takes x/y on 0–100; scale your data to that range.
