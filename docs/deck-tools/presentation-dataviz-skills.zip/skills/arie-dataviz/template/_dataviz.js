/* ---- Arie Dataviz: consulting-grade charts for Deck Builder by Arie ----
   Use: <div class="chart" data-chart='{"type":"stack100", ...}' style="position:absolute;left:..;top:..;width:..;height:.."></div>
   Types: stack100, bubbles, split, waterfall, slope, dumbbell, rank, growth, mekko, matrix, harvey, funnel.
   Colours come from the deck theme (--p primary, --s accent, --ink, --muted, --line, --paper), so every chart is on brand.
   It plugs into the deck's chart pipeline (window.drawChart / renderCharts), so morph tweens these charts too.
   Text sizes are tuned for a 1600x900 slide: data labels 20px, category labels 18px, notes 15px. */
(() => {
  const NS = "http://www.w3.org/2000/svg";
  const mk = (tag, a, p) => { const e = document.createElementNS(NS, tag); for (const k in a) e.setAttribute(k, a[k]); p && p.appendChild(e); return e; };
  const txt = (p, x, y, s, a = {}) => { const t = mk("text", { x, y, ...a }, p); t.textContent = s; return t; };
  const v = (box, n) => getComputedStyle(box).getPropertyValue(n).trim();
  const fmt = (n, c = {}) => (n < 0 ? "−" : "") + (c.prefix || "") + (Math.abs(n) >= 1000 && !c.raw ? Math.abs(n).toLocaleString("en-US") : (c.dec != null ? Math.abs(n).toFixed(c.dec) : +Math.abs(n).toFixed(Math.abs(n) < 10 && n % 1 ? 1 : 0))) + (c.suffix || "");
  function pal(box) {
    const P = v(box, "--p") || "#2E6B4F", S = v(box, "--s") || "#5DBB7A", paper = v(box, "--paper") || "#fff", ink = v(box, "--ink") || "#1d1d1d";
    const mix = (c, pct, b = paper) => `color-mix(in srgb, ${c} ${pct}%, ${b})`;
    const dark = box.dataset.on === "dark";
    return dark
      ? { main: "#fff", alt: S, soft: "rgba(255,255,255,.55)", faint: "rgba(255,255,255,.16)", ink: "#fff", muted: "rgba(255,255,255,.72)", line: "rgba(255,255,255,.22)", band: "rgba(255,255,255,.08)", onMain: P, onSoft: "#fff", neg: "#F2A08C", mix }
      : { main: P, alt: S, soft: mix(P, 45), faint: mix(P, 14), ink, muted: v(box, "--muted") || "#6b6b6b", line: v(box, "--line") || "#d9d9d9", band: mix(S, 16), onMain: "#fff", onSoft: ink, neg: v(box, "--bad") || "#C8553D", mix };
  }
  const base = (svg, c) => svg.setAttribute("style", `font-family:var(--body);overflow:visible`);
  const LBL = 18, DAT = 20;

  // 1. 100% stacked columns with series names on the left (BCG survey style)
  function stack100(svg, c, W, H, k) {
    const n = c.labels.length, left = c.seriesLabels === false ? 0 : 190, top = 34, bot = 44, gap = (W - left) / n, bw = Math.min(110, gap * .5);
    const y = p => top + (H - top - bot) * (1 - p / 100), cols = [k.main, k.soft, k.faint, k.alt];
    mk("line", { x1: left - 10, x2: W, y1: H - bot, y2: H - bot, stroke: k.line, "stroke-width": 1.5 }, svg);
    c.labels.forEach((L, i) => {
      const x = left + gap * i + (gap - bw) / 2; let acc = 0;
      c.series.forEach((s, si) => { const val = s.values[i]; if (!val) return;
        const y0 = y(acc), y1 = y(acc + val); const col = s.color || cols[si % 4];
        mk("rect", { x, y: y1, width: bw, height: Math.max(0, y0 - y1), fill: col, class: "cb", rx: si === c.series.length - 1 ? 3 : 0, style: `transition-delay:${i * .08}s` }, svg);
        if (y0 - y1 > 26) txt(svg, x + bw / 2, (y0 + y1) / 2 + 7, fmt(val, { suffix: c.suffix ?? "%" }), { "text-anchor": "middle", "font-size": DAT, "font-weight": 500, fill: si === 0 ? k.onMain : k.onSoft, class: "fade" });
        acc += val; });
      txt(svg, x + bw / 2, H - bot + 30, L, { "text-anchor": "middle", "font-size": LBL, fill: k.ink });
    });
    if (left) { let acc = 0; c.series.forEach(s => { const val = s.values[0]; const mid = y(acc + val / 2); acc += val;
      String(s.name).split("\n").forEach((ln, j, arr) => txt(svg, left - 24, mid + 6 + (j - (arr.length - 1) / 2) * 24, ln, { "text-anchor": "end", "font-size": LBL, fill: k.muted })); }); }
    if (c.total !== false) txt(svg, W, y(100) + 6, c.total || "100%", { "text-anchor": "end", "font-size": 16, fill: k.muted });
  }

  // 2. answer bubbles with a bracket that sums a group ("From half to all of it 69%")
  function bubbles(svg, c, W, H, k) {
    const n = c.items.length, gap = W / n, r = Math.min(gap * .36, (H - 140) / 2, 74), cy = 70 + r;
    if (c.group) { const [a, b] = c.group.range, x0 = gap * a + gap / 2 - r - 30, x1 = gap * b + gap / 2 + r + 30;
      mk("rect", { x: x0, y: cy - r * .62, width: x1 - x0, height: r * 1.24, fill: k.band, rx: 6, class: "fade" }, svg);
      const sum = c.group.total ?? c.items.slice(a, b + 1).reduce((t, d) => t + d.value, 0), mid = (x0 + x1) / 2;
      txt(svg, mid, 16, c.group.label, { "text-anchor": "middle", "font-size": 22, fill: k.ink });
      txt(svg, mid, 46, fmt(sum, { suffix: c.suffix ?? "%" }), { "text-anchor": "middle", "font-size": 22, "font-weight": 700, fill: k.ink });
      mk("line", { x1: x0, x2: mid - 150, y1: 9, y2: 9, stroke: k.ink, "stroke-width": 1.2 }, svg); mk("line", { x1: mid + 150, x2: x1, y1: 9, y2: 9, stroke: k.ink, "stroke-width": 1.2 }, svg); }
    const hl = c.highlight ?? -1;
    c.items.forEach((d, i) => { const cx = gap * i + gap / 2, rr = c.sized ? r * Math.sqrt(d.value / Math.max(...c.items.map(x => x.value))) : r;
      mk("circle", { cx, cy, r: rr, fill: i === hl ? k.main : k.mix(k.alt, 45), class: "fade" }, svg);
      txt(svg, cx, cy + 11, fmt(d.value, { suffix: c.suffix ?? "%" }), { "text-anchor": "middle", "font-size": 32, "font-weight": 500, fill: i === hl ? k.onMain : k.ink });
      String(d.label).split("\n").forEach((ln, j) => txt(svg, cx, cy + r + 38 + j * 26, ln, { "text-anchor": "middle", "font-size": 20, fill: k.ink })); });
  }

  // 3. yes/no split bars with a dashed remainder; highlight rows get a band
  function split(svg, c, W, H, k) {
    const left = 130, n = c.rows.length, rh = (H - 40) / n, bh = Math.min(52, rh * .62), hl = new Set(c.highlight || []);
    c.rows.forEach((d, i) => { const y = i * rh + (rh - bh) / 2, w = (W - left) * d.value / 100;
      if (hl.has(i)) mk("rect", { x: 0, y: i * rh, width: W, height: rh, fill: k.band }, svg);
      txt(svg, left - 16, y + bh / 2 + 7, d.label, { "text-anchor": "end", "font-size": LBL, fill: k.ink });
      mk("rect", { x: left, y, width: w, height: bh, fill: k.main, class: "hb", rx: 2 }, svg);
      mk("rect", { x: left + w, y: y + .75, width: W - left - w - .75, height: bh - 1.5, fill: "none", stroke: k.line, "stroke-dasharray": "5 4", "stroke-width": 1.5 }, svg);
      txt(svg, left + w / 2, y + bh / 2 + 7, d.value + "%", { "text-anchor": "middle", "font-size": DAT, fill: k.onMain, class: "fade" });
      txt(svg, left + w + (W - left - w) / 2, y + bh / 2 + 7, 100 - d.value + "%", { "text-anchor": "middle", "font-size": DAT, fill: k.muted, class: "fade" }); });
    mk("line", { x1: left, x2: left, y1: 0, y2: n * rh, stroke: k.line, "stroke-width": 1.5 }, svg);
    if (c.yes) txt(svg, left + (W - left) * .22, H - 4, c.yes, { "text-anchor": "middle", "font-size": 20, fill: k.ink });
    if (c.no) txt(svg, left + (W - left) * .7, H - 4, c.no, { "text-anchor": "middle", "font-size": 20, fill: k.ink });
  }

  // 4. waterfall: start, ups and downs, end
  function waterfall(svg, c, W, H, k) {
    const steps = c.steps, n = steps.length, top = 40, bot = 50, gap = W / n, bw = gap * .58;
    let run = 0; const pts = steps.map(s => { const from = s.total ? 0 : run, to = s.total ? s.value : run + s.value; run = s.total ? s.value : run + s.value; return { ...s, from, to }; });
    const max = Math.max(...pts.map(p => Math.max(p.from, p.to))) * 1.08, y = val => top + (H - top - bot) * (1 - val / max);
    mk("line", { x1: 0, x2: W, y1: y(0), y2: y(0), stroke: k.line, "stroke-width": 1.5 }, svg);
    pts.forEach((p, i) => { const x = gap * i + (gap - bw) / 2, y0 = y(Math.min(p.from, p.to)), y1 = y(Math.max(p.from, p.to));
      const col = p.total ? k.main : p.value >= 0 ? k.alt : k.neg;
      mk("rect", { x, y: y1, width: bw, height: Math.max(1, y0 - y1), fill: col, rx: 3, class: "cb", style: `transition-delay:${i * .07}s` }, svg);
      if (i < n - 1) mk("line", { x1: x + bw, x2: x + gap, y1: y(p.to), y2: y(p.to), stroke: k.muted, "stroke-dasharray": "3 3", "stroke-width": 1.2, class: "fade" }, svg);
      txt(svg, x + bw / 2, y1 - 10, (p.total || p.value < 0 ? "" : "+") + fmt(p.value, c), { "text-anchor": "middle", "font-size": DAT, "font-weight": p.total ? 600 : 400, fill: k.ink, class: "fade" });
      String(p.label).split("\n").forEach((ln, j) => txt(svg, x + bw / 2, H - bot + 28 + j * 22, ln, { "text-anchor": "middle", "font-size": 16, fill: k.muted })); });
  }

  // 5. slope: two points in time, one line per item, highlight one
  function slope(svg, c, W, H, k) {
    const all = c.items.flatMap(d => [d.a, d.b]), lo = Math.min(...all), hi = Math.max(...all), top = 50, bot = 20;
    const y = val => top + (H - top - bot) * (1 - (val - lo) / ((hi - lo) || 1)), x0 = W * .3, x1 = W * .7;
    txt(svg, x0, 18, c.from, { "text-anchor": "middle", "font-size": 18, "font-weight": 600, fill: k.muted });
    txt(svg, x1, 18, c.to, { "text-anchor": "middle", "font-size": 18, "font-weight": 600, fill: k.muted });
    c.items.forEach((d, i) => { const on = i === c.highlight, col = on ? k.main : k.line;
      mk("line", { x1: x0, x2: x1, y1: y(d.a), y2: y(d.b), stroke: col, "stroke-width": on ? 4 : 2.2, "stroke-linecap": "round", class: "fade" }, svg);
      [[x0, d.a, "end", -16], [x1, d.b, "start", 16]].forEach(([x, val, an, dx]) => { mk("circle", { cx: x, cy: y(val), r: on ? 7 : 5, fill: on ? k.main : k.soft }, svg);
        txt(svg, x + dx, y(val) + 6, (an === "end" ? d.label + "  " : "") + fmt(val, c), { "text-anchor": an, "font-size": on ? 20 : 17, "font-weight": on ? 600 : 400, fill: on ? k.ink : k.muted }); }); });
  }

  // 6. dumbbell: before → after per row
  function dumbbell(svg, c, W, H, k) {
    const left = 200, n = c.rows.length, rh = (H - 40) / n, all = c.rows.flatMap(r => [r.a, r.b]), max = c.max ?? Math.max(...all) * 1.1, min = c.min ?? 0;
    const x = val => left + (W - left - 40) * (val - min) / (max - min);
    c.rows.forEach((r, i) => { const yy = 30 + i * rh + rh / 2, up = r.b >= r.a;
      txt(svg, left - 20, yy + 6, r.label, { "text-anchor": "end", "font-size": LBL, fill: k.ink });
      mk("line", { x1: x(r.a), x2: x(r.b), y1: yy, y2: yy, stroke: up ? k.soft : k.mix(k.neg, 50), "stroke-width": 8, "stroke-linecap": "round", class: "fade" }, svg);
      mk("circle", { cx: x(r.a), cy: yy, r: 8, fill: k.paper || "#fff", stroke: k.muted, "stroke-width": 2.5 }, svg);
      mk("circle", { cx: x(r.b), cy: yy, r: 10, fill: up ? k.main : k.neg }, svg);
      txt(svg, x(Math.max(r.a, r.b)) + 18, yy + 7, fmt(r.b, c), { "text-anchor": "start", "font-size": DAT, "font-weight": 600, fill: k.ink }); });
    if (c.legend) { txt(svg, left, 14, "○ " + c.legend[0], { "font-size": 16, fill: k.muted }); txt(svg, left + 180, 14, "● " + c.legend[1], { "font-size": 16, fill: k.main }); }
  }

  // 7. ranked bars with one highlight and an optional average line
  function rank(svg, c, W, H, k) {
    const rows = c.sort === false ? c.rows : [...c.rows].sort((a, b) => b.value - a.value), left = 210, n = rows.length, rh = H / n, bh = Math.min(30, rh * .58);
    const max = Math.max(...rows.map(r => r.value)) * 1.12, x = val => left + (W - left) * val / max;
    if (c.avg != null) { const ax = x(c.avg); mk("line", { x1: ax, x2: ax, y1: -6, y2: H, stroke: k.ink, "stroke-dasharray": "4 4", "stroke-width": 1.2 }, svg);
      txt(svg, ax + 6, -12, (c.avgLabel || "Average") + " " + fmt(c.avg, c), { "font-size": 15, fill: k.ink }); }
    rows.forEach((r, i) => { const yy = i * rh + (rh - bh) / 2, on = r.label === c.highlight || i === c.highlight;
      txt(svg, left - 16, yy + bh / 2 + 6, r.label, { "text-anchor": "end", "font-size": LBL, "font-weight": on ? 600 : 400, fill: on ? k.ink : k.muted });
      mk("rect", { x: left, y: yy, width: x(r.value) - left, height: bh, rx: bh / 2, fill: on ? k.main : k.faint, class: "hb", style: `transition-delay:${i * .05}s` }, svg);
      txt(svg, x(r.value) + 12, yy + bh / 2 + 7, fmt(r.value, c), { stroke: k.paper || "#fff", "stroke-width": 6, "paint-order": "stroke", "stroke-linejoin": "round", "font-size": DAT, "font-weight": on ? 600 : 400, fill: on ? k.ink : k.muted, class: "fade" }); });
  }

  // 8. growth columns with CAGR pills (BCG market sizing style)
  function growth(svg, c, W, H, k) {
    const n = c.labels.length, top = 92, bot = 44, gap = W / n, bw = gap * .56, vals = c.values, max = Math.max(...vals) * 1.05;
    const y = val => top + (H - top - bot) * (1 - val / max), hl = new Set(c.highlight ?? [n - 1]), fc = new Set(c.forecast || []);
    mk("line", { x1: 0, x2: W, y1: H - bot, y2: H - bot, stroke: k.line, "stroke-width": 1.5 }, svg);
    vals.forEach((val, i) => { const x = gap * i + (gap - bw) / 2;
      mk("rect", { x, y: y(val), width: bw, height: H - bot - y(val), rx: 3, fill: hl.has(i) ? k.main : k.soft, "fill-opacity": fc.has(i) ? .45 : 1, stroke: fc.has(i) ? k.main : "none", "stroke-dasharray": "4 3", class: "cb", style: `transition-delay:${i * .05}s` }, svg);
      txt(svg, x + bw / 2, y(val) - 10, fmt(val, c), { "text-anchor": "middle", "font-size": 18, "font-weight": hl.has(i) ? 600 : 400, fill: k.ink, class: "fade" });
      txt(svg, x + bw / 2, H - bot + 28, c.labels[i], { "text-anchor": "middle", "font-size": 16, fill: k.muted }); });
    (c.cagr || []).forEach((g, j) => { const xa = gap * g.from + gap / 2, xb = gap * g.to + gap / 2, yy = 22 + j * 0;
      mk("path", { d: `M${xa},${y(vals[g.from]) - 34} L${xa},${yy + 14} L${xb},${yy + 14} L${xb},${y(vals[g.to]) - 34}`, fill: "none", stroke: k.muted, "stroke-width": 1.2, "stroke-dasharray": "3 3", class: "fade" }, svg);
      const t = g.text, w = t.length * 10.5 + 28, mx = (xa + xb) / 2;
      mk("rect", { x: mx - w / 2, y: yy - 4, width: w, height: 34, rx: 17, fill: g.neg ? k.neg : k.alt, class: "fade" }, svg);
      txt(svg, mx, yy + 19, t, { "text-anchor": "middle", "font-size": 17, "font-weight": 600, fill: "#fff", class: "fade" }); });
  }

  // 9. marimekko: column widths = size, stacks = mix
  function mekko(svg, c, W, H, k) {
    const lines = Math.max(...c.cols.map(d => String(d.label).split("\n").length));   // category labels may use \n
    const LG = Math.min(170, (W - (c.line ? 190 : 0)) / Math.max(1, (c.parts || []).length));   // legend spacing that fits
    const total = c.cols.reduce((t, d) => t + d.width, 0), top = c.line ? 120 : 10, bot = 36 + 20 * lines, cols = [k.main, k.soft, k.faint, k.alt]; let x = 0;
    c.cols.forEach((d, i) => { const w = (W - (c.cols.length - 1) * 4) * d.width / total; let acc = 0;
      d.parts.forEach((p, j) => { const h = (H - top - bot) * p / 100, yy = H - bot - acc - h;
        mk("rect", { x, y: yy, width: w, height: h, fill: cols[j % 4], class: "cb" }, svg);
        if (h > 26 && w > 50) txt(svg, x + w / 2, yy + h / 2 + 7, p + "%", { "text-anchor": "middle", "font-size": 18, fill: j === 0 ? k.onMain : k.onSoft, class: "fade" });
        acc += h; });
      // narrow last column: right-align its labels so they don't run off the chart
      const edge = i === c.cols.length - 1 && w < 170, lx = edge ? x + w : x + w / 2, an = edge ? "end" : "middle";
      const ls = String(d.label).split("\n"), g = mk("g", { class: "mk-lbl" }, svg);
      ls.forEach((ln, j) => txt(g, lx, H - bot + 26 + j * 20, ln, { "text-anchor": an, "font-size": 17, fill: k.ink }));
      txt(g, lx, H - bot + 26 + ls.length * 20 + 2, fmt(d.width, c), { "text-anchor": an, "font-size": 15, fill: k.muted });
      x += w + 4; });
    // optional cost line over the columns: {"line": {"name": "...", "values": [...], "labels": [...]}} (own scale, starts at 0)
    if (c.line) { const L = c.line, mx = Math.max(...L.values.filter(v => v != null)) * 1.35 || 1, pts = []; let xx = 0;
      c.cols.forEach((d, i) => { const w = (W - (c.cols.length - 1) * 4) * d.width / total; pts.push([xx + w / 2, top - 22 - 70 * (L.values[i] || 0) / mx]); xx += w + 4; });   // own band above the columns
      const lc = L.color || "#E8A23C";
      mk("line", { x1: 0, x2: W, y1: top - 22, y2: top - 22, stroke: k.line, "stroke-dasharray": "3 4", "stroke-width": 1.2 }, svg);
      const known = pts.filter((p, i) => L.values[i] != null).map(p => p.join(",")).join(" ");   // null = unknown cost: no point
      mk("polyline", { points: known, fill: "none", stroke: "#fff", "stroke-width": 7, "stroke-linejoin": "round", opacity: .85, class: "fade" }, svg);
      mk("polyline", { points: known, fill: "none", stroke: lc, "stroke-width": 3.5, "stroke-linejoin": "round", class: "fade" }, svg);
      let prevT = null;
      pts.forEach(([px, py], i) => { if (L.values[i] == null) { if ((L.labels || [])[i]) txt(svg, px, py - 10, L.labels[i], { "text-anchor": "middle", "font-size": 15, "font-style": "italic", fill: k.muted, class: "fade" }); return; }
        mk("circle", { cx: px, cy: py, r: 8, fill: lc, stroke: "#fff", "stroke-width": 3, class: "fade" }, svg);
        const n = pts.length, an = i === 0 && n > 1 ? "start" : i === n - 1 && n > 1 ? "end" : "middle", ox = an === "start" ? -8 : an === "end" ? 8 : 0;
        const pv = L.values.slice(0, i).reverse().find(v => v != null), down = i > 0 && L.values[i] > 0 && pv != null && L.values[i] < pv;   // a point lower than the one before: label underneath, off the line
        const t = txt(svg, px + ox, down ? py + 28 : py - 16, (L.labels || [])[i] ?? fmt(L.values[i], L), { "text-anchor": an, "font-size": 18, "font-weight": 700, fill: k.ink, class: "fade" });
        t.setAttribute("paint-order", "stroke"); t.setAttribute("stroke", "#fff"); t.setAttribute("stroke-width", 5); t.setAttribute("stroke-linejoin", "round");
        // a label that would touch the previous one goes under its point instead
        const prev = prevT; prevT = t;
        if (prev) { const a = prev.getBBox(), b = t.getBBox(); if (b.x < a.x + a.width + 8 && b.x + b.width > a.x - 8 && Math.abs(b.y - a.y) < b.height + 2) t.setAttribute("y", py + 30); } });
      const lx0 = (c.parts || []).length * LG;
      mk("line", { x1: lx0, x2: lx0 + 22, y1: -27, y2: -27, stroke: lc, "stroke-width": 3.5 }, svg); mk("circle", { cx: lx0 + 11, cy: -27, r: 5, fill: lc }, svg);
      txt(svg, lx0 + 30, -22, L.name || "", { "font-size": 16, fill: k.muted }); }
    // labels of neighbouring columns must not touch: slide a label left until it clears the one on its right
    const gs = [...svg.querySelectorAll(".mk-lbl")];
    for (let i = gs.length - 2; i >= 0; i--) { const r = gs[i].getBBox(), n = gs[i + 1].getBBox(), dx = r.x + r.width + 14 - n.x - (+gs[i + 1].dataset.dx || 0);
      if (dx > 0) { const sh = Math.min(dx, r.x); gs[i].setAttribute("transform", `translate(${-sh},0)`); gs[i].dataset.dx = -sh; } }
    (c.parts || []).forEach((p, j) => { mk("rect", { x: j * LG, y: -34, width: 14, height: 14, rx: 3, fill: cols[j % 4] }, svg); txt(svg, j * LG + 22, -22, p, { "font-size": 16, fill: k.muted }); });
  }

  // 10. 2x2 matrix with quadrant names and sized points
  function matrix(svg, c, W, H, k) {
    const L = 40, B = 40, w = W - L, h = H - B;
    [[0, 0], [1, 0], [0, 1], [1, 1]].forEach(([qx, qy], i) => mk("rect", { x: L + qx * w / 2 + 3, y: qy * h / 2 + 3, width: w / 2 - 6, height: h / 2 - 6, rx: 10, fill: i === (c.hlQuad ?? 1) ? k.band : k.mix(k.line, 30) }, svg));
    (c.quads || []).forEach((q, i) => txt(svg, L + (i % 2) * w / 2 + 22, Math.floor(i / 2) * h / 2 + 36, q, { "font-size": 17, "font-weight": 600, fill: k.muted }));
    txt(svg, L + w / 2, H - 6, c.x + "  →", { "text-anchor": "middle", "font-size": 17, fill: k.ink });
    const yl = txt(svg, 14, h / 2, c.y + "  →", { "text-anchor": "middle", "font-size": 17, fill: k.ink, transform: `rotate(-90 14 ${h / 2})` });
    (c.points || []).forEach(p => { const cx = L + w * p.x / 100, cy = h * (1 - p.y / 100), r = p.r || 14;
      mk("circle", { cx, cy, r, fill: p.hl ? k.main : k.soft, "fill-opacity": p.hl ? 1 : .85, class: "fade" }, svg);
      txt(svg, cx + r + 8, cy + 6, p.label, { "font-size": 16, "font-weight": p.hl ? 600 : 400, fill: k.ink, class: "fade" }); });
  }

  // 11. harvey-ball table (0–4 filled quarters)
  function harvey(svg, c, W, H, k) {
    const left = 230, cw = (W - left) / c.cols.length, rh = (H - 50) / c.rows.length, r = Math.min(16, rh * .3);
    c.cols.forEach((t, j) => txt(svg, left + cw * j + cw / 2, 22, t, { "text-anchor": "middle", "font-size": 16, "font-weight": 600, fill: k.muted }));
    c.rows.forEach((row, i) => { const cy = 50 + rh * i + rh / 2;
      if (i % 2 === 0) mk("rect", { x: 0, y: 50 + rh * i, width: W, height: rh, fill: k.mix(k.line, 22) }, svg);
      txt(svg, 12, cy + 6, row.label, { "font-size": 18, fill: k.ink });
      row.values.forEach((q, j) => { const cx = left + cw * j + cw / 2;
        mk("circle", { cx, cy, r, fill: "none", stroke: k.main, "stroke-width": 2 }, svg);
        if (q >= 4) mk("circle", { cx, cy, r, fill: k.main }, svg);
        else if (q > 0) { const a = q / 4 * 2 * Math.PI, x2 = cx + r * Math.sin(a), y2 = cy - r * Math.cos(a);
          mk("path", { d: `M${cx},${cy} L${cx},${cy - r} A${r},${r} 0 ${a > Math.PI ? 1 : 0} 1 ${x2},${y2} Z`, fill: k.main }, svg); } }); });
  }

  // 12. funnel steps with curved connectors (conversion stages)
  function funnel(svg, c, W, H, k) {
    const n = c.steps.length, gap = W / n, bw = gap * .42, max = c.steps[0].value;
    c.steps.forEach((s, i) => { const h = (H - 70) * s.value / max, x = gap * i + (gap - bw) / 2, yy = H - 40 - h;
      mk("rect", { x, y: yy, width: bw, height: h, rx: 4, fill: i === n - 1 ? k.main : k.soft, class: "cb" }, svg);
      txt(svg, x + bw / 2, yy - 12, fmt(s.value, c), { "text-anchor": "middle", "font-size": 22, "font-weight": 600, fill: k.ink, class: "fade" });
      txt(svg, x + bw / 2, H - 12, s.label, { "text-anchor": "middle", "font-size": 17, fill: k.muted });
      if (i < n - 1) { const nh = (H - 70) * c.steps[i + 1].value / max, x2 = gap * (i + 1) + (gap - bw) / 2, ny = H - 40 - nh;
        mk("path", { d: `M${x + bw},${yy} C${x + bw + 40},${yy} ${x2 - 40},${ny} ${x2},${ny} L${x2},${H - 40} L${x + bw},${H - 40} Z`, fill: k.faint, class: "fade" }, svg);
        const pct = Math.round(c.steps[i + 1].value / s.value * 100);
        txt(svg, (x + bw + x2) / 2, H - 56, pct + "%", { "text-anchor": "middle", "font-size": 16, "font-weight": 600, fill: k.main, class: "fade" }); } });
  }

  const VIZ = { stack100, bubbles, split, waterfall, slope, dumbbell, rank, growth, mekko, matrix, harvey, funnel };
  const drawViz = (box, c) => { const W = box.offsetWidth, H = box.offsetHeight; if (!W || !H) return;
    box.innerHTML = ""; const svg = mk("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": c.title || c.type + " chart" }, box);
    base(svg, c); const k = pal(box); k.paper = v(box, "--paper"); VIZ[c.type](svg, c, W, H, k); };
  // hook into the deck's chart pipeline so renderCharts, theme switches and morph all work
  const prev = window.drawChart;
  window.drawChart = (box, c) => VIZ[c.type] ? drawViz(box, c) : prev && prev(box, c);
  window.drawViz = drawViz; window.VIZ_TYPES = Object.keys(VIZ);
  const run = () => document.querySelectorAll(".chart[data-chart]").forEach(b => { if (b.classList.contains("morphing")) return; let c; try { c = JSON.parse(b.dataset.chart); } catch (e) { return; } if (VIZ[c.type]) drawViz(b, c); });
  run(); document.fonts?.ready.then(run);
  let rt = 0; window.addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(run, 160); });
})();
