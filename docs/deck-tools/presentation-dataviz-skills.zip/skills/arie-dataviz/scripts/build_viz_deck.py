"""Build a deck from data slides, on the Deck Builder by Arie engine.

    python3 build_viz_deck.py slides.html out/deck.html [--theme sage] [--name "Deck name"] [--keep-layouts]

slides.html holds only <section class="slide" ...> blocks (see examples/demo_slides.html).
The engine, themes, presenter tools, editing, comments, morph and export all come from
~/.claude/skills/arie-deck-builder/template/layouts.html; this script adds the dataviz CSS + JS.
--keep-layouts keeps the 30 layout slides after yours (handy to mix data slides with designed ones).
To add data slides to an existing deck instead, run add_dataviz.py on it.
"""
import argparse, pathlib, re

HERE = pathlib.Path(__file__).resolve().parent.parent
ENGINE = pathlib.Path.home() / ".claude/skills/arie-deck-builder/template/layouts.html"


def inject(t):
    css = (HERE / "template/_dataviz.css").read_text()
    js = (HERE / "template/_dataviz.js").read_text()
    t = re.sub(r"/\* dataviz-css:begin \*/.*?/\* dataviz-css:end \*/\n?", "", t, flags=re.S)
    t = re.sub(r"<script>/\* dataviz:begin \*/.*?/\* dataviz:end \*/</script>\n?", "", t, flags=re.S)
    i = t.index("</style>")
    t = t[:i] + "/* dataviz-css:begin */\n" + css + "/* dataviz-css:end */\n" + t[i:]
    return t + "\n<script>/* dataviz:begin */\n" + js + "/* dataviz:end */</script>\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slides"); ap.add_argument("out")
    ap.add_argument("--theme", default="sage", help="one theme, or several comma-separated (first is the default; the theme menu shows them all)"); ap.add_argument("--name", default="Insight deck")
    ap.add_argument("--keep-layouts", action="store_true")
    a = ap.parse_args()
    t = ENGINE.read_text()
    slides = pathlib.Path(a.slides).read_text()
    start = t.index('<section class="slide'); end = t.index('<canvas id="ink"')
    body = slides + ("\n" + t[start:end] if a.keep_layouts else "\n")
    t = t[:start] + body + "    " + t[end:]
    themes = [x.strip() for x in a.theme.split(",") if x.strip()]
    t = re.sub(r'const THEMES = \[[^\]]*\];', 'const THEMES = [' + ", ".join(f'"{x}"' for x in themes) + '];', t, count=1)
    t = t.replace('data-deck="Holiday Creator Campaign"', f'data-deck="{a.name}"', 1)
    t = re.sub(r"<title>.*?</title>", f"<title>{a.name}</title>", t, count=1)
    out = pathlib.Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(inject(t))
    print("wrote", out, "·", slides.count('<section class="slide'), "data slides · theme", a.theme)


if __name__ == "__main__":
    main()
