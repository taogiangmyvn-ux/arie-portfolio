"""Add (or update) the dataviz CSS + JS in an existing Deck Builder by Arie deck, so its slides can use
the 12 consulting chart types and the vz-* text blocks.

    python3 add_dataviz.py path/to/deck.html [more decks...]
"""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from build_viz_deck import inject

for f in sys.argv[1:]:
    p = pathlib.Path(f)
    p.write_text(inject(p.read_text()))
    print("updated", p)
