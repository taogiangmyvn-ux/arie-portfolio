# Presentation & Data Visualization Tools — Team Workflows

Three Claude skills that turn a doc, a spreadsheet or a brief into a board-ready, editable HTML deck. Built for marketing and brand teams who report every month and are tired of dragging charts around in PowerPoint.

https://github.com/taogiangmyvn-ux/presentation-dataviz-tools/raw/main/media/Report_Charts_promo_16x9.mp4

| Skill | What it does |
|---|---|
| **arie-deck-builder** | Interactive decks as one HTML file. 47 layouts, 13 themes, morph transitions, in-place editing (text style bar, photo crop/replace, Ctrl+Z), pen and shapes, comments, export to PDF and PPTX. |
| **arie-dataviz** | Consulting-style data slides on the same engine: action titles, survey question boxes, delta callouts, takeaway bands, source lines. 12 chart types (100% stacked, waterfall, slope, dumbbell, marimekko, 2×2, funnel…). |
| **arie-report-charts** | Quarterly / monthly business reports in a clean report style: KPI rows with deltas, event-marked charts, a "how to read" line under every chart, IMPLICATION boxes. 16 chart functions incl. heatmap, radar, waterfall, funnel, dual axis, small multiples. One command turns the report into an editable deck. |

## Why it exists

Most AI-made decks have a topic title, five buzzword bullets and no numbers. These skills enforce the opposite:

- **Action titles.** The title states the finding ("NMV up 93% — one marketplace carries 85%"), not the topic ("Q3 Sales Overview").
- **One chart, one message.** Values on the bars, ranked bars sorted, reference lines for targets and break-even, marketing moments marked on the timeline.
- **So what, every slide.** Each slide ends with the implication and the next action, in bold.
- **Brand-safe.** Themes come from the brand book; logos and product photos are never redrawn.

## Demos (fictional numbers)

- `demo/report-charts-deck.html` — 11-slide quarterly report, editable
- `demo/dataviz-deck.html` — consulting-style data slides
- `demo/layout-library.html` — all 47 layouts; switch themes from the toolbar

Open any file in a browser. Arrow keys move slides, **W** edits text, **S** switches to scroll view.

## Install (Claude Code)

```bash
cp -r skills/* ~/.claude/skills/
```

Then ask Claude, for example:

- `/arie-report-charts build a Q3 report deck from report.docx`
- `/arie-deck-builder make a 10-slide pitch in the azure theme`
- `/arie-dataviz turn this survey CSV into data slides`

Chrome is used for PDF export. Python 3 with PyMuPDF and Pillow is used for PPTX export and image prep.

## Team workflow

1. **Brief in, draft out.** Drop the doc or data; the skill classifies each piece of content and picks the layout (see the content-to-layout table in `skills/arie-deck-builder/SKILL.md`).
2. **Review in place.** Publish as a private page; teammates edit text, swap photos and leave comments directly on the slides.
3. **Ship.** Export PDF for email, PPTX for PowerPoint / Google Slides, or share the link.

## Repo layout

```
skills/   arie-deck-builder · arie-dataviz · arie-report-charts
demo/     three demo decks (fictional data)
media/    promo videos, 9:16 and 16:9
```

Made by Arie.
